VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} VefeyatKisiSec
   Caption         =   "Vefeyat - Kisi secimi"
   ClientHeight    =   6480
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   9000
   OleObjectBlob   =   "VefeyatKisiSec.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "VefeyatKisiSec"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit


' Empty designer binary: Copyright (c) 2026 Samy Haliem, MIT License.
' See THIRD-PARTY-NOTICES.txt. All code below is Vefeyat source.

Private WithEvents mResults As MSForms.ListBox
Private WithEvents mChoose As MSForms.CommandButton
Private WithEvents mCancel As MSForms.CommandButton
Private mDetails As MSForms.TextBox
Private mPrompt As MSForms.Label
Private mRows As Collection
Private mBrowse As Boolean

' One-based index in the candidates collection; 0 means cancellation.
Public ChosenIndex As Long

' Every record is a Variant array indexed 0..5:
' short name, full name, original name, death date, description, source link.
Public Sub InitCandidates(ByVal people As Collection, ByVal query As String)
    Dim i As Long, person As Variant
    Set mRows = people
    ChosenIndex = 0
    mResults.Clear
    mPrompt.Caption = query & VfkText(" i\u00e7in ") & CStr(people.Count) & _
        VfkText(" kay\u0131t bulundu. Eklemek istedi\u011finiz ki\u015fiyi se\u00e7in.")
    For i = 1 To people.Count
        person = people(i)
        mResults.AddItem CStr(person(0))
        mResults.List(i - 1, 1) = CStr(person(3))
        mResults.List(i - 1, 2) = CStr(person(1))
    Next i
    mResults.ListIndex = -1
    mDetails.Text = VfkText("Ayr\u0131nt\u0131lar\u0131 g\u00f6rmek i\u00e7in listeden bir ki\u015fi se\u00e7in.")
    mChoose.Enabled = False
End Sub

Public Sub SetBrowseOnly()
    mBrowse = True
    mChoose.Visible = False
    mCancel.Caption = VfkText("Kapat")
    mPrompt.Caption = VfkText("Yerel kay\u0131tlar: ayr\u0131nt\u0131lar i\u00e7in bir ki\u015fi se\u00e7in.")
End Sub

Private Sub UserForm_Initialize()
    Me.Caption = VfkText("Vefey\u00e2t: ki\u015fiyi se\u00e7in")
    Me.Width = 640
    Me.Height = 463
    Me.Font.Name = "Segoe UI"
    Me.Font.Size = 10

    Set mPrompt = Me.Controls.Add("Forms.Label.1", "ResultPrompt", True)
    With mPrompt
        .Left = 16: .Top = 12: .Width = 600: .Height = 32
        .WordWrap = True
    End With

    AddHeading VfkText("K\u0131sa ad"), 16, 160
    AddHeading "Vefat tarihi", 176, 90
    AddHeading "Tam ad", 266, 350

    Set mResults = Me.Controls.Add("Forms.ListBox.1", "Results", True)
    With mResults
        .Left = 16: .Top = 66: .Width = 600: .Height = 164
        .ColumnCount = 3
        .ColumnWidths = "160 pt;90 pt;330 pt"
        .MultiSelect = fmMultiSelectSingle
        .TabIndex = 0
    End With

    Set mDetails = Me.Controls.Add("Forms.TextBox.1", "Details", True)
    With mDetails
        .Left = 16: .Top = 242: .Width = 600: .Height = 144
        .MultiLine = True
        .WordWrap = True
        .ScrollBars = fmScrollBarsVertical
        .Locked = True
        .TabIndex = 1
    End With

    Set mChoose = Me.Controls.Add("Forms.CommandButton.1", "ChooseButton", True)
    With mChoose
        .Caption = VfkText("Se\u00e7 ve ekle")
        .Left = 394: .Top = 400: .Width = 108: .Height = 28
        .Default = True
        .Enabled = False
        .TabIndex = 2
    End With

    Set mCancel = Me.Controls.Add("Forms.CommandButton.1", "CancelButton", True)
    With mCancel
        .Caption = VfkText("\u0130ptal")
        .Left = 514: .Top = 400: .Width = 102: .Height = 28
        .Cancel = True
        .TabIndex = 3
    End With
End Sub

Private Sub mResults_Change()
    Dim row As Variant
    If mRows Is Nothing Then Exit Sub
    If mResults.ListIndex < 0 Then
        mDetails.Text = vbNullString
        mChoose.Enabled = False
        Exit Sub
    End If
    row = mRows(mResults.ListIndex + 1)
    mDetails.Text = "Tam ad: " & CStr(row(1)) & vbCrLf & _
        "Orijinal ad: " & CStr(row(2)) & vbCrLf & _
        "Vefat tarihi: " & CStr(row(3)) & vbCrLf & vbCrLf & _
        CStr(row(4)) & vbCrLf & vbCrLf & "Kaynak: " & CStr(row(5))
    mChoose.Enabled = True
End Sub

Private Sub mResults_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    mChoose_Click
End Sub

Private Sub mChoose_Click()
    If mBrowse Then Exit Sub
    If mResults.ListIndex < 0 Then Exit Sub
    ChosenIndex = mResults.ListIndex + 1
    Me.Hide
End Sub

Private Sub mCancel_Click()
    ChosenIndex = 0
    Me.Hide
End Sub

Private Sub UserForm_QueryClose(Cancel As Integer, CloseMode As Integer)
    If CloseMode = vbFormControlMenu Then
        Cancel = True
        ChosenIndex = 0
        Me.Hide
    End If
End Sub

Private Sub AddHeading(ByVal text As String, ByVal x As Single, ByVal size As Single)
    Dim heading As MSForms.Label
    Set heading = Me.Controls.Add("Forms.Label.1")
    With heading
        .Caption = text
        .Left = x
        .Top = 48
        .Width = size
        .Height = 16
        .Font.Bold = True
    End With
End Sub

' Decode ASCII source labels without depending on another module's helpers.
Private Function VfkText(ByVal escaped As String) As String
    Dim i As Long, j As Long, code As Long, digit As Long
    Dim result As String, valid As Boolean, part As String
    i = 1
    Do While i <= Len(escaped)
        If Mid$(escaped, i, 2) = "\u" And i + 5 <= Len(escaped) Then
            part = Mid$(escaped, i + 2, 4)
            code = 0
            valid = True
            For j = 1 To 4
                digit = InStr(1, "0123456789abcdef", LCase$(Mid$(part, j, 1)), vbBinaryCompare) - 1
                If digit < 0 Then
                    valid = False
                    Exit For
                End If
                code = code * 16 + digit
            Next j
            If valid Then
                If code > 32767 Then code = code - 65536
                result = result & ChrW(code)
                i = i + 6
            Else
                result = result & Mid$(escaped, i, 1)
                i = i + 1
            End If
        Else
            result = result & Mid$(escaped, i, 1)
            i = i + 1
        End If
    Loop
    VfkText = result
End Function
