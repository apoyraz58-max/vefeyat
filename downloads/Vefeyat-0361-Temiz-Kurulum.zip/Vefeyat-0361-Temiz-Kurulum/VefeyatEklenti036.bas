Attribute VB_Name = "VefeyatEklenti036"
Option Explicit

' Pass UTF-16 string pointers directly; VBA MsgBox uses the ANSI code page.
#If VBA7 Then
Private Declare PtrSafe Function VfMessageBoxW Lib "user32" Alias "MessageBoxW" (ByVal owner As LongPtr, ByVal message As LongPtr, ByVal title As LongPtr, ByVal flags As Long) As Long
#Else
Private Declare Function VfMessageBoxW Lib "user32" Alias "MessageBoxW" (ByVal owner As Long, ByVal message As Long, ByVal title As Long, ByVal flags As Long) As Long
#End If

' Local UTF-8 CSV catalog. No network or installer.
' Keep this source ASCII so it imports consistently into the VBA editor.
Private mVfRows As Collection
Private mVfSearchText() As String
Private mVfNameText() As String
Private mVfNameKeys() As String
Private mVfIndexReady As Boolean
Private mVfUniqueCounter As Long

Private Const VfpPrefixVariable As String = "VefeyatPrefix"
Private Const VfpScopeVariable As String = "VefeyatScope"
Private Const VfpInvalidSetting As Long = vbObjectError + 2301
Private Const VfpInvalidDocument As Long = vbObjectError + 2302
Private Const VfpCheckFailure As Long = vbObjectError + 2303

' Only an explicit leading death marker is changed. The rest of a catalog
' expression, including spaces, uncertainty, ranges, and punctuation, is kept.

Private Const VfaTagPrefix As String = "Vefeyat.Date."
Private Const VfaVariablePrefix As String = "Vefeyat.Binding."
Private Const VfaNextVariable As String = "Vefeyat.NextBinding"
Private Const VfaNamespaceVariable As String = "Vefeyat.BindingNamespace"
Private Const VfaManualBookmarkPrefix As String = "_VfM_"
Private Const VfaInvalidData As Long = vbObjectError + 2401
Private Const VfaCheckFailure As Long = vbObjectError + 2402
Private Const VfaMaxName As Long = 200
Private Const VfaMaxDate As Long = 500
Private mVfaRandomized As Boolean

' No catalog access or document writes are allowed in this enabled callback.

Private mVflPending As Boolean
Private mVflBusy As Boolean
Private mVflSuspended As Boolean
Private mVflStates As Collection
Private mVflStatus As String
Private mVflDueAt As Date
Private mVflLastTick As Date
Private mVflTicks As Long
Private mVflPhase As String
Private mVflProbePath As String

' A source spelling is a proposal, never a claim that all other forms are wrong.
' Only the explicitly selected name is edited; no document-wide replacement.

Private Const VfrVersion As String = "0.3.6.1"
Private mVfrRibbon As Object
Private mVfrEvents As VefeyatOlaylar036

' Explicit, user-run setup inside a separate, user-authored Word template.
' Never copy code from Normal or access the VBProject model.
' All ZIP and XML operations are local Windows COM calls, without shell commands.
Private mVfsBusy As Boolean
Private Const VfsSourceTemplateName As String = "VefeyatHazirlik.dotm"
Private Const VfsInstalledModule As String = "VefeyatEklenti036"
Private Const VfsTemplateName As String = "VefeyatEklenti.dotm"
Private Const VfsRibbonName As String = "VefeyatRibbon.xml"
Private Const VfsUiNamespace As String = "http://schemas.microsoft.com/office/2009/07/customui"
Private Const VfsUiRelationship As String = "http://schemas.microsoft.com/office/2007/relationships/ui/extensibility"
Private Const VfsRelationshipsNamespace As String = "http://schemas.openxmlformats.org/package/2006/relationships"
Private Const VfsContentTypesNamespace As String = "http://schemas.openxmlformats.org/package/2006/content-types"

Private Function VfMessage(ByVal message As String, Optional ByVal flags As Long = 0, Optional ByVal title As String = "Vefeyat") As Long
    VfMessage = VfMessageBoxW(0, StrPtr(message), StrPtr(title), flags Or &H2000&)
End Function

Private Function VfText(ByVal escaped As String) As String
    Dim i As Long, j As Long, code As Long, digit As Long
    Dim part As String, result As String, valid As Boolean
    i = 1
    Do While i <= Len(escaped)
        If Mid$(escaped, i, 2) = "\u" And i + 5 <= Len(escaped) Then
            part = Mid$(escaped, i + 2, 4)
            valid = True
            code = 0
            For j = 1 To 4
                digit = InStr(1, "0123456789abcdef", LCase$(Mid$(part, j, 1)), vbBinaryCompare) - 1
                If digit < 0 Then
                    valid = False
                    Exit For
                End If
                code = code * 16 + digit
            Next j
            If valid Then
                If code > 32767 Then code = code - 65536
                result = result & ChrW(code)
                i = i + 6
            Else
                result = result & Mid$(escaped, i, 1)
                i = i + 1
            End If
        Else
            result = result & Mid$(escaped, i, 1)
            i = i + 1
        End If
    Loop
    VfText = result
End Function

Private Function VefeyatDataPath() As String
    Dim root As String
    root = Environ$("LOCALAPPDATA")
    If Len(root) = 0 Then VfFail "Windows LOCALAPPDATA folder is unavailable."
    If Right$(root, 1) = "\" Then root = Left$(root, Len(root) - 1)
    VfCheckLocalPath root
    VefeyatDataPath = root & "\Vefeyat\WordVBA\people.csv"
End Function

Private Function VefeyatEnsureData() As Boolean
    Dim fso As Object, catalogPath As String
    On Error GoTo Failed
    catalogPath = VefeyatDataPath()
    Set fso = CreateObject("Scripting.FileSystemObject")
    If Not fso.FileExists(catalogPath) Then
        If Not VfImportCatalog(False) Then Exit Function
    End If
    If mVfRows Is Nothing Then VfLoadCache catalogPath
    VefeyatEnsureData = True
    Exit Function
Failed:
    VfMessage VfText("Veriler a\u00e7\u0131lamad\u0131: ") & Err.Description, vbExclamation, "Vefeyat"
End Function

Private Sub VefeyatChooseData()
    On Error GoTo Failed
    If VfImportCatalog(True) Then
        ' A new import is loaded lazily; no old search index survives it.
        Set mVfRows = Nothing
        mVfIndexReady = False
    End If
    Exit Sub
Failed:
    VfMessage VfText("CSV al\u0131namad\u0131: ") & Err.Description, vbExclamation, "Vefeyat"
End Sub

Private Function VefeyatRecordCount() As Long
    If VefeyatEnsureData() Then VefeyatRecordCount = mVfRows.Count
End Function

Private Function VefeyatFind(ByVal query As String, Optional ByVal includeDescriptions As Boolean = True) As Collection
    Dim result As New Collection
    Dim order() As Long, ranks() As Long, found As Long, position As Long, rank As Long
    Dim term As String, compact As String, row As Variant
    Dim i As Long, j As Long, score As Long, best As Long
    Set VefeyatFind = result
    If Not VefeyatEnsureData() Then Exit Function
    term = VefeyatNormalize(query)
    If Len(term) = 0 Then Exit Function
    compact = Replace(term, " ", "")
    If Not mVfIndexReady Then VfBuildIndex
    If mVfRows.Count = 0 Then Exit Function
    ReDim order(1 To mVfRows.Count)
    ReDim ranks(1 To mVfRows.Count)
    For i = 1 To mVfRows.Count
        best = 0
        For j = 0 To 2
            score = VfNameMatch(mVfNameText(i, j), mVfNameKeys(i, j), term, compact)
            If score > best Then best = score
        Next j
        row = mVfRows.Item(i)
        rank = 0
        If best > 0 Then
            rank = best * 1000 + VfProminence(row, compact)
        ElseIf includeDescriptions Then
            If VfContainsTokens(mVfSearchText(i), term) Then rank = 1
        End If
        If rank > 0 Then
            found = found + 1
            position = found
            Do While position > 1
                If ranks(position - 1) >= rank Then Exit Do
                ranks(position) = ranks(position - 1)
                order(position) = order(position - 1)
                position = position - 1
            Loop
            ranks(position) = rank
            order(position) = i
        End If
    Next i
    For i = 1 To found
        result.Add mVfRows.Item(order(i))
    Next i
End Function

' Compare each name separately. A compact key also joins words separated by
' apostrophes, dashes or spaces, without changing the selected document text.
Private Function VefeyatNameMatch(ByVal name As String, ByVal query As String) As Long
    Dim term As String, normalizedName As String
    term = VefeyatNormalize(query)
    normalizedName = VefeyatNormalize(name)
    VefeyatNameMatch = VfNameMatch(normalizedName, Replace(normalizedName, " ", ""), _
                                  term, Replace(term, " ", ""))
End Function

Private Function VfNameMatch(ByVal name As String, ByVal compactName As String, _
                             ByVal term As String, ByVal compactTerm As String) As Long
    If Len(term) = 0 Or Len(name) = 0 Or Len(compactTerm) = 0 Then Exit Function
    If name = term Then
        VfNameMatch = 4
    ElseIf compactName = compactTerm Then
        VfNameMatch = 3
    ElseIf VfContainsTokens(name, term) Then
        VfNameMatch = 2
    ElseIf InStr(1, compactName, compactTerm, vbBinaryCompare) > 0 Then
        VfNameMatch = 1
    ElseIf VfSpellingMatch(name, compactName, compactTerm) Then
        VfNameMatch = 1
    End If
End Function

Private Function VfCollapseLetters(ByVal value As String) As String
    Dim i As Long, previous As String, ch As String, result As String
    For i = 1 To Len(value)
        ch = Mid$(value, i, 1)
        If ch <> previous Then result = result & ch
        previous = ch
    Next i
    VfCollapseLetters = result
End Function

Private Function VfSpellingMatch(ByVal name As String, ByVal compactName As String, ByVal term As String) As Boolean
    Dim token As Variant, folded As String, limit As Long
    If Len(term) < 5 Or Len(term) > 80 Then Exit Function
    folded = VfCollapseLetters(term)
    If InStr(1, VfCollapseLetters(compactName), folded, vbBinaryCompare) > 0 Then
        VfSpellingMatch = True
        Exit Function
    End If
    limit = 1
    If Len(term) >= 9 Then limit = 2
    If VfNearWord(compactName, term, limit) Then
        VfSpellingMatch = True
        Exit Function
    End If
    For Each token In Split(name, " ")
        If VfNearWord(CStr(token), term, limit) Then
            VfSpellingMatch = True
            Exit Function
        End If
    Next token
End Function

Private Function VfNearWord(ByVal word As String, ByVal term As String, ByVal limit As Long) As Boolean
    Dim previous() As Long, current() As Long, i As Long, j As Long
    Dim best As Long, cost As Long, value As Long
    If Abs(Len(word) - Len(term)) > limit Or Len(word) = 0 Then Exit Function
    ReDim previous(0 To Len(term))
    ReDim current(0 To Len(term))
    For j = 0 To Len(term): previous(j) = j: Next j
    For i = 1 To Len(word)
        current(0) = i
        best = i
        For j = 1 To Len(term)
            cost = 1
            If Mid$(word, i, 1) = Mid$(term, j, 1) Then cost = 0
            value = previous(j) + 1
            If current(j - 1) + 1 < value Then value = current(j - 1) + 1
            If previous(j - 1) + cost < value Then value = previous(j - 1) + cost
            current(j) = value
            If value < best Then best = value
        Next j
        If best > limit Then Exit Function
        For j = 0 To Len(term): previous(j) = current(j): Next j
    Next i
    VfNearWord = (current(Len(term)) <= limit)
End Function

' Explicit common-name priorities, not measured global fame statistics.
' They apply only to the ambiguous short query, never to an explicit full name.
Private Function VfProminence(ByRef row As Variant, ByVal query As String) As Long
    Dim shortName As String, fullName As String, preferred As String
    shortName = VefeyatNormalize(CStr(row(0)))
    fullName = VefeyatNormalize(CStr(row(1)))
    Select Case VfCollapseLetters(query)
        Case "razi": preferred = "fahreddin er razi"
        Case "gazali": preferred = "gazzali"
        Case "buhari": preferred = "buhari muhammed b ismail"
        Case "muslim": preferred = "muslim b haccac"
        Case "taberi": preferred = "taberi muhammed b cerir"
    End Select
    If Len(preferred) > 0 And shortName = preferred Then VfProminence = 5000
    If shortName = query Then VfProminence = VfProminence + 100
End Function

Private Function VfContainsTokens(ByVal name As String, ByVal term As String) As Boolean
    Dim token As Variant
    If Len(term) = 0 Then Exit Function
    For Each token In Split(term, " ")
        If InStr(1, name, CStr(token), vbBinaryCompare) = 0 Then Exit Function
    Next token
    VfContainsTokens = True
End Function

Private Function VefeyatNormalize(ByVal text As String) As String
    Dim i As Long, code As Long, ch As String, result As String
    Dim pendingSpace As Boolean
    ' Fold Turkish I before lowercasing to avoid locale-specific results.
    text = Replace(text, ChrW(&H130), "i")
    text = Replace(text, ChrW(&H131), "i")
    text = Replace(text, "I", "i")
    text = LCase$(text)
    text = VfFoldLetters(text, "\u00e0\u00e1\u00e2\u00e3\u00e4\u00e5\u0101\u0103\u0105\u01ce", "a")
    text = VfFoldLetters(text, "\u00e7\u0107\u0109\u010b\u010d", "c")
    text = VfFoldLetters(text, "\u010f\u0111\u1e0d", "d")
    text = VfFoldLetters(text, "\u00e8\u00e9\u00ea\u00eb\u0113\u0115\u0117\u0119\u011b", "e")
    text = VfFoldLetters(text, "\u011d\u011f\u0121\u0123\u1e21", "g")
    text = VfFoldLetters(text, "\u0125\u0127\u1e25", "h")
    text = VfFoldLetters(text, "\u00ec\u00ed\u00ee\u00ef\u0129\u012b\u012d\u012f\u01d0", "i")
    text = VfFoldLetters(text, "\u0135", "j")
    text = VfFoldLetters(text, "\u0137\u1e33", "k")
    text = VfFoldLetters(text, "\u013a\u013c\u013e\u0142", "l")
    text = VfFoldLetters(text, "\u00f1\u0144\u0146\u0148\u1e45\u1e47", "n")
    text = VfFoldLetters(text, "\u00f2\u00f3\u00f4\u00f5\u00f6\u00f8\u014d\u014f\u0151\u01d2", "o")
    text = VfFoldLetters(text, "\u0155\u0157\u0159\u1e5b", "r")
    text = VfFoldLetters(text, "\u015b\u015d\u015f\u0161\u1e63", "s")
    text = VfFoldLetters(text, "\u0163\u0165\u0167\u1e6d", "t")
    text = VfFoldLetters(text, "\u00f9\u00fa\u00fb\u00fc\u0169\u016b\u016d\u016f\u0171\u0173\u01d4", "u")
    text = VfFoldLetters(text, "\u00fd\u00ff\u0177", "y")
    text = VfFoldLetters(text, "\u017a\u017c\u017e\u1e93", "z")
    text = Replace(text, ChrW(&HE6), "ae")
    text = Replace(text, ChrW(&H153), "oe")
    text = Replace(text, ChrW(&HDF), "ss")
    For i = 1 To Len(text)
        ch = Mid$(text, i, 1)
        code = AscW(ch)
        If code < 0 Then code = code + 65536
        If (code >= &H300 And code <= &H36F) Or (code >= &H64B And code <= &H65F) Then
            ' Combining accents and Arabic vocalization marks are not search terms.
        ElseIf VfIsSeparator(code) Then
            If Len(result) > 0 Then pendingSpace = True
        Else
            If pendingSpace Then result = result & " "
            result = result & ch
            pendingSpace = False
        End If
    Next i
    result = " " & result & " "
    Do While InStr(1, result, " ibni ", vbBinaryCompare) > 0
        result = Replace(result, " ibni ", " ibn ")
    Loop
    VefeyatNormalize = Trim$(result)
End Function

Private Function VfFoldLetters(ByVal text As String, ByVal escaped As String, ByVal plain As String) As String
    Dim letters As String, i As Long
    letters = VfText(escaped)
    For i = 1 To Len(letters)
        text = Replace(text, Mid$(letters, i, 1), plain)
    Next i
    VfFoldLetters = text
End Function

Private Function VfIsSeparator(ByVal code As Long) As Boolean
    If code <= 32 Or code = 127 Or code = &HA0 Or code = &HAD Then
        VfIsSeparator = True
    ElseIf code < 128 Then
        VfIsSeparator = Not ((code >= 48 And code <= 57) Or (code >= 97 And code <= 122))
    ElseIf (code >= &H2000 And code <= &H206F) Or (code >= &H2E00 And code <= &H2E7F) Then
        VfIsSeparator = True
    ElseIf code = &H60C Or code = &H61B Or code = &H61F Or code = &H640 Then
        VfIsSeparator = True
    ElseIf code = &HB4 Or code = &H2BB Or code = &H2BC Or code = &H2BE Or code = &H2BF Then
        VfIsSeparator = True
    ElseIf code = &HFEFF& Or code = &H3000 Or code = &HFF0C& Or code = &HFF1B& Then
        VfIsSeparator = True
    End If
End Function

Private Sub VfBuildIndex()
    Dim i As Long, j As Long, row As Variant, combined As String
    If mVfRows.Count = 0 Then
        mVfIndexReady = True
        Exit Sub
    End If
    ReDim mVfSearchText(1 To mVfRows.Count)
    ReDim mVfNameText(1 To mVfRows.Count, 0 To 2)
    ReDim mVfNameKeys(1 To mVfRows.Count, 0 To 2)
    For i = 1 To mVfRows.Count
        row = mVfRows.Item(i)
        For j = 0 To 2
            mVfNameText(i, j) = VefeyatNormalize(CStr(row(j)))
            mVfNameKeys(i, j) = Replace(mVfNameText(i, j), " ", "")
        Next j
        combined = CStr(row(0)) & " " & CStr(row(1)) & " " & CStr(row(2))
        combined = combined & " " & CStr(row(3)) & " " & CStr(row(4))
        mVfSearchText(i) = VefeyatNormalize(combined)
    Next i
    mVfIndexReady = True
End Sub

Private Sub VfLoadCache(ByVal path As String)
    Dim loaded As Collection
    Set loaded = VfReadCatalog(path)
    Set mVfRows = loaded
    mVfIndexReady = False
End Sub

Private Function VfImportCatalog(ByVal showSuccess As Boolean) As Boolean
    Dim dialog As Object, fso As Object, selectedPath As String
    Dim currentPath As String, folderPath As String, stagePath As String, backupPath As String
    Dim parsed As Collection, stagedRows As Collection
    Dim existed As Boolean, removedCurrent As Boolean, committed As Boolean
    Dim errorText As String, errorNumber As Long, restored As Boolean
    Set dialog = Application.FileDialog(3)
    With dialog
        .Title = VfText("Vefey\u00e2t: bilgisayar\u0131n\u0131zdaki CSV dosyas\u0131n\u0131 se\u00e7in")
        .AllowMultiSelect = False
        .Filters.Clear
        .Filters.Add "CSV", "*.csv"
        If .Show <> -1 Then Exit Function
        selectedPath = CStr(.SelectedItems(1))
    End With
    VfCheckLocalPath selectedPath
    Set fso = CreateObject("Scripting.FileSystemObject")
    currentPath = VefeyatDataPath()
    Set parsed = VfReadCatalog(selectedPath)
    If StrComp(fso.GetAbsolutePathName(selectedPath), currentPath, vbTextCompare) = 0 Then
        Set mVfRows = Nothing
        mVfIndexReady = False
        VfImportCatalog = True
        Exit Function
    End If
    existed = fso.FileExists(currentPath)
    If existed Then
        If VfMessage(VfText("Yerel veri kopyas\u0131 se\u00e7ti\u011finiz CSV ile de\u011fi\u015ftirilsin mi?") & _
            vbCrLf & VfText("Mevcut kopya ayn\u0131 klas\u00f6re yedeklenecek. Kaynak CSV de\u011fi\u015fmez."), _
            vbQuestion Or vbYesNo Or vbDefaultButton2, "Vefeyat") <> vbYes Then Exit Function
    End If
    On Error GoTo Failed
    folderPath = fso.GetParentFolderName(currentPath)
    VfEnsureFolder folderPath, fso
    stagePath = VfUniquePath(folderPath, "incoming-", ".tmp", fso)
    fso.CopyFile selectedPath, stagePath, False
    ' Validate the actual staged copy as well, before touching current data.
    Set stagedRows = VfReadCatalog(stagePath)
    If existed Then
        backupPath = VfUniquePath(folderPath, "people-backup-", ".csv", fso)
        fso.CopyFile currentPath, backupPath, False
        Kill currentPath
        removedCurrent = True
    End If
    fso.MoveFile stagePath, currentPath
    committed = True
    Set mVfRows = Nothing
    mVfIndexReady = False
    VfImportCatalog = True
    If showSuccess Then
        VfMessage CStr(stagedRows.Count) & VfText(" kay\u0131t al\u0131nd\u0131.") & vbCrLf & currentPath, _
            vbInformation, "Vefeyat"
    End If
    Exit Function
Failed:
    errorNumber = Err.Number
    errorText = Err.Description
    On Error Resume Next
    If removedCurrent And Not committed Then
        Err.Clear
        fso.CopyFile backupPath, currentPath, True
        restored = (Err.Number = 0)
    End If
    If Len(stagePath) > 0 Then
        If fso.FileExists(stagePath) Then fso.DeleteFile stagePath, True
    End If
    On Error GoTo 0
    If removedCurrent And Not committed And Not restored Then
        errorText = errorText & vbCrLf & "Restore the retained backup: " & backupPath
    End If
    Err.Raise errorNumber, "VefeyatData", errorText
End Function

Private Sub VfCheckLocalPath(ByVal path As String)
    Dim fso As Object, drive As Object
    ' Reject network/URL paths. Imported source data must be on a local drive.
    If Len(path) < 3 Then VfFail "Choose a CSV file on a local Windows drive."
    If Mid$(path, 2, 2) <> ":\" Then VfFail "Choose a CSV file on a local Windows drive."
    If InStr(1, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", UCase$(Left$(path, 1)), vbBinaryCompare) = 0 Then
        VfFail "Choose a CSV file on a local Windows drive."
    End If
    Set fso = CreateObject("Scripting.FileSystemObject")
    Set drive = fso.GetDrive(Left$(path, 2))
    If drive.DriveType = 3 Then VfFail "A network drive cannot hold the local catalog."
End Sub

Private Sub VfEnsureFolder(ByVal path As String, ByVal fso As Object)
    Dim parent As String
    If fso.FolderExists(path) Then Exit Sub
    parent = fso.GetParentFolderName(path)
    If Len(parent) = 0 Or parent = path Then VfFail "Cannot create the local data folder."
    If Not fso.FolderExists(parent) Then VfEnsureFolder parent, fso
    MkDir path
End Sub

Private Function VfUniquePath(ByVal folder As String, ByVal prefix As String, ByVal suffix As String, ByVal fso As Object) As String
    Dim candidate As String
    Do
        mVfUniqueCounter = mVfUniqueCounter + 1
        candidate = folder & "\" & prefix & Format$(Now, "yyyymmdd-hhnnss") & "-" & CStr(mVfUniqueCounter) & suffix
    Loop While fso.FileExists(candidate) Or fso.FolderExists(candidate)
    VfUniquePath = candidate
End Function

Private Function VfReadCatalog(ByVal path As String) As Collection
    Dim stream As Object, content As String, errorText As String, errorNumber As Long
    On Error GoTo Failed
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 2
    stream.Charset = "utf-8"
    stream.Open
    stream.LoadFromFile path
    content = stream.ReadText(-1)
    stream.Close
    Set stream = Nothing
    If Len(content) > 0 Then
        If Left$(content, 1) = ChrW(&HFEFF) Then content = Mid$(content, 2)
    End If
    Set VfReadCatalog = VfParseCsv(content)
    Exit Function
Failed:
    errorNumber = Err.Number
    errorText = Err.Description
    On Error Resume Next
    If Not stream Is Nothing Then stream.Close
    On Error GoTo 0
    Err.Raise errorNumber, "VefeyatData", errorText
End Function

Private Function VfParseCsv(ByVal content As String) As Collection
    Dim rows As New Collection, fields As New Collection
    Dim fieldValue As String, ch As String, state As Long
    Dim i As Long, lineNumber As Long, recordLine As Long
    Dim recordStarted As Boolean, haveHeader As Boolean
    lineNumber = 1
    recordLine = 1
    i = 1
    Do While i <= Len(content)
        ch = Mid$(content, i, 1)
        If state = 1 Then
            If ch = """" Then
                If Mid$(content, i + 1, 1) = """" Then
                    fieldValue = fieldValue & """"
                    i = i + 1
                Else
                    state = 2
                End If
            Else
                fieldValue = fieldValue & ch
                If ch = vbLf Then lineNumber = lineNumber + 1
            End If
        Else
            If state = 2 And ch <> ";" And ch <> vbCr And ch <> vbLf Then
                VfCsvFail lineNumber, "Unexpected text after a closing quote."
            End If
            Select Case ch
                Case """"
                    If Len(fieldValue) <> 0 Then VfCsvFail lineNumber, "Quote inside an unquoted field."
                    state = 1
                    recordStarted = True
                Case ";"
                    fields.Add fieldValue
                    fieldValue = ""
                    state = 0
                    recordStarted = True
                Case vbCr, vbLf
                    If recordStarted Or fields.Count > 0 Then
                        fields.Add fieldValue
                        VfAppendCsvRecord rows, fields, haveHeader, recordLine
                    End If
                    Set fields = New Collection
                    fieldValue = ""
                    state = 0
                    recordStarted = False
                    If ch = vbCr And Mid$(content, i + 1, 1) = vbLf Then i = i + 1
                    lineNumber = lineNumber + 1
                    recordLine = lineNumber
                Case Else
                    fieldValue = fieldValue & ch
                    recordStarted = True
            End Select
        End If
        i = i + 1
    Loop
    If state = 1 Then VfCsvFail recordLine, "Unclosed quoted field."
    If recordStarted Or fields.Count > 0 Then
        fields.Add fieldValue
        VfAppendCsvRecord rows, fields, haveHeader, recordLine
    End If
    If Not haveHeader Then VfFail "The CSV file has no header."
    If rows.Count = 0 Then VfFail "The CSV file contains no people."
    Set VfParseCsv = rows
End Function

Private Sub VfAppendCsvRecord(ByVal rows As Collection, ByVal fields As Collection, ByRef haveHeader As Boolean, ByVal lineNumber As Long)
    Dim expected As Variant, row As Variant, i As Long
    If fields.Count <> 6 Then VfCsvFail lineNumber, "Expected exactly six semicolon-separated columns."
    If Not haveHeader Then
        expected = Array(VfText("K\u0131sa Ad"), "Tam Ad", "Orijinal Ad", "Vefat Tarihi", VfText("Tan\u0131t\u0131m"), "Kaynak Link")
        For i = 0 To 5
            If StrComp(CStr(fields.Item(i + 1)), CStr(expected(i)), vbBinaryCompare) <> 0 Then
                VfCsvFail lineNumber, "The six CSV headers do not match the expected catalog format."
            End If
        Next i
        haveHeader = True
        Exit Sub
    End If
    row = Array("", "", "", "", "", "")
    For i = 0 To 5
        row(i) = Trim$(CStr(fields.Item(i + 1)))
        If row(i) = "---" Then row(i) = ""
    Next i
    If Len(CStr(row(0))) = 0 Then VfCsvFail lineNumber, "A short name is required."
    rows.Add row
End Sub

Private Sub VfCsvFail(ByVal lineNumber As Long, ByVal message As String)
    VfFail "CSV line " & CStr(lineNumber) & ": " & message
End Sub

Private Sub VfFail(ByVal message As String)
    Err.Raise vbObjectError + 2141, "VefeyatData", message
End Sub

Private Function VfpFormatDate(ByVal raw As String, ByVal prefix As String) As String
    Dim key As String
    Dim markerStart As Long
    Dim markerLength As Long
    Dim replacement As String

    key = VfpRequirePrefix(prefix)
    VfpFormatDate = raw
    If key = "original" Or Len(raw) = 0 Then Exit Function

    markerStart = VfpSkipSpaces(raw, 1)
    If markerStart > Len(raw) Then Exit Function
    If Mid$(raw, markerStart, 1) = "(" Then
        markerStart = VfpSkipSpaces(raw, markerStart + 1)
    End If
    markerLength = VfpMarkerLength(raw, markerStart)
    If markerLength = 0 Then Exit Function

    Select Case key
        Case "o": replacement = VfText("\u00f6.")
        Case "ol": replacement = VfText("\u00f6l.")
        Case "v": replacement = "v."
    End Select
    VfpFormatDate = Left$(raw, markerStart - 1) & replacement & _
                    Mid$(raw, markerStart + markerLength)
End Function

' Settings belong to this Word document. Reading an absent or old invalid
' value returns a default without writing to the document or the registry.
Private Function VfpGetPrefix(ByVal doc As Word.Document) As String
    Dim key As String
    key = VfpNormalizeKey(VfpReadVariable(doc, VfpPrefixVariable))
    If Not VfpKnownPrefix(key) Then key = "original"
    VfpGetPrefix = key
End Function

Private Sub VfpSetPrefix(ByVal doc As Word.Document, ByVal value As String)
    Dim key As String
    key = VfpRequirePrefix(value)
    VfpWriteVariable doc, VfpPrefixVariable, key
End Sub

Private Function VfpGetScope(ByVal doc As Word.Document) As String
    Dim key As String
    key = VfpNormalizeKey(VfpReadVariable(doc, VfpScopeVariable))
    If Not VfpKnownScope(key) Then key = "first"
    VfpGetScope = key
End Function

Private Sub VfpSetScope(ByVal doc As Word.Document, ByVal value As String)
    Dim key As String
    key = VfpNormalizeKey(value)
    If Not VfpKnownScope(key) Then
        Err.Raise VfpInvalidSetting, "VefeyatPolicy", "Unknown occurrence scope."
    End If
    VfpWriteVariable doc, VfpScopeVariable, key
End Sub

' A length-prefixed identity avoids delimiter and hash collisions. The CSV
' has no ID column; rows with the same URL and all three names share an ID.
' Dates and descriptions are deliberately excluded so a correction to them
' does not change the identity. This key is not used as a variable name.
Private Function VfpPersonKey(ByRef row As Variant) As String
    VfpPersonKey = "Vfp1:" & VfpKeyPart(CStr(row(5))) & _
                   VfpKeyPart(CStr(row(0))) & VfpKeyPart(CStr(row(1))) & _
                   VfpKeyPart(CStr(row(2)))
End Function

Private Function VfpKeyPart(ByVal value As String) As String
    VfpKeyPart = CStr(Len(value)) & ":" & value
End Function

Private Function VfpRequirePrefix(ByVal value As String) As String
    Dim key As String
    key = VfpNormalizeKey(value)
    If Not VfpKnownPrefix(key) Then
        Err.Raise VfpInvalidSetting, "VefeyatPolicy", "Unknown death-date prefix."
    End If
    VfpRequirePrefix = key
End Function

Private Function VfpNormalizeKey(ByVal value As String) As String
    VfpNormalizeKey = LCase$(Trim$(value))
End Function

Private Function VfpKnownPrefix(ByVal key As String) As Boolean
    Select Case key
        Case "original", "o", "ol", "v": VfpKnownPrefix = True
    End Select
End Function

Private Function VfpKnownScope(ByVal key As String) As Boolean
    Select Case key
        Case "first", "all": VfpKnownScope = True
    End Select
End Function

Private Function VfpReadVariable(ByVal doc As Word.Document, ByVal name As String) As String
    Dim item As Word.Variable
    If doc Is Nothing Then
        Err.Raise VfpInvalidDocument, "VefeyatPolicy", "A Word document is required."
    End If
    ' A missing Word document variable can return a proxy whose Value raises
    ' 5825 (object deleted). Read only items present in the collection.
    For Each item In doc.Variables
        If StrComp(item.Name, name, vbTextCompare) = 0 Then
            VfpReadVariable = item.Value
            Exit Function
        End If
    Next item
End Function

Private Sub VfpWriteVariable(ByVal doc As Word.Document, ByVal name As String, _
                             ByVal value As String)
    Dim item As Word.Variable
    If doc Is Nothing Then
        Err.Raise VfpInvalidDocument, "VefeyatPolicy", "A Word document is required."
    End If
    For Each item In doc.Variables
        If StrComp(item.Name, name, vbTextCompare) = 0 Then
            item.Value = value
            Exit Sub
        End If
    Next item
    doc.Variables.Add Name:=name, Value:=value
End Sub

Private Function VfpSkipSpaces(ByVal value As String, ByVal start As Long) As Long
    Do While start <= Len(value)
        If Not VfpIsSpace(Mid$(value, start, 1)) Then Exit Do
        start = start + 1
    Loop
    VfpSkipSpaces = start
End Function

Private Function VfpIsSpace(ByVal value As String) As Boolean
    If Len(value) <> 1 Then Exit Function
    Select Case AscW(value)
        Case 9, 10, 13, 32, 160, 8199, 8239: VfpIsSpace = True
    End Select
End Function

Private Function VfpMarkerLength(ByVal value As String, ByVal start As Long) As Long
    Dim candidate As String
    Dim length As Long
    If start < 1 Or start > Len(value) Then Exit Function
    candidate = LCase$(Mid$(value, start, 3))
    candidate = Replace(candidate, VfText("\u00d6"), VfText("\u00f6"))
    If Left$(candidate, 3) = VfText("\u00f6l.") Then
        length = 3
    ElseIf Left$(candidate, 2) = VfText("\u00f6.") Or Left$(candidate, 2) = "v." Then
        length = 2
    Else
        Exit Function
    End If
    If VfpMarkerBoundary(value, start + length) Then VfpMarkerLength = length
End Function

Private Function VfpMarkerBoundary(ByVal value As String, ByVal nextIndex As Long) As Boolean
    Dim nextChar As String
    If nextIndex > Len(value) Then Exit Function
    nextChar = Mid$(value, nextIndex, 1)
    If VfpIsSpace(nextChar) Then
        VfpMarkerBoundary = True
    ElseIf nextChar >= "0" And nextChar <= "9" Then
        VfpMarkerBoundary = True
    ElseIf nextChar = "?" Then
        VfpMarkerBoundary = True
    End If
End Function

' Explicitly invoked only. These checks never create or modify a document.
' The return value is the number of successful pure helper assertions.
Private Function VfpRunPolicyChecks() As Long
    Dim count As Long
    Dim raw As String
    Dim rowA As Variant
    Dim rowB As Variant
    Dim formatted As String
    Dim errorNumber As Long

    raw = VfText("  (\u00f6.  680/1282) ")
    VfpCheck VfpFormatDate(raw, "original") = raw, "Original bytes", count
    VfpCheck VfpFormatDate(raw, "ol") = VfText("  (\u00f6l.  680/1282) "), "Spaces", count
    VfpCheck VfpFormatDate(raw, "v") = "  (v.  680/1282) ", "V prefix", count
    VfpCheck VfpFormatDate(VfText("(\u00f6l. 680/1282)"), "o") = _
             VfText("(\u00f6. 680/1282)"), "Long marker", count
    VfpCheck VfpFormatDate("(v. 680/1282)", "o") = _
             VfText("(\u00f6. 680/1282)"), "V marker", count
    VfpCheck VfpFormatDate(VfText("(\u00d6L. 680/1282)"), "v") = _
             "(v. 680/1282)", "Uppercase marker", count
    VfpCheck VfpFormatDate(VfText("\u00f6.680/1282"), "v") = "v.680/1282", _
             "Adjacent year", count
    VfpCheck VfpFormatDate("(v. ?)", "ol") = VfText("(\u00f6l. ?)"), "Uncertainty", count
    VfpCheck VfpFormatDate("(1844-1921)", "ol") = "(1844-1921)", "Lifespan", count
    raw = VfText("(m.\u00f6. 384-322)")
    VfpCheck VfpFormatDate(raw, "v") = raw, "BC expression", count
    raw = VfText("(M.\u00d6. 384-322)")
    VfpCheck VfpFormatDate(raw, "o") = raw, "Uppercase BC", count
    raw = "(gaybeti 260/874)"
    VfpCheck VfpFormatDate(raw, "ol") = raw, "Other event", count
    raw = "(tarih bilinmiyor)"
    VfpCheck VfpFormatDate(raw, "o") = raw, "Unknown expression", count
    raw = VfText("\u00d6zt\u00fcrk")
    VfpCheck VfpFormatDate(raw, "v") = raw, "Name substring", count
    raw = VfText("(\u00f6.zt\u00fcrk)")
    VfpCheck VfpFormatDate(raw, "v") = raw, "Marker boundary", count
    raw = VfText("(not: \u00f6. 680/1282)")
    VfpCheck VfpFormatDate(raw, "v") = raw, "Nonleading marker", count
    raw = VfText("(\u00f6. 680/1282; kaynak: \u00f6. 681)")
    VfpCheck VfpFormatDate(raw, "v") = _
             VfText("(v. 680/1282; kaynak: \u00f6. 681)"), "Only leading marker", count
    raw = VfText("\u00a0(\u00a0\u00f6.\u00a0680/1282)")
    VfpCheck VfpFormatDate(raw, "v") = _
             VfText("\u00a0(\u00a0v.\u00a0680/1282)"), "Unicode spaces", count
    VfpCheck VfpFormatDate("", "o") = "", "Empty expression", count
    VfpCheck VfpFormatDate("v.", "ol") = "v.", "Bare marker", count
    VfpCheck VfpFormatDate("(V. 680/1282)", " OL ") = _
             VfText("(\u00f6l. 680/1282)"), "Normalized setting", count
    On Error Resume Next
    formatted = VfpFormatDate("(v. 680)", "")
    errorNumber = Err.Number
    On Error GoTo 0
    VfpCheck errorNumber = VfpInvalidSetting, "Blank prefix rejected", count
    On Error Resume Next
    formatted = VfpFormatDate("(v. 680)", "invalid")
    errorNumber = Err.Number
    On Error GoTo 0
    VfpCheck errorNumber = VfpInvalidSetting, "Unknown prefix rejected", count
    VfpCheck VfpKnownScope("first") And VfpKnownScope("all"), "Known scopes", count
    VfpCheck Not VfpKnownScope("") And Not VfpKnownScope("selection"), "Unknown scopes", count
    rowA = Array("A:B", "C", "", "old date", "description", "url")
    rowB = Array("A", "B:C", "", "old date", "description", "url")
    VfpCheck VfpPersonKey(rowA) <> VfpPersonKey(rowB), "Identity delimiters", count
    rowB = Array("A:B", "C", "", "new date", "new description", "url")
    VfpCheck VfpPersonKey(rowA) = VfpPersonKey(rowB), "Stable metadata identity", count
    rowB = Array("A:B", "C", "", "old date", "description", "other url")
    VfpCheck VfpPersonKey(rowA) <> VfpPersonKey(rowB), "Source identity", count
    VfpRunPolicyChecks = count
    Debug.Print "Vefeyat policy checks passed: " & CStr(count)
End Function

Private Sub VfpCheck(ByVal passed As Boolean, ByVal description As String, ByRef count As Long)
    If Not passed Then
        Err.Raise VfpCheckFailure, "VefeyatPolicy", "Policy check failed: " & description
    End If
    count = count + 1
End Sub

Private Function VfaCanInsert() As Boolean
    Dim targetDoc As Word.Document
    Dim selectedText As String, aliasText As String
    On Error GoTo Unavailable
    If Application.Documents.Count = 0 Then Exit Function
    Set targetDoc = ActiveDocument
    If targetDoc.ReadOnly Then Exit Function
    If targetDoc.ProtectionType <> wdNoProtection Then Exit Function
    If Selection.Type <> wdSelectionNormal Then Exit Function
    If Not VfaSupportedRange(targetDoc, Selection.Range) Then Exit Function
    selectedText = Selection.Range.Text
    If Not VfaSelectionAlias(selectedText, aliasText) Then Exit Function
    VfaCanInsert = True
Unavailable:
End Function

Private Sub VfaInsertSelected()
    Dim targetDoc As Word.Document
    Dim targetRange As Word.Range
    Dim originalText As String, aliasText As String, reason As String
    Dim originalStart As Long, originalEnd As Long, originalStory As Long
    Dim candidates As Collection
    Dim row As Variant, chosen As Long, bindingId As String
    Dim undoObject As Object, undoStarted As Boolean, changed As Boolean
    Dim inserted As Long, skipped As Long, failure As String

    On Error GoTo Failed
    If Not VfaCapture(targetDoc, targetRange, originalText, aliasText, _
                      originalStart, originalEnd, originalStory) Then Exit Sub
    If Not VefeyatEnsureData() Then Exit Sub
    Set candidates = VefeyatFind(aliasText, False)
    Set candidates = VfaConfirmationCandidates(candidates, aliasText)
    If candidates.Count = 0 Then
        VfaWarn VfText("Se\u00e7ili adla e\u015fle\u015fen bir \u015fah\u0131s bulunamad\u0131. Ad\u0131n yaz\u0131m\u0131n\u0131 ve se\u00e7ili CSV dosyas\u0131n\u0131 kontrol edin.")
        Exit Sub
    End If
    ' Every insertion requires confirmation, including a single exact match.
    chosen = VfePickPerson(candidates, aliasText)
    If chosen = 0 Then Exit Sub
    If chosen < 1 Or chosen > candidates.Count Then Exit Sub
    row = candidates.Item(chosen)
    If Not VfaValidDate(CStr(row(3))) Then
        VfaWarn VfText("Bu kay\u0131ttaki \u00f6l\u00fcm tarihi bo\u015f veya tek sat\u0131rl\u0131k tarih olarak kullan\u0131lam\u0131yor. Belgeye eklenmedi.")
        Exit Sub
    End If
    If Not VfaTargetCurrent(targetDoc, targetRange, originalText, originalStart, _
                            originalEnd, originalStory, reason) Then
        VfaWarn reason
        Exit Sub
    End If

    undoStarted = VfaBeginUndo(undoObject)
    VfaEnsureNamespace targetDoc, changed
    bindingId = VfaGetBinding(targetDoc, row, aliasText, changed)
    ' An explicit new choice for this spelling replaces its previous person.
    VfaRetireOtherBindings targetDoc, bindingId, aliasText, changed
    VfaApplyBinding targetDoc, bindingId, aliasText, CStr(row(3)), _
                    inserted, skipped, changed
    VfaEndUndo undoObject, undoStarted
    If inserted = 0 And skipped > 0 Then
        VfaWarn VfText("Bu yaz\u0131m\u0131n uygulanacak yerinde \u00f6l\u00fcm tarihi zaten var. Elle yaz\u0131lm\u0131\u015f tarihe dokunulmad\u0131.")
    ElseIf inserted = 0 Then
        VfaWarn VfText("Se\u00e7ili yaz\u0131m ana metinde veya dipnotlarda tam s\u00f6zc\u00fck olarak bulunamad\u0131. Ad\u0131n tamam\u0131n\u0131 se\u00e7ip yeniden deneyin.")
    Else
        Application.StatusBar = CStr(inserted) & VfText(" Vefey\u00e2t tarihi eklendi.")
    End If
    Exit Sub
Failed:
    failure = Err.Description
    VfaEndUndo undoObject, undoStarted
    VfaReportFailure failure, changed
End Sub

' Called only by an explicit user command or a Ribbon setting change.
' Stored original dates make this operation independent of the CSV file.
Private Sub VfaRefreshDocument()
    Dim targetDoc As Word.Document
    Dim bindings As Collection, bindingId As Variant
    Dim aliasText As String, rawDate As String
    Dim undoObject As Object, undoStarted As Boolean, changed As Boolean
    Dim inserted As Long, skipped As Long, failure As String

    On Error GoTo Failed
    If Application.Documents.Count = 0 Then Exit Sub
    Set targetDoc = ActiveDocument
    If Not VfaEditable(targetDoc) Then Exit Sub
    Set bindings = VfaActiveBindingIds(targetDoc)
    If bindings.Count = 0 Then Exit Sub
    undoStarted = VfaBeginUndo(undoObject)
    For Each bindingId In bindings
        aliasText = VfaReadVariable(targetDoc, VfaVariableName(CStr(bindingId), "Alias"))
        rawDate = VfaReadVariable(targetDoc, VfaVariableName(CStr(bindingId), "Raw"))
        If Not VfaValidAlias(aliasText) Or Not VfaValidDate(rawDate) Then
            Err.Raise VfaInvalidData, "VefeyatActions", "Stored date binding is incomplete."
        End If
        VfaApplyBinding targetDoc, CStr(bindingId), aliasText, rawDate, _
                        inserted, skipped, changed
    Next bindingId
    VfaEndUndo undoObject, undoStarted
    Application.StatusBar = VfText("Vefey\u00e2t tarihleri belge ayarlar\u0131na g\u00f6re g\u00fcncellendi.")
    Exit Sub
Failed:
    failure = Err.Description
    VfaEndUndo undoObject, undoStarted
    VfaReportFailure failure, changed
End Sub

Private Function VfaCapture(ByRef targetDoc As Word.Document, ByRef targetRange As Word.Range, _
                            ByRef originalText As String, ByRef aliasText As String, _
                            ByRef originalStart As Long, ByRef originalEnd As Long, _
                            ByRef originalStory As Long) As Boolean
    Dim reason As String
    If Application.Documents.Count = 0 Then
        VfaWarn VfText("Bir Word belgesi a\u00e7\u0131p metindeki \u015fah\u0131s ad\u0131n\u0131 se\u00e7in.")
        Exit Function
    End If
    If Selection.Type <> wdSelectionNormal Then
        VfaWarn VfText("Metindeki tek bir \u015fah\u0131s ad\u0131n\u0131 se\u00e7in.")
        Exit Function
    End If
    Set targetDoc = ActiveDocument
    Set targetRange = Selection.Range.Duplicate
    originalText = targetRange.Text
    originalStart = targetRange.Start
    originalEnd = targetRange.End
    originalStory = targetRange.StoryType
    If Not VfaSupportedRange(targetDoc, targetRange) Then
        VfaWarn VfText("Ana metin veya dipnottaki \u015fah\u0131s ad\u0131n\u0131 se\u00e7in. \u00dcstbilgi, sonnot ve metin kutular\u0131 bu i\u015fleme dahil de\u011fildir.")
        Exit Function
    End If
    If Not VfaSelectionAlias(originalText, aliasText) Then
        VfaWarn VfText("Yaln\u0131zca tek sat\u0131rdaki ad\u0131 se\u00e7in (en fazla 200 karakter). Birden \u00e7ok paragraf\u0131, sekme veya h\u00fccre sonunu se\u00e7ime katmay\u0131n.")
        Exit Function
    End If
    If Not VfaTargetCurrent(targetDoc, targetRange, originalText, originalStart, _
                            originalEnd, originalStory, reason) Then
        VfaWarn reason
        Exit Function
    End If
    VfaCapture = True
End Function

Private Function VfaTargetCurrent(ByVal targetDoc As Word.Document, ByVal targetRange As Word.Range, _
                                  ByVal originalText As String, ByVal originalStart As Long, _
                                  ByVal originalEnd As Long, ByVal originalStory As Long, _
                                  ByRef reason As String) As Boolean
    Dim currentDoc As Word.Document, rangeDoc As Word.Document
    Dim currentRange As Word.Range, aliasText As String
    reason = VfText("Belge veya se\u00e7ili ad de\u011fi\u015fti. Tarih eklenmedi; ad\u0131 yeniden se\u00e7in.")
    If Application.Documents.Count = 0 Then Exit Function
    Set currentDoc = ActiveDocument
    If Not currentDoc Is targetDoc Then Exit Function
    Set rangeDoc = targetRange.Document
    If Not rangeDoc Is targetDoc Then Exit Function
    If Selection.Type <> wdSelectionNormal Then Exit Function
    Set currentRange = Selection.Range.Duplicate
    If Not currentRange.IsEqual(targetRange) Then Exit Function
    If targetRange.Start <> originalStart Or targetRange.End <> originalEnd Then Exit Function
    If Not VfaSupportedRange(targetDoc, targetRange) Then Exit Function
    If targetRange.StoryType <> originalStory Or currentRange.StoryType <> originalStory Then Exit Function
    If StrComp(targetRange.Text, originalText, vbBinaryCompare) <> 0 Then Exit Function
    If StrComp(currentRange.Text, originalText, vbBinaryCompare) <> 0 Then Exit Function
    If Not VfaSelectionAlias(originalText, aliasText) Then Exit Function
    If targetDoc.ReadOnly Then
        reason = VfText("Bu belge salt okunur. Tarih eklenmedi.")
        Exit Function
    End If
    If targetDoc.ProtectionType <> wdNoProtection Then
        reason = VfText("Bu belge d\u00fczenlemeye kar\u015f\u0131 korumal\u0131. Tarih eklenmedi.")
        Exit Function
    End If
    If VfaOverlapsExcluded(targetRange, VfaExcludedRanges(targetDoc, aliasText)) Then
        reason = VfText("Se\u00e7im bir Word alan\u0131, i\u00e7erik denetimi veya Vefey\u00e2t'\u0131n tarih ekledi\u011fi ba\u015fka bir adla \u00e7ak\u0131\u015f\u0131yor. Zotero at\u0131flar\u0131 ve y\u00f6netilen adlar korunur; ana metin veya dipnottaki ad\u0131n tamam\u0131n\u0131 se\u00e7in.")
        Exit Function
    End If
    VfaTargetCurrent = True
End Function

Private Function VfaEditable(ByVal targetDoc As Word.Document) As Boolean
    If targetDoc.ReadOnly Then
        VfaWarn VfText("Bu belge salt okunur. Tarihler g\u00fcncellenmedi.")
        Exit Function
    End If
    If targetDoc.ProtectionType <> wdNoProtection Then
        VfaWarn VfText("Bu belge d\u00fczenlemeye kar\u015f\u0131 korumal\u0131. Tarihler g\u00fcncellenmedi.")
        Exit Function
    End If
    VfaEditable = True
End Function

Private Sub VfaNameCandidates(ByVal candidates As Collection, ByVal query As String, _
                              ByRef exact As Collection, ByRef partial As Collection)
    Dim row As Variant, personKey As String
    Dim i As Long, score As Long, isExact As Boolean, isPartial As Boolean
    Dim exactKeys As New Collection, partialKeys As New Collection
    Set exact = New Collection
    Set partial = New Collection
    For Each row In candidates
        isExact = False
        isPartial = False
        For i = 0 To 2
            score = VefeyatNameMatch(CStr(row(i)), query)
            If score >= 3 Then isExact = True
            If score > 0 Then isPartial = True
        Next i
        personKey = VfpPersonKey(row)
        If isExact Then
            If Not VfaCollectionContains(exactKeys, personKey) Then
                exact.Add row
                exactKeys.Add personKey
            End If
        ElseIf isPartial Then
            If Not VfaCollectionContains(partialKeys, personKey) Then
                partial.Add row
                partialKeys.Add personKey
            End If
        End If
    Next row
End Sub

Private Function VfaConfirmationCandidates(ByVal candidates As Collection, ByVal query As String) As Collection
    Dim result As New Collection, keys As New Collection
    Dim row As Variant, key As String, i As Long, score As Long
    For Each row In candidates
        score = 0
        For i = 0 To 2
            If VefeyatNameMatch(CStr(row(i)), query) > 0 Then score = 1
        Next i
        key = VfpPersonKey(row)
        If score > 0 And Not VfaCollectionContains(keys, key) Then
            result.Add row
            keys.Add key
        End If
    Next row
    Set VfaConfirmationCandidates = result
End Function

Private Function VfaCollectionContains(ByVal values As Collection, ByVal value As String) As Boolean
    Dim item As Variant
    For Each item In values
        If StrComp(CStr(item), value, vbBinaryCompare) = 0 Then
            VfaCollectionContains = True
            Exit Function
        End If
    Next item
End Function

' Pure lookup checks: no Word document, file, catalog, or user interface access.
Private Function VfaRunLookupChecks() As Long
    Dim candidates As Collection, exact As Collection, partial As Collection, confirmed As Collection
    Dim row As Variant, count As Long
    Dim aliasText As String, literalText As String
    Set candidates = New Collection
    candidates.Add Array("Ali", "Ali b. Hasan", "", "(o. 10)", "", "one")
    candidates.Add Array("Alim", "Alim b. Hasan", "", "(o. 20)", "", "two")
    candidates.Add Array("Zeyd", "Zeyd b. Hasan", "", "(o. 30)", "Ali", "three")
    VfaNameCandidates candidates, "Ali", exact, partial
    VfaLookupAssert exact.Count = 1, "Unique exact name", count
    row = exact.Item(1)
    VfaLookupAssert CStr(row(0)) = "Ali", "Exact identity", count
    VfaLookupAssert partial.Count = 1, "Description-only candidate excluded", count
    Set confirmed = VfaConfirmationCandidates(candidates, "Ali")
    VfaLookupAssert confirmed.Count = 2, "Confirmation retains exact and partial alternatives", count
    VfaLookupAssert VefeyatNameMatch("Abaka", "Abaka") = 4, "Exact name rank", count
    VfaLookupAssert VefeyatNameMatch(VfText("K\u0131v\u00e2m\u00fc\u2019s-s\u00fcnne"), _
                                    VfText("K\u0131v\u00e2m\u00fcss\u00fcnne")) = 3, "Joined alias rank", count
    VfaLookupAssert VefeyatNameMatch(VfText("Ebu'l-Kasim K\u0131v\u00e2m\u00fc\u2019s-s\u00fcnne Ismail"), _
                                    VfText("K\u0131v\u00e2m\u00fcss\u00fcnne")) > 0, "Joined alias within full name", count

    Set candidates = New Collection
    candidates.Add Array("Ali", "Ali b. Hasan", "", "(o. 10)", "", "one")
    candidates.Add Array("Ali", "Ali b. Huseyin", "", "(o. 20)", "", "two")
    candidates.Add Array("Ali", "Ali b. Hasan", "", "(o. 11)", "Updated date", "one")
    VfaNameCandidates candidates, "Ali", exact, partial
    VfaLookupAssert exact.Count = 2, "Distinct homonyms remain ambiguous", count
    VfaLookupAssert partial.Count = 0, "Duplicate identity removed", count

    Set candidates = New Collection
    candidates.Add Array(VfText("Gazz\u00e2l\u00ee"), "Abu Hamid", _
                         VfText("\u0627\u0644\u063a\u0632\u0627\u0644\u064a"), "(o. 505)", "", "arabic")
    VfaNameCandidates candidates, "Gazzali", exact, partial
    VfaLookupAssert exact.Count = 1, "Accent-folded name is exact", count
    VfaNameCandidates candidates, VfText("\u0627\u0644\u063a\u0632\u0627\u0644\u064a"), exact, partial
    VfaLookupAssert exact.Count = 1, "Original Arabic name is exact", count

    Set candidates = New Collection
    candidates.Add Array("Ali b. Hasan", "Ali b. Hasan", "", "(o. 10)", "", "one")
    VfaNameCandidates candidates, "Ali", exact, partial
    VfaLookupAssert exact.Count = 0 And partial.Count = 1, "Substring requires a chooser", count
    VfaLookupAssert VfaBindingFromTag("Vefeyat.Date.D0123456789ABCDEF.P1", _
                                    "D0123456789ABCDEF") = "P1", "Local namespace", count
    VfaLookupAssert Len(VfaBindingFromTag("Vefeyat.Date.D0123456789ABCDEF.P1", _
                                        "D1123456789ABCDEF")) = 0, "Foreign namespace rejected", count
    VfaLookupAssert Len(VfaBindingFromTag("Vefeyat.Date.P1", _
                                        "D0123456789ABCDEF")) = 0, "Unnamespaced tag rejected", count
    VfaLookupAssert VfaBindingFromFieldCode(" ADDIN Vefeyat.Date.D0123456789ABCDEF.P1 ", _
                                          "D0123456789ABCDEF") = "P1", "Owned ADDIN field", count
    VfaLookupAssert Len(VfaBindingFromFieldCode(" ADDIN ZOTERO_ITEM CSL_CITATION ", _
                                              "D0123456789ABCDEF")) = 0, "Other add-in field excluded", count
    VfaLookupAssert Len(VfaBindingFromFieldCode(" DOCVARIABLE Vefeyat.Date.D0123456789ABCDEF.P1 ", _
                                              "D0123456789ABCDEF")) = 0, "Other field type excluded", count
    VfaLookupAssert Len(VfaBindingFromFieldCode(" ADDIN Vefeyat.Date.D0123456789ABCDEF.P1 extra ", _
                                              "D0123456789ABCDEF")) = 0, "Extra field code rejected", count
    VfaLookupAssert VfaOrderBefore(10, 0, 0, 20, 1, 5), "Main before later footnote", count
    VfaLookupAssert VfaOrderBefore(20, 1, 5, 21, 0, 0), "Footnote before following main", count
    VfaLookupAssert VfaOrderBefore(20, 0, 0, 20, 1, 1), "Main reference precedes footnote", count
    VfaLookupAssert VfaOrderBefore(20, 1, 3, 20, 1, 9), "Within-footnote order", count
    VfaLookupAssert Not VfaOrderBefore(20, 1, 9, 20, 1, 3), "Reverse note order rejected", count
    VfaLookupAssert Not VfaOrderBefore(20, 1, 3, 20, 1, 3), "Equal order is stable", count
    VfaLookupAssert VfaSelectionAlias("Abaka" & vbCr, aliasText), "Trailing paragraph mark accepted", count
    VfaLookupAssert aliasText = "Abaka", "Paragraph mark excluded from alias", count
    literalText = "Ali" & ChrW$(160) & "  Hasan"
    VfaLookupAssert VfaSelectionAlias(ChrW$(8239) & literalText & ChrW$(8194) & vbCr & ChrW$(12288), _
                                    aliasText), "Unicode edge spaces with paragraph accepted", count
    VfaLookupAssert aliasText = literalText, "Internal Unicode and repeated spaces retained", count
    VfaLookupAssert VfaSelectionAlias(ChrW$(160) & "Abaka" & ChrW$(8239), _
                                    aliasText), "Unicode edge spaces without paragraph accepted", count
    VfaLookupAssert aliasText = "Abaka", "Unicode edge spaces trimmed", count
    VfaLookupAssert Not VfaSelectionAlias("Ali" & vbCr & "Hasan", aliasText), "Interior paragraph rejected", count
    VfaLookupAssert Len(aliasText) = 0, "Rejected selection returns no alias", count
    VfaLookupAssert Not VfaSelectionAlias(vbCr & "Ali", aliasText), "Leading paragraph rejected", count
    VfaLookupAssert Not VfaSelectionAlias("Ali" & vbCr & vbCr, aliasText), "Multiple paragraphs rejected", count
    VfaLookupAssert Not VfaSelectionAlias("Ali" & vbCr & " " & vbCr, aliasText), "Spaced paragraphs rejected", count
    VfaLookupAssert Not VfaSelectionAlias("Ali" & vbTab, aliasText), "Trailing tab rejected", count
    VfaLookupAssert Not VfaSelectionAlias("Ali" & vbLf, aliasText), "Line feed rejected", count
    VfaLookupAssert Not VfaSelectionAlias("Ali" & vbCr & vbLf, aliasText), "CRLF rejected", count
    VfaLookupAssert Not VfaSelectionAlias("Ali" & vbCr & Chr$(7), aliasText), "Word cell marker rejected", count
    VfaLookupAssert Not VfaSelectionAlias("Ali" & Chr$(11), aliasText), "Manual line break rejected", count
    VfaLookupAssert Not VfaSelectionAlias("Ali" & Chr$(27), aliasText), "Other C0 control rejected", count
    VfaLookupAssert Not VfaSelectionAlias("Ali" & ChrW$(128), aliasText), "C1 control rejected", count
    VfaLookupAssert Not VfaSelectionAlias("Ali" & ChrW$(133), aliasText), "Unicode next-line control rejected", count
    VfaLookupAssert Not VfaSelectionAlias("Ali" & ChrW$(8232), aliasText), "Unicode line separator rejected", count
    VfaLookupAssert Not VfaSelectionAlias(" " & vbCr & ChrW$(160), aliasText), "Empty paragraph rejected", count
    VfaLookupAssert VfaSelectionAlias(String$(VfaMaxName, "A") & " " & vbCr, _
                                    aliasText), "Literal maximum accepted despite selection extras", count
    VfaLookupAssert Len(aliasText) = VfaMaxName, "Literal maximum retained", count
    VfaLookupAssert Not VfaSelectionAlias(String$(VfaMaxName + 1, "A") & vbCr, _
                                        aliasText), "Overlong literal rejected", count
    VfaRunLookupChecks = count
End Function

Private Sub VfaLookupAssert(ByVal condition As Boolean, ByVal name As String, ByRef count As Long)
    If Not condition Then Err.Raise VfaCheckFailure, "VefeyatActions", name
    count = count + 1
End Sub

Private Function VfaGetBinding(ByVal targetDoc As Word.Document, ByRef row As Variant, _
                               ByVal aliasText As String, ByRef changed As Boolean) As String
    Dim bindings As Collection, bindingId As Variant
    Dim personKey As String, storedAlias As String, numberText As String
    Dim nextNumber As Long
    personKey = VfpPersonKey(row)
    Set bindings = VfaBindingIds(targetDoc)
    For Each bindingId In bindings
        storedAlias = VfaReadVariable(targetDoc, VfaVariableName(CStr(bindingId), "Alias"))
        If VfaAliasKey(storedAlias) = VfaAliasKey(aliasText) Then
            If VfaReadVariable(targetDoc, VfaVariableName(CStr(bindingId), "Key")) = personKey Then
                changed = True
                VfaWriteVariable targetDoc, VfaVariableName(CStr(bindingId), "Raw"), CStr(row(3))
                VfaGetBinding = CStr(bindingId)
                Exit Function
            End If
        End If
    Next bindingId
    numberText = VfaReadVariable(targetDoc, VfaNextVariable)
    nextNumber = 1
    If Len(numberText) > 0 Then
        If IsNumeric(numberText) Then
            If CDbl(numberText) >= 1 And CDbl(numberText) < 2000000000# Then nextNumber = CLng(numberText)
        End If
    End If
    Do
        bindingId = "P" & CStr(nextNumber)
        nextNumber = nextNumber + 1
    Loop While VfaVariableExists(targetDoc, VfaVariableName(CStr(bindingId), "Key"))
    changed = True
    VfaWriteVariable targetDoc, VfaNextVariable, CStr(nextNumber)
    VfaWriteVariable targetDoc, VfaVariableName(CStr(bindingId), "Alias"), aliasText
    VfaWriteVariable targetDoc, VfaVariableName(CStr(bindingId), "Raw"), CStr(row(3))
    ' Key is the commit marker. Incomplete metadata is never scanned.
    VfaWriteVariable targetDoc, VfaVariableName(CStr(bindingId), "Key"), personKey
    VfaGetBinding = CStr(bindingId)
End Function

Private Sub VfaRetireOtherBindings(ByVal targetDoc As Word.Document, ByVal keepId As String, _
                                   ByVal aliasText As String, ByRef changed As Boolean)
    Dim bindings As Collection, bindingId As Variant, storedAlias As String
    Set bindings = VfaBindingIds(targetDoc)
    For Each bindingId In bindings
        If CStr(bindingId) <> keepId Then
            storedAlias = VfaReadVariable(targetDoc, VfaVariableName(CStr(bindingId), "Alias"))
            If VfaAliasKey(storedAlias) = VfaAliasKey(aliasText) Then
                VfaDeleteManaged targetDoc, CStr(bindingId), changed
                VfaDeleteManualBookmark targetDoc, CStr(bindingId), changed
                changed = True
                targetDoc.Variables.Item(VfaVariableName(CStr(bindingId), "Key")).Delete
                VfaDeleteVariable targetDoc, VfaVariableName(CStr(bindingId), "Alias")
                VfaDeleteVariable targetDoc, VfaVariableName(CStr(bindingId), "Raw")
            End If
        End If
    Next bindingId
End Sub

Private Sub VfaApplyBinding(ByVal targetDoc As Word.Document, ByVal bindingId As String, _
                            ByVal aliasText As String, ByVal rawDate As String, _
                            ByRef inserted As Long, ByRef skipped As Long, ByRef changed As Boolean)
    Dim occurrences As Collection, occurrence As Word.Range
    Dim i As Long, last As Long, dateText As String
    Dim previousInserted As Long, previousSkipped As Long
    dateText = VfpFormatDate(rawDate, VfpGetPrefix(targetDoc))
    previousInserted = inserted
    previousSkipped = skipped
    VfaDeleteManualBookmark targetDoc, bindingId, changed
    VfaDeleteManaged targetDoc, bindingId, changed
    Set occurrences = VfaFindOccurrences(targetDoc, aliasText)
    last = occurrences.Count
    If VfpGetScope(targetDoc) = "first" And last > 1 Then last = 1
    For i = last To 1 Step -1
        Set occurrence = occurrences.Item(i)
        If VfaAlreadyHasDate(occurrence, rawDate) Then
            skipped = skipped + 1
        Else
            VfaInsertManaged targetDoc, occurrence, dateText, bindingId, changed
            inserted = inserted + 1
        End If
    Next i
    If inserted = previousInserted And skipped > previousSkipped Then
        ' A manual first date can leave no owned fields after all -> first.
        ' Keep only a name bookmark for that explicit result, never own its date.
        Set occurrence = occurrences.Item(1)
        changed = True
        targetDoc.Bookmarks.Add Name:=VfaBookmarkName(targetDoc, bindingId), Range:=occurrence
    End If
End Sub

Private Sub VfaDeleteManualBookmark(ByVal targetDoc As Word.Document, ByVal bindingId As String, _
                                    ByRef changed As Boolean)
    Dim name As String
    name = VfaBookmarkName(targetDoc, bindingId)
    If Len(name) = 0 Then Exit Sub
    If targetDoc.Bookmarks.Exists(name) Then
        changed = True
        targetDoc.Bookmarks.Item(name).Delete
    End If
End Sub

Private Function VfaManualBookmarkActive(ByVal targetDoc As Word.Document, ByVal bindingId As String) As Boolean
    Dim target As Word.Range, aliasText As String, rawDate As String, name As String
    name = VfaBookmarkName(targetDoc, bindingId)
    If Len(name) = 0 Then Exit Function
    If Not targetDoc.Bookmarks.Exists(name) Then Exit Function
    Set target = targetDoc.Bookmarks.Item(name).Range
    If Not VfaSupportedRange(targetDoc, target) Then Exit Function
    aliasText = VfaReadVariable(targetDoc, VfaVariableName(bindingId, "Alias"))
    rawDate = VfaReadVariable(targetDoc, VfaVariableName(bindingId, "Raw"))
    If Not VfaValidAlias(aliasText) Or Not VfaValidDate(rawDate) Then Exit Function
    If StrComp(target.Text, aliasText, vbTextCompare) <> 0 Then Exit Function
    VfaManualBookmarkActive = VfaAlreadyHasDate(target, rawDate)
End Function

Private Sub VfaDeleteManaged(ByVal targetDoc As Word.Document, ByVal bindingId As String, _
                             ByRef changed As Boolean)
    Dim regions As Collection, region As Word.Range, field As Word.Field, i As Long
    Set regions = VfaRegions(targetDoc)
    For Each region In regions
        For i = region.Fields.Count To 1 Step -1
            Set field = region.Fields.Item(i)
            If VfaFieldBinding(targetDoc, field) = bindingId Then
                changed = True
                field.Locked = False
                ' Delete the field and its displayed date; never leave result text.
                field.Delete
            End If
        Next i
    Next region
End Sub

Private Function VfaFindOccurrences(ByVal targetDoc As Word.Document, ByVal aliasText As String) As Collection
    Dim result As New Collection, occurrence As Word.Range
    Dim excluded As Collection, literal As Collection
    Set VfaFindOccurrences = result
    Set excluded = VfaExcludedRanges(targetDoc, aliasText)
    Set literal = VfaLiteralOccurrences(targetDoc, aliasText)
    For Each occurrence In literal
        If Not VfaOverlapsExcluded(occurrence, excluded) Then result.Add occurrence
    Next occurrence
End Function

' Main text is followed at each reference by that footnote's text. Coordinates
' from different stories must never be compared without a main-text anchor.
Private Function VfaLiteralOccurrences(ByVal targetDoc As Word.Document, ByVal aliasText As String) As Collection
    Dim result As New Collection, main As Collection, notes As Collection
    Dim note As Word.Footnote, occurrence As Word.Range, nextMain As Long
    Set main = VfaRegionOccurrences(targetDoc.Content, aliasText)
    nextMain = 1
    For Each note In targetDoc.Footnotes
        Do While nextMain <= main.Count
            Set occurrence = main.Item(nextMain)
            If Not VfaOrderBefore(occurrence.Start, 0, 0, note.Reference.Start, 1, 0) Then Exit Do
            result.Add occurrence
            nextMain = nextMain + 1
        Loop
        Set notes = VfaRegionOccurrences(note.Range, aliasText)
        For Each occurrence In notes
            result.Add occurrence
        Next occurrence
    Next note
    Do While nextMain <= main.Count
        result.Add main.Item(nextMain)
        nextMain = nextMain + 1
    Loop
    Set VfaLiteralOccurrences = result
End Function

' Lexicographic order: main anchor, main/note, local position within a note.
' This helper is pure so the first-occurrence rule has deterministic checks.
Private Function VfaOrderBefore(ByVal anchorA As Long, ByVal partA As Long, ByVal localA As Long, _
                                 ByVal anchorB As Long, ByVal partB As Long, ByVal localB As Long) As Boolean
    If anchorA <> anchorB Then
        VfaOrderBefore = (anchorA < anchorB)
    ElseIf partA <> partB Then
        VfaOrderBefore = (partA < partB)
    Else
        VfaOrderBefore = (localA < localB)
    End If
End Function

' Raw, independent search used by both occurrence lookup and longer-name guards.
' It must never call the exclusion builder or managed occurrence finder.
Private Function VfaRegionOccurrences(ByVal region As Word.Range, ByVal aliasText As String) As Collection
    Dim result As New Collection, scan As Word.Range, nextPosition As Long
    Set VfaRegionOccurrences = result
    Set scan = region.Duplicate
    With scan.Find
        .ClearFormatting
        .Text = Replace(aliasText, "^", "^^")
        .Forward = True
        .Wrap = wdFindStop
        .Format = False
        .MatchCase = False
        .MatchWholeWord = True
        .MatchWildcards = False
        .MatchSoundsLike = False
        .MatchAllWordForms = False
        .IgnoreSpace = False
        .IgnorePunct = False
        .MatchPrefix = False
        .MatchSuffix = False
    End With
    Do While scan.Find.Execute
        If scan.End <= scan.Start Then Exit Do
        If Not VfaRangeInRegion(scan, region) Then Exit Do
        ' Independently reject any broadening by Word's language/find settings.
        If StrComp(scan.Text, aliasText, vbTextCompare) = 0 Then result.Add scan.Duplicate
        nextPosition = scan.End
        If nextPosition >= region.End Then Exit Do
        scan.SetRange nextPosition, region.End
    Loop
End Function

Private Function VfaRegions(ByVal targetDoc As Word.Document) As Collection
    Dim result As New Collection, note As Word.Footnote
    result.Add targetDoc.Content.Duplicate
    For Each note In targetDoc.Footnotes
        result.Add note.Range.Duplicate
    Next note
    Set VfaRegions = result
End Function

Private Function VfaRangeInRegion(ByVal target As Word.Range, ByVal region As Word.Range) As Boolean
    If Not target.InStory(region) Then Exit Function
    VfaRangeInRegion = target.InRange(region)
End Function

Private Function VfaSupportedRange(ByVal targetDoc As Word.Document, ByVal target As Word.Range) As Boolean
    Dim note As Word.Footnote
    If target.StoryType = wdMainTextStory Then
        VfaSupportedRange = VfaRangeInRegion(target, targetDoc.Content)
    ElseIf target.StoryType = wdFootnotesStory Then
        For Each note In targetDoc.Footnotes
            If VfaRangeInRegion(target, note.Range) Then
                VfaSupportedRange = True
                Exit Function
            End If
        Next note
    End If
End Function

Private Function VfaExcludedRanges(ByVal targetDoc As Word.Document, _
                                   Optional ByVal allowAlias As String = "") As Collection
    Dim result As New Collection, control As Word.ContentControl
    Dim field As Word.Field, protectedRange As Word.Range, region As Word.Range
    Dim storedAlias As String, nameRange As Word.Range, regions As Collection
    Dim bindings As Collection, bindingId As Variant, literal As Collection
    ' Store Range objects, not plain offsets: footnotes use another story.
    ' Never place dates in codes/results or any add-in's content controls.
    Set regions = VfaRegions(targetDoc)
    For Each region In regions
        For Each field In region.Fields
            Set protectedRange = field.Code.Duplicate
            protectedRange.SetRange field.Code.Start - 1, field.Result.End + 1
            result.Add protectedRange
        Next field
        For Each control In region.ContentControls
            result.Add control.Range.Duplicate
        Next control
    Next region
    Set bindings = VfaActiveBindingIds(targetDoc)
    For Each bindingId In bindings
        storedAlias = VfaReadVariable(targetDoc, VfaVariableName(CStr(bindingId), "Alias"))
        If Len(storedAlias) > Len(allowAlias) Then
            If InStr(1, storedAlias, allowAlias, vbTextCompare) > 0 Then
                ' Protect EVERY occurrence of an active longer alias, including
                ' occurrences without dates under the first-occurrence setting.
                Set literal = VfaLiteralOccurrences(targetDoc, storedAlias)
                For Each nameRange In literal
                    result.Add nameRange
                Next nameRange
            End If
        End If
    Next bindingId
    Set VfaExcludedRanges = result
End Function

Private Function VfaOverlapsExcluded(ByVal target As Word.Range, ByVal excluded As Collection) As Boolean
    Dim protectedRange As Word.Range
    For Each protectedRange In excluded
        If target.InStory(protectedRange) Then
            If target.Start < protectedRange.End And target.End > protectedRange.Start Then
                VfaOverlapsExcluded = True
                Exit Function
            End If
        End If
    Next protectedRange
End Function

Private Sub VfaInsertManaged(ByVal targetDoc As Word.Document, ByVal occurrence As Word.Range, _
                             ByVal dateText As String, ByVal bindingId As String, ByRef changed As Boolean, _
                             Optional ByVal moveCaret As Boolean = False)
    Dim insertion As Word.Range, field As Word.Field
    Dim errorNumber As Long, errorText As String
    On Error GoTo Failed
    Set insertion = occurrence.Duplicate
    insertion.Collapse wdCollapseEnd
    changed = True
    ' A directly created ADDIN has no result separator: assigning Result.Text
    ' would write an unmanaged date after it. QUOTE supplies a real result.
    ' The duplicate retains its story, including when the name is in a footnote.
    Set field = insertion.Fields.Add(Range:=insertion, Type:=wdFieldQuote, _
                                    Text:=Chr$(34) & " " & Chr$(34), PreserveFormatting:=False)
    field.Result.Text = " " & dateText
    field.Code.Text = " ADDIN " & VfaFieldTag(targetDoc, bindingId) & " "
    field.Locked = True
    field.ShowCodes = False
    If field.Type <> wdFieldAddin Or StrComp(field.Result.Text, " " & dateText, vbBinaryCompare) <> 0 Then
        Err.Raise VfaInvalidData, "VefeyatActions", "Word could not retain the managed date inside its field."
    End If
    If moveCaret Then
        ' Continue typing after the closing field character, in the same story.
        Set insertion = field.Result.Duplicate
        insertion.SetRange field.Result.End + 1, field.Result.End + 1
        insertion.Select
    End If
    Exit Sub
Failed:
    errorNumber = Err.Number
    errorText = Err.Description
    ' Roll back only the field created by this call. Never retry insertion.
    On Error Resume Next
    If Not field Is Nothing Then
        field.Locked = False
        field.Delete
    End If
    On Error GoTo 0
    Err.Raise errorNumber, "VefeyatActions", errorText
End Sub

Private Function VfaAlreadyHasDate(ByVal occurrence As Word.Range, ByVal rawDate As String) As Boolean
    Dim following As Word.Range, afterText As String, dateText As String
    Dim key As Variant, i As Long, character As String
    Set following = occurrence.Duplicate
    following.SetRange occurrence.End, occurrence.End
    Call following.MoveEnd(wdCharacter, Len(rawDate) * 3 + 512)
    afterText = following.Text
    For i = 1 To Len(afterText)
        character = Mid$(afterText, i, 1)
        If character = vbCr Or character = Chr$(7) Or character = Chr$(11) Then
            afterText = Left$(afterText, i - 1)
            Exit For
        End If
    Next i
    afterText = VfaNormalizeWhitespace(afterText)
    For Each key In Array("original", "o", "ol", "v")
        dateText = VfaNormalizeWhitespace(VfpFormatDate(rawDate, CStr(key)))
        If Len(dateText) > 0 And Len(afterText) >= Len(dateText) Then
            If StrComp(Left$(afterText, Len(dateText)), dateText, vbTextCompare) = 0 Then
                If Len(afterText) = Len(dateText) Then
                    VfaAlreadyHasDate = True
                Else
                    VfaAlreadyHasDate = VfaDateBoundary(Mid$(afterText, Len(dateText) + 1, 1))
                End If
                If VfaAlreadyHasDate Then Exit Function
            End If
        End If
    Next key
End Function

Private Function VfaDateBoundary(ByVal character As String) As Boolean
    VfaDateBoundary = (InStr(1, " .,;:!?)]}" & Chr$(34), character, vbBinaryCompare) > 0)
End Function

Private Function VfaBindingIds(ByVal targetDoc As Word.Document) As Collection
    Dim result As New Collection, item As Word.Variable, name As String, bindingId As String
    For Each item In targetDoc.Variables
        name = item.Name
        If Left$(name, Len(VfaVariablePrefix)) = VfaVariablePrefix Then
            If Right$(name, 4) = ".Key" Then
                bindingId = Mid$(name, Len(VfaVariablePrefix) + 1, Len(name) - Len(VfaVariablePrefix) - 4)
                If VfaValidBindingId(bindingId) Then result.Add bindingId
            End If
        End If
    Next item
    Set VfaBindingIds = result
End Function

Private Function VfaActiveBindingIds(ByVal targetDoc As Word.Document) As Collection
    Dim result As New Collection, field As Word.Field, bindingId As String
    Dim bindings As Collection, markerId As Variant, regions As Collection, region As Word.Range
    ' Undoing or deleting the last managed field must deactivate its metadata.
    ' Only an explicit insertion command may reuse an inactive binding.
    Set regions = VfaRegions(targetDoc)
    For Each region In regions
        For Each field In region.Fields
            bindingId = VfaFieldBinding(targetDoc, field)
            If Len(bindingId) > 0 Then
                If Not VfaCollectionContains(result, bindingId) Then result.Add bindingId
            End If
        Next field
    Next region
    Set bindings = VfaBindingIds(targetDoc)
    For Each markerId In bindings
        If Not VfaCollectionContains(result, CStr(markerId)) Then
            If VfaManualBookmarkActive(targetDoc, CStr(markerId)) Then result.Add CStr(markerId)
        End If
    Next markerId
    Set VfaActiveBindingIds = result
End Function

Private Function VfaValidBindingId(ByVal value As String) As Boolean
    Dim i As Long, character As String
    If Len(value) < 2 Or Len(value) > 12 Then Exit Function
    If Left$(value, 1) <> "P" Then Exit Function
    For i = 2 To Len(value)
        character = Mid$(value, i, 1)
        If character < "0" Or character > "9" Then Exit Function
    Next i
    VfaValidBindingId = True
End Function

Private Sub VfaEnsureNamespace(ByVal targetDoc As Word.Document, ByRef changed As Boolean)
    Dim value As String
    value = VfaReadVariable(targetDoc, VfaNamespaceVariable)
    If Len(value) > 0 Then
        If Not VfaValidNamespace(value) Then
            Err.Raise VfaInvalidData, "VefeyatActions", "Stored binding namespace is invalid."
        End If
        Exit Sub
    End If
    If Not mVfaRandomized Then
        Randomize
        mVfaRandomized = True
    End If
    value = "D" & Right$("00000000" & Hex$(CLng(Rnd() * 2147483646#)), 8) & _
                  Right$("00000000" & Hex$(CLng(Rnd() * 2147483646#)), 8)
    changed = True
    VfaWriteVariable targetDoc, VfaNamespaceVariable, value
End Sub

Private Function VfaNamespace(ByVal targetDoc As Word.Document) As String
    Dim value As String
    value = VfaReadVariable(targetDoc, VfaNamespaceVariable)
    If VfaValidNamespace(value) Then VfaNamespace = value
End Function

Private Function VfaValidNamespace(ByVal value As String) As Boolean
    Dim i As Long
    If Len(value) <> 17 Then Exit Function
    If Left$(value, 1) <> "D" Then Exit Function
    For i = 2 To Len(value)
        If InStr(1, "0123456789ABCDEF", Mid$(value, i, 1), vbBinaryCompare) = 0 Then Exit Function
    Next i
    VfaValidNamespace = True
End Function

Private Function VfaBindingFromTag(ByVal tag As String, ByVal namespace As String) As String
    Dim prefix As String, bindingId As String
    If Not VfaValidNamespace(namespace) Then Exit Function
    prefix = VfaTagPrefix & namespace & "."
    If Left$(tag, Len(prefix)) <> prefix Then Exit Function
    bindingId = Mid$(tag, Len(prefix) + 1)
    If VfaValidBindingId(bindingId) Then VfaBindingFromTag = bindingId
End Function

Private Function VfaFieldBinding(ByVal targetDoc As Word.Document, ByVal field As Word.Field) As String
    If field.Type <> wdFieldAddin Then Exit Function
    VfaFieldBinding = VfaBindingFromFieldCode(field.Code.Text, VfaNamespace(targetDoc))
End Function

Private Function VfaBindingFromFieldCode(ByVal code As String, ByVal namespace As String) As String
    Dim normalized As String
    normalized = VfaNormalizeWhitespace(code)
    If StrComp(Left$(normalized, 6), "ADDIN ", vbTextCompare) <> 0 Then Exit Function
    VfaBindingFromFieldCode = VfaBindingFromTag(Mid$(normalized, 7), namespace)
End Function

Private Function VfaFieldTag(ByVal targetDoc As Word.Document, ByVal bindingId As String) As String
    Dim namespace As String
    namespace = VfaNamespace(targetDoc)
    If Len(namespace) = 0 Or Not VfaValidBindingId(bindingId) Then
        Err.Raise VfaInvalidData, "VefeyatActions", "A local binding namespace and ID are required."
    End If
    VfaFieldTag = VfaTagPrefix & namespace & "." & bindingId
End Function

Private Function VfaBookmarkName(ByVal targetDoc As Word.Document, ByVal bindingId As String) As String
    Dim namespace As String
    namespace = VfaNamespace(targetDoc)
    If Len(namespace) = 0 Or Not VfaValidBindingId(bindingId) Then Exit Function
    VfaBookmarkName = VfaManualBookmarkPrefix & namespace & "_" & bindingId
End Function

Private Function VfaVariableName(ByVal bindingId As String, ByVal field As String) As String
    VfaVariableName = VfaVariablePrefix & bindingId & "." & field
End Function

Private Function VfaVariableExists(ByVal targetDoc As Word.Document, ByVal name As String) As Boolean
    Dim item As Word.Variable
    For Each item In targetDoc.Variables
        If StrComp(item.Name, name, vbTextCompare) = 0 Then
            VfaVariableExists = True
            Exit Function
        End If
    Next item
End Function

Private Function VfaReadVariable(ByVal targetDoc As Word.Document, ByVal name As String) As String
    Dim item As Word.Variable
    ' Enumerating avoids treating an absent setting as a deleted Word object.
    ' Errors from real, existing objects are deliberately allowed to propagate.
    For Each item In targetDoc.Variables
        If StrComp(item.Name, name, vbTextCompare) = 0 Then
            VfaReadVariable = item.Value
            Exit Function
        End If
    Next item
End Function

Private Sub VfaWriteVariable(ByVal targetDoc As Word.Document, ByVal name As String, ByVal value As String)
    If VfaVariableExists(targetDoc, name) Then
        targetDoc.Variables.Item(name).Value = value
    Else
        targetDoc.Variables.Add Name:=name, Value:=value
    End If
End Sub

Private Sub VfaDeleteVariable(ByVal targetDoc As Word.Document, ByVal name As String)
    If VfaVariableExists(targetDoc, name) Then targetDoc.Variables.Item(name).Delete
End Sub

Private Function VfaAliasKey(ByVal value As String) As String
    ' Literal spelling is retained: accent folding belongs only to catalog lookup.
    ' Internal spaces are also literal for Word.Find, so do not collapse them.
    VfaAliasKey = LCase$(VfaTrimSpaces(value))
End Function

Private Function VfaValidAlias(ByVal value As String) As Boolean
    If Len(value) = 0 Or Len(value) > VfaMaxName Then Exit Function
    If Not VfaSingleLine(value) Then Exit Function
    VfaValidAlias = (Len(VefeyatNormalize(value)) > 0)
End Function

' Word can include the paragraph mark when a name occupies the whole paragraph.
' Normalize only the lookup spelling; the captured selection remains unchanged.
Private Function VfaSelectionAlias(ByVal originalText As String, ByRef aliasText As String) As Boolean
    Dim candidate As String, i As Long, code As Long
    aliasText = ""
    candidate = VfaTrimSpaces(originalText)
    If Len(candidate) = 0 Then Exit Function
    If Right$(candidate, 1) = vbCr Then
        candidate = VfaTrimSpaces(Left$(candidate, Len(candidate) - 1))
    End If
    If Len(candidate) = 0 Or Len(candidate) > VfaMaxName Then Exit Function
    For i = 1 To Len(candidate)
        code = AscW(Mid$(candidate, i, 1)) And &HFFFF&
        If code >= 127 And code <= 159 Then Exit Function
    Next i
    If Not VfaValidAlias(candidate) Then Exit Function
    aliasText = candidate
    VfaSelectionAlias = True
End Function

Private Function VfaValidDate(ByVal value As String) As Boolean
    If Len(VfaTrimSpaces(value)) = 0 Or Len(value) > VfaMaxDate Then Exit Function
    VfaValidDate = VfaSingleLine(value)
End Function

Private Function VfaSingleLine(ByVal value As String) As Boolean
    Dim i As Long, code As Long
    For i = 1 To Len(value)
        code = AscW(Mid$(value, i, 1)) And &HFFFF&
        If code < 32 Or code = 127 Or code = 133 Or code = 8232 Or code = 8233 Then Exit Function
    Next i
    VfaSingleLine = True
End Function

Private Function VfaTrimSpaces(ByVal value As String) As String
    Dim first As Long, last As Long
    first = 1
    last = Len(value)
    Do While first <= last
        If Not VfaIsSpace(Mid$(value, first, 1)) Then Exit Do
        first = first + 1
    Loop
    Do While last >= first
        If Not VfaIsSpace(Mid$(value, last, 1)) Then Exit Do
        last = last - 1
    Loop
    If last >= first Then VfaTrimSpaces = Mid$(value, first, last - first + 1)
End Function

Private Function VfaIsSpace(ByVal value As String) As Boolean
    Dim code As Long
    code = AscW(value) And &HFFFF&
    VfaIsSpace = (code = 32 Or code = 160 Or code = 5760 Or _
                 (code >= 8192 And code <= 8202) Or code = 8239 Or code = 8287 Or code = 12288)
End Function

Private Function VfaNormalizeWhitespace(ByVal value As String) As String
    Dim i As Long, character As String, result As String, pending As Boolean
    For i = 1 To Len(value)
        character = Mid$(value, i, 1)
        If VfaIsSpace(character) Or character = vbTab Then
            If Len(result) > 0 Then pending = True
        Else
            If pending Then result = result & " "
            result = result & character
            pending = False
        End If
    Next i
    VfaNormalizeWhitespace = result
End Function

Private Function VfaBeginUndo(ByRef undoObject As Object) As Boolean
    Dim currentLevel As Long
    On Error Resume Next
    Err.Clear
    Set undoObject = CallByName(Application, "UndoRecord", VbGet)
    If Err.Number = 0 Then
        currentLevel = CLng(CallByName(undoObject, "CustomRecordLevel", VbGet))
        If Err.Number = 0 And currentLevel = 0 Then
            Err.Clear
            CallByName undoObject, "StartCustomRecord", VbMethod, VfText("Vefey\u00e2t tarihleri")
            VfaBeginUndo = (Err.Number = 0)
        End If
    End If
    Err.Clear
    On Error GoTo 0
End Function

Private Sub VfaEndUndo(ByRef undoObject As Object, ByRef undoStarted As Boolean)
    If undoStarted Then
        On Error Resume Next
        CallByName undoObject, "EndCustomRecord", VbMethod
        Err.Clear
        On Error GoTo 0
    End If
    undoStarted = False
    Set undoObject = Nothing
End Sub

Private Sub VfaReportFailure(ByVal failure As String, ByVal changed As Boolean)
    Dim message As String
    message = VfText("Word tarih i\u015flemini tamamlayamad\u0131. ")
    If changed Then
        message = message & VfText("Belgede k\u0131smi de\u011fi\u015fiklik olabilir. Yeniden denemeden \u00f6nce tarihleri kontrol edin; gerekirse Word'\u00fcn Geri Al komutunu kullan\u0131n. ")
    End If
    VfaWarn message & Left$(failure, 300)
End Sub

Private Sub VfaWarn(ByVal message As String)
    VfMessage message, vbInformation, VfText("Vefey\u00e2t")
End Sub

Private Function VflMacroPath(ByVal entry As String) As String
    ' Bind the callback to its actual template, independently of VBE project names.
    VflMacroPath = "'" & ThisDocument.Name & "'!" & VfsInstalledModule & "." & entry
End Function

Private Sub VflArm()
    On Error GoTo Failed
    If StrComp(ThisDocument.Name, VfsTemplateName, vbTextCompare) <> 0 Then Exit Sub
    If mVflSuspended Then Exit Sub
    If mVflPending Then
        ' Another Word add-in may replace the single shared OnTime callback.
        ' Expire our stale bookkeeping when a later UI event asks to re-arm.
        If Now <= DateAdd("s", 3, mVflDueAt) Then Exit Sub
        mVflPending = False
    End If
    mVflDueAt = DateAdd("s", 1, Now)
    Application.OnTime When:=mVflDueAt, Name:=VflMacroPath("Vefeyat036UiAutoTick")
    mVflPending = True
    Exit Sub
Failed:
    mVflPending = False
    mVflStatus = VfText("Zamanlay\u0131c\u0131 ba\u015flat\u0131lamad\u0131: ") & Err.Description
End Sub

Private Function VflDiagnostic() As String
    Dim result As String, scope As String, count As Long
    On Error GoTo Failed
    If Documents.Count > 0 Then
        scope = VfText("\u0130lk ge\u00e7ti\u011fi yere")
        If VfpGetScope(ActiveDocument) = "all" Then scope = VfText("Her ge\u00e7ti\u011fi yere")
        count = VfaActiveBindingIds(ActiveDocument).Count
        result = VfText("Bu belgedeki ekleme ayar\u0131: ") & scope & vbCrLf & _
            VfText("Onayl\u0131 ad ba\u011f\u0131: ") & CStr(count) & vbCrLf
    End If
    If mVflTicks = 0 Then
        result = result & VfText("Son otomatik denetim: Hen\u00fcz \u00e7al\u0131\u015fmad\u0131.")
    Else
        result = result & VfText("Son otomatik denetim: ") & Format$(mVflLastTick, "hh:nn:ss") & _
            " (" & CStr(mVflTicks) & ")"
    End If
    result = result & vbCrLf & VfText("Durum: ") & mVflPhase
    If mVflPending Then
        If Now > DateAdd("s", 3, mVflDueAt) Then
            result = result & vbCrLf & VfText("Planlanan denetim gecikti veya iptal edildi.")
        Else
            result = result & vbCrLf & VfText("Sonraki denetim planland\u0131.")
        End If
    End If
    If Len(mVflStatus) > 0 Then result = result & vbCrLf & mVflStatus
    VflDiagnostic = result
    Exit Function
Failed:
    VflDiagnostic = result & vbCrLf & VfText("Tan\u0131 okunamad\u0131: ") & Err.Description
End Function

' State is isolated per open document; changing windows must not discard Undo guards.
Private Function VflState(ByVal doc As Word.Document) As Object
    Dim state As Object, owner As Word.Document, current As Word.Document, i As Long, opened As Boolean
    If mVflStates Is Nothing Then Set mVflStates = New Collection
    For i = mVflStates.Count To 1 Step -1
        Set state = mVflStates(i)
        Set owner = state("Document")
        opened = False
        For Each current In Documents
            If current Is owner Then opened = True
        Next current
        If Not opened Then
            mVflStates.Remove i
        ElseIf owner Is doc Then
            Set VflState = state
        End If
    Next i
    If Not VflState Is Nothing Then Exit Function
    Set state = CreateObject("Scripting.Dictionary")
    Set state("Document") = doc
    state("Text") = vbNullString
    state("Processed") = vbNullString
    state("ProcessedPosition") = -1&
    state("ProcessedStory") = -1&
    state("Position") = -1&
    state("Story") = -1&
    state("Observed") = Now
    state("Initialized") = False
    Set state("Tracked") = New Collection
    Set state("Suppressed") = New Collection
    mVflStates.Add state
    Set VflState = state
End Function

Private Function VflSignature(ByVal doc As Word.Document) As String
    Dim note As Word.Footnote, result As String
    result = doc.Content.Text
    For Each note In doc.Footnotes
        result = result & ChrW$(30) & note.Range.Text
    Next note
    VflSignature = result
End Function

' A new text/caret observation only starts the wait. An unchanged observation
' becomes eligible after a full interval, even when no trailing space is typed.
Private Function VflIdleReady(ByVal signature As String, ByVal position As Long, ByVal story As Long, _
                              ByVal stamp As Date, ByVal state As Object) As Boolean
    If Not CBool(state("Initialized")) Or signature <> CStr(state("Text")) Or _
       position <> CLng(state("Position")) Or story <> CLng(state("Story")) Then
        state("Text") = signature
        state("Position") = position
        state("Story") = story
        state("Observed") = stamp
        state("Initialized") = True
        Exit Function
    End If
    If signature = CStr(state("Processed")) And position = CLng(state("ProcessedPosition")) And _
       story = CLng(state("ProcessedStory")) Then Exit Function
    If DateDiff("s", CDate(state("Observed")), stamp) < 1 Then Exit Function
    VflIdleReady = True
End Function

Public Sub Vefeyat036UiAutoTick()
    Dim doc As Word.Document, state As Object, signature As String, inserted As Long
    On Error GoTo Failed
    mVflPending = False
    mVflLastTick = Now
    mVflTicks = mVflTicks + 1
    mVflPhase = VfText("Denetim ba\u015flad\u0131.")
    If StrComp(ThisDocument.Name, VfsTemplateName, vbTextCompare) <> 0 Then Exit Sub
    If mVflBusy Or mVflSuspended Then
        mVflPhase = VfText("Ba\u015fka bir Vefey\u00e2t i\u015flemi bekleniyor.")
        GoTo Again
    End If
    If Documents.Count = 0 Then
        Set mVflStates = Nothing
        mVflPhase = VfText("A\u00e7\u0131k belge yok.")
        GoTo Again
    End If
    Set doc = ActiveDocument
    Set state = VflState(doc)
    If doc.ReadOnly Or doc.ProtectionType <> wdNoProtection Then
        state("Initialized") = False
        mVflPhase = VfText("Belge salt okunur veya korumal\u0131.")
        GoTo Again
    End If
    If VfpGetScope(doc) <> "all" Then
        state("Initialized") = False
        mVflPhase = VfText("\u0130lk ge\u00e7i\u015f modu: otomatik ekleme kapal\u0131.")
        GoTo Again
    End If
    If Selection.Type <> wdSelectionIP Then
        state("Initialized") = False
        mVflPhase = VfText("Metin se\u00e7ili; yaz\u0131 imleci bekleniyor.")
        GoTo Again
    End If
    If Not VfaSupportedRange(doc, Selection.Range) Then
        mVflPhase = VfText("\u0130mle\u00e7 ana metin veya dipnotta de\u011fil.")
        GoTo Again
    End If
    If VfaActiveBindingIds(doc).Count = 0 Then
        mVflPhase = VfText("Bu belgede etkin onayl\u0131 ad yok.")
        GoTo Again
    End If
    signature = VflSignature(doc)
    If Not VflIdleReady(signature, Selection.Range.Start, Selection.Range.StoryType, Now, state) Then
        mVflPhase = VfText("Yaz\u0131n\u0131n durmas\u0131 veya yeni metin bekleniyor.")
        GoTo Again
    End If
    mVflBusy = True
    VflProtectRemoved doc, state
    inserted = VfaAutoFill(doc, state)
    VflTrackDates doc, state
    state("Processed") = VflSignature(doc)
    state("ProcessedPosition") = Selection.Range.Start
    state("ProcessedStory") = Selection.Range.StoryType
    ' Re-observe after our own insertion to keep the next user edit debounced.
    state("Initialized") = False
    mVflBusy = False
    mVflPhase = VfText("Denetim tamamland\u0131; yeni tarih say\u0131s\u0131: ") & CStr(inserted)
    If inserted > 0 Then mVflStatus = CStr(inserted) & VfText(" tarih otomatik eklendi.")
Again:
    VflArm
    Exit Sub
Failed:
    mVflBusy = False
    mVflPhase = VfText("Hata nedeniyle durdu.")
    mVflStatus = VfText("Otomatik ekleme durdu: ") & Err.Description
    Application.StatusBar = mVflStatus
End Sub

' Explicit commands may reset the wait, but must retain per-document exclusions.
Private Sub VflResetWait()
    Dim state As Object
    If mVflStates Is Nothing Then Exit Sub
    For Each state In mVflStates
        state("Initialized") = False
        state("Processed") = vbNullString
    Next state
End Sub

Private Sub VflCaptureCommand()
    Dim state As Object
    If Documents.Count = 0 Then Exit Sub
    Set state = VflState(ActiveDocument)
    VflTrackDates ActiveDocument, state
    VflResetWait
End Sub

Private Function VflAutoReady(ByVal occurrence As Word.Range, ByVal caret As Word.Range) As Boolean
    Dim following As Word.Range, ch As String
    Set following = occurrence.Duplicate
    following.Collapse wdCollapseEnd
    following.MoveEnd wdCharacter, 1
    ch = Left$(following.Text, 1)
    ' Never split Gazali'nin or an apostrophe continuation while typing.
    If ch = "'" Or ch = ChrW(&H2019) Or ch = ChrW(&H2018) Then Exit Function
    VflAutoReady = True
    If occurrence.InStory(caret) Then
        ' The completed name's end is eligible after the idle check above.
        If caret.Start >= occurrence.Start And caret.Start < occurrence.End Then VflAutoReady = False
    End If
End Function

Private Function VflSuppressed(ByVal occurrence As Word.Range, ByVal state As Object) As Boolean
    Dim ranges As Collection, previous As Word.Range
    Set ranges = state("Suppressed")
    For Each previous In ranges
        If previous.InStory(occurrence) Then
            If previous.Start = occurrence.Start And previous.End = occurrence.End Then
                If StrComp(previous.Text, occurrence.Text, vbBinaryCompare) = 0 Then
                    VflSuppressed = True
                    Exit Function
                End If
            End If
        End If
    Next previous
End Function

' Remember the name range, not a Field object that becomes invalid on Undo.
Private Sub VflTrackDates(ByVal doc As Word.Document, ByVal state As Object)
    Dim tracked As New Collection, ids As Collection, id As Variant, occurrence As Word.Range
    Dim aliasText As String, raw As String, record As Collection
    Set ids = VfaActiveBindingIds(doc)
    For Each id In ids
        aliasText = VfaReadVariable(doc, VfaVariableName(CStr(id), "Alias"))
        raw = VfaReadVariable(doc, VfaVariableName(CStr(id), "Raw"))
        If VfaValidAlias(aliasText) And VfaValidDate(raw) Then
            For Each occurrence In VfaFindOccurrences(doc, aliasText)
                If VfaAlreadyHasDate(occurrence, raw) Then
                    Set record = New Collection
                    record.Add occurrence.Duplicate
                    record.Add occurrence.Text
                    record.Add raw
                    tracked.Add record
                End If
            Next occurrence
        End If
    Next id
    Set state("Tracked") = tracked
End Sub

Private Sub VflProtectRemoved(ByVal doc As Word.Document, ByVal state As Object)
    Dim tracked As Collection, suppressed As Collection, record As Collection, name As Word.Range
    Set tracked = state("Tracked")
    Set suppressed = state("Suppressed")
    For Each record In tracked
        Set name = record(1)
        If name.End > name.Start Then
            If StrComp(name.Text, CStr(record(2)), vbBinaryCompare) = 0 Then
                If Not VfaAlreadyHasDate(name, CStr(record(3))) Then
                    If Not VflSuppressed(name, state) Then suppressed.Add name.Duplicate
                End If
            End If
        End If
    Next record
End Sub

Private Function VfaAutoFill(ByVal doc As Word.Document, ByVal state As Object) As Long
    Dim ids As Collection, id As Variant, ranges As Collection, occurrence As Word.Range
    Dim caret As Word.Range, aliasText As String, raw As String, text As String, i As Long, atCaret As Boolean
    Dim undoObject As Object, started As Boolean, changed As Boolean, number As Long, detail As String
    On Error GoTo Failed
    If Not ActiveDocument Is doc Then Exit Function
    If doc.ReadOnly Or doc.ProtectionType <> wdNoProtection Or VfpGetScope(doc) <> "all" Then Exit Function
    If Selection.Type <> wdSelectionIP Then Exit Function
    Set caret = Selection.Range.Duplicate
    If Not VfaSupportedRange(doc, caret) Then Exit Function
    Set ids = VfaActiveBindingIds(doc)
    For Each id In ids
        aliasText = VfaReadVariable(doc, VfaVariableName(CStr(id), "Alias"))
        raw = VfaReadVariable(doc, VfaVariableName(CStr(id), "Raw"))
        If VfaValidAlias(aliasText) And VfaValidDate(raw) Then
            text = VfpFormatDate(raw, VfpGetPrefix(doc))
            Set ranges = VfaFindOccurrences(doc, aliasText)
            For i = ranges.Count To 1 Step -1
                Set occurrence = ranges.Item(i)
                If VflAutoReady(occurrence, caret) And Not VflSuppressed(occurrence, state) Then
                    If Not VfaAlreadyHasDate(occurrence, raw) Then
                        atCaret = False
                        If occurrence.InStory(caret) Then atCaret = (caret.Start = occurrence.End)
                        If Not started Then started = VfaBeginUndo(undoObject)
                        VfaInsertManaged doc, occurrence, text, CStr(id), changed, atCaret
                        VfaAutoFill = VfaAutoFill + 1
                    End If
                End If
            Next i
        End If
    Next id
    VfaEndUndo undoObject, started
    Exit Function
Failed:
    number = Err.Number
    detail = Err.Description
    VfaEndUndo undoObject, started
    Err.Raise number, "VefeyatLive", detail
End Function

Private Sub VfnCheckSelected()
    Dim doc As Word.Document, target As Word.Range, named As Word.Range, adjacent As Word.Field
    Dim original As String, aliasText As String, reason As String, proposal As String, preview As String
    Dim start As Long, finish As Long, story As Long, offset As Long, choice As Long
    Dim candidates As Collection, row As Variant, bindingId As String, rawDate As String
    Dim undoObject As Object, started As Boolean, changed As Boolean, failure As String
    On Error GoTo Failed
    If Not VfaCapture(doc, target, original, aliasText, start, finish, story) Then Exit Sub
    If VfnHasSuffix(aliasText) Then
        VfaWarn VfText("Yaz\u0131m denetiminde yaln\u0131z \u015fah\u0131s ad\u0131n\u0131 se\u00e7in; kesme i\u015faretinden sonraki T\u00fcrk\u00e7e eki se\u00e7ime katmay\u0131n. Eke dokunulmaz.")
        Exit Sub
    End If
    If Not VefeyatEnsureData() Then Exit Sub
    Set candidates = VfaConfirmationCandidates(VefeyatFind(aliasText, False), aliasText)
    If candidates.Count = 0 Then
        VfaWarn VfText("Bu yaz\u0131m i\u00e7in kaynakta aday bulunamad\u0131. Metin de\u011fi\u015ftirilmedi.")
        Exit Sub
    End If
    choice = VfePickPerson(candidates, aliasText, True)
    If choice < 1 Or choice > candidates.Count Then Exit Sub
    row = candidates(choice)
    proposal = VfnSourceName(row, aliasText)
    If Not VfaValidAlias(proposal) Then
        VfaWarn VfText("Se\u00e7ili ad\u0131n bi\u00e7imini koruyan yak\u0131n bir kaynak yaz\u0131m\u0131 bulunamad\u0131. Metin de\u011fi\u015ftirilmedi.")
        Exit Sub
    End If
    If StrComp(aliasText, proposal, vbBinaryCompare) = 0 Then
        VfMessage VfText("Se\u00e7ili ad kaynak yaz\u0131m\u0131yla ayn\u0131. De\u011fi\u015fiklik gerekmedi."), vbInformation, VfText("Vefey\u00e2t: isim yaz\u0131m\u0131")
        Exit Sub
    End If
    preview = VfText("Kaynak yaz\u0131m\u0131 \u00f6nerisi") & vbCrLf & vbCrLf & _
        VfText("Belgedeki: ") & aliasText & vbCrLf & VfText("\u00d6nerilen: ") & proposal & vbCrLf & vbCrLf & _
        CStr(row(4)) & vbCrLf & VfText("Kaynak: ") & CStr(row(5)) & vbCrLf & vbCrLf & _
        VfText("Ba\u015fka bir yaz\u0131m\u0131n yanl\u0131\u015f oldu\u011fu anlam\u0131na gelmez. Yaln\u0131z bu se\u00e7ili ad\u0131 de\u011fi\u015ftirelim mi?")
    If VfMessage(preview, vbYesNo Or vbQuestion Or vbDefaultButton2, VfText("Vefey\u00e2t: yaz\u0131m\u0131 onaylay\u0131n")) <> vbYes Then Exit Sub
    If Not VfaTargetCurrent(doc, target, original, start, finish, story, reason) Then
        VfaWarn reason
        Exit Sub
    End If
    offset = InStr(1, original, aliasText, vbBinaryCompare) - 1
    If offset < 0 Then Exit Sub
    Set named = target.Duplicate
    named.SetRange start + offset, start + offset + Len(aliasText)
    Set adjacent = VfnAdjacentField(doc, named)
    If Not adjacent Is Nothing Then
        bindingId = VfaFieldBinding(doc, adjacent)
        rawDate = VfaReadVariable(doc, VfaVariableName(bindingId, "Raw"))
        If VfaReadVariable(doc, VfaVariableName(bindingId, "Key")) <> VfpPersonKey(row) Then
            VfaWarn VfText("Bu ad\u0131n tarihi ba\u015fka bir \u015fahsa ba\u011fl\u0131. \u00d6nce \u00d6l\u00fcm tarihi ekle ile \u015fahs\u0131 yeniden do\u011frulay\u0131n.")
            Exit Sub
        End If
        If Not VfnBindingAvailable(doc, proposal, VfpPersonKey(row)) Then
            VfaWarn VfText("\u00d6nerilen yaz\u0131m bu belgede ba\u015fka bir \u015fahsa onaylanm\u0131\u015f. Ad ve tarih de\u011fi\u015ftirilmedi; daha a\u00e7\u0131k bir ad kullan\u0131n.")
            Exit Sub
        End If
    End If
    started = VfaBeginUndo(undoObject)
    changed = True
    named.Text = proposal
    If Not adjacent Is Nothing Then
        bindingId = VfaGetBinding(doc, row, proposal, changed)
        ' A name correction must not silently replace an existing source date.
        VfaWriteVariable doc, VfaVariableName(bindingId, "Raw"), rawDate
        adjacent.Locked = False
        adjacent.Code.Text = " ADDIN " & VfaFieldTag(doc, bindingId) & " "
        adjacent.Locked = True
        adjacent.ShowCodes = False
    End If
    VfaEndUndo undoObject, started
    VflCaptureCommand
    Application.StatusBar = VfText("Se\u00e7ili ad kaynak yaz\u0131m\u0131yla g\u00fcncellendi. Ctrl+Z ile geri alabilirsiniz.")
    Exit Sub
Failed:
    failure = Err.Description
    On Error Resume Next
    If Not adjacent Is Nothing Then adjacent.Locked = True
    On Error GoTo 0
    VfaEndUndo undoObject, started
    VfaReportFailure failure, changed
End Sub

Private Function VfnBindingAvailable(ByVal doc As Word.Document, ByVal aliasText As String, ByVal key As String) As Boolean
    Dim id As Variant
    VfnBindingAvailable = True
    For Each id In VfaActiveBindingIds(doc)
        If VfaAliasKey(VfaReadVariable(doc, VfaVariableName(CStr(id), "Alias"))) = VfaAliasKey(aliasText) Then
            If VfaReadVariable(doc, VfaVariableName(CStr(id), "Key")) <> key Then
                VfnBindingAvailable = False
                Exit Function
            End If
        End If
    Next id
End Function

Private Function VfnSourceName(ByRef row As Variant, ByVal query As String) As String
    Dim i As Long, first As Long, last As Long, score As Long, best As Long
    Dim name As String, candidate As String, key As String
    key = Replace(VefeyatNormalize(query), " ", "")
    If Len(key) = 0 Then Exit Function
    ' Compare contiguous source-name spans. Keep a full name full, and recover
    ' embedded aliases such as Kivamussunne without replacing them with Teymi.
    For i = 0 To 2
        name = CStr(row(i))
        If Len(name) <= 2000 Then
            For first = 1 To Len(name)
                If first = 1 Then
                    score = 1
                Else
                    score = Abs(CLng(VfnNameBoundary(Mid$(name, first - 1, 1))))
                End If
                If score > 0 And Not VfnNameBoundary(Mid$(name, first, 1)) Then
                    For last = first To Len(name)
                        If last - first + 1 > VfaMaxName Then Exit For
                        score = 0
                        If last = Len(name) Then
                            score = 1
                        ElseIf VfnNameBoundary(Mid$(name, last + 1, 1)) Then
                            score = 1
                        End If
                        If score > 0 Then
                            candidate = Mid$(name, first, last - first + 1)
                            score = VfnSpellingScore(candidate, query, key)
                            If score > best Then
                                best = score
                                VfnSourceName = candidate
                            End If
                        End If
                    Next last
                End If
            Next first
        End If
    Next i
End Function

Private Function VfnNameBoundary(ByVal ch As String) As Boolean
    VfnNameBoundary = VfaIsSpace(ch) Or ch = "-" Or ch = ChrW(&H2013) Or ch = ChrW(&H2014)
End Function

Private Function VfnSpellingScore(ByVal candidate As String, ByVal query As String, ByVal key As String) As Long
    Dim normalized As String, compact As String, limit As Long
    normalized = VefeyatNormalize(candidate)
    compact = Replace(normalized, " ", "")
    If normalized = VefeyatNormalize(query) Then
        VfnSpellingScore = 4
    ElseIf compact = key Then
        VfnSpellingScore = 3
    ElseIf VfCollapseLetters(compact) = VfCollapseLetters(key) Then
        VfnSpellingScore = 2
    ElseIf Len(key) >= 5 Then
        limit = 1
        If Len(key) >= 9 Then limit = 2
        If VfNearWord(compact, key, limit) Then VfnSpellingScore = 1
    End If
End Function

Private Function VfnHasSuffix(ByVal value As String) As Boolean
    Dim plain As String, at As Long, suffix As String
    plain = Replace(value, ChrW(&H2019), "'")
    at = InStrRev(plain, "'")
    If at = 0 Then Exit Function
    suffix = VefeyatNormalize(Mid$(plain, at + 1))
    Select Case suffix
        Case "in", "nin", "un", "nun", "a", "e", "ya", "ye", "i", "u", "yi", "yu", _
             "da", "de", "ta", "te", "dan", "den", "tan", "ten", "la", "le", "yla", "yle"
            VfnHasSuffix = True
    End Select
End Function

Private Function VfnAdjacentField(ByVal doc As Word.Document, ByVal name As Word.Range) As Word.Field
    Dim region As Word.Range, field As Word.Field
    For Each region In VfaRegions(doc)
        If name.InStory(region) Then
            For Each field In region.Fields
                If field.Code.Start - 1 = name.End Then
                    If Len(VfaFieldBinding(doc, field)) > 0 Then
                        Set VfnAdjacentField = field
                        Exit Function
                    End If
                End If
            Next field
        End If
    Next region
End Function

Public Sub Vefeyat036UiOnLoad(ByVal ribbon As Object)
    mVflSuspended = False
    mVflPending = False
    Set mVflStates = Nothing
    If Not mVfrEvents Is Nothing Then mVfrEvents.Detach
    Set mVfrRibbon = ribbon
    Set mVfrEvents = New VefeyatOlaylar036
    mVfrEvents.Attach Application, ribbon
    VflArm
End Sub

Public Sub Vefeyat036UiInvalidate()
    If Not mVfrRibbon Is Nothing Then mVfrRibbon.Invalidate
End Sub

Public Function Vefeyat036UiReady() As Boolean
    Vefeyat036UiReady = Not mVfrRibbon Is Nothing
End Function

Public Sub Vefeyat036UiInsert(ByVal control As Object)
    Vefeyat036OlumTarihiEkle
End Sub

Public Sub Vefeyat036OlumTarihiEkle()
    On Error GoTo Failed
    mVflSuspended = True
    Application.StatusBar = VfText("Vefey\u00e2t: se\u00e7ili ad aran\u0131yor...")
    VfaInsertSelected
    mVflSuspended = False
    VflCaptureCommand
    VflArm
    Vefeyat036UiInvalidate
    Exit Sub
Failed:
    mVflSuspended = False
    VfrReport Err.Description
End Sub

Public Sub Vefeyat036UiCanInsert(ByVal control As Object, ByRef enabled As Variant)
    On Error GoTo Unavailable
    ' Keep the command available in an editable document. The action validates
    ' the live selection and explains a rejected selection before any change.
    enabled = VfrEditableDocument()
    VflArm
    Exit Sub
Unavailable:
    enabled = False
End Sub

Public Sub Vefeyat036UiDisconnect()
    mVflSuspended = True
    If Not mVfrEvents Is Nothing Then mVfrEvents.Detach
    Set mVfrEvents = Nothing
    Set mVfrRibbon = Nothing
End Sub

Public Sub Vefeyat036UiDocumentEnabled(ByVal control As Object, ByRef enabled As Variant)
    enabled = VfrEditableDocument()
End Sub

Public Sub Vefeyat036UiGetPrefix(ByVal control As Object, ByRef selectedId As Variant)
    On Error GoTo DefaultValue
    If Application.Documents.Count > 0 Then
        selectedId = VfpGetPrefix(ActiveDocument)
        Exit Sub
    End If
DefaultValue:
    selectedId = "original"
End Sub

Public Sub Vefeyat036UiGetScope(ByVal control As Object, ByRef selectedId As Variant)
    On Error GoTo DefaultValue
    If Application.Documents.Count > 0 Then
        selectedId = VfpGetScope(ActiveDocument)
        Exit Sub
    End If
DefaultValue:
    selectedId = "first"
End Sub

Public Sub Vefeyat036UiSetPrefix(ByVal control As Object, ByVal selectedId As String, ByVal index As Integer)
    Dim undoObject As Object, undoStarted As Boolean, errorText As String
    On Error GoTo Failed
    If Not VfrEditableDocument() Then Exit Sub
    undoStarted = VfaBeginUndo(undoObject)
    VfpSetPrefix ActiveDocument, selectedId
    VfaRefreshDocument
    VflCaptureCommand
    VfaEndUndo undoObject, undoStarted
    Vefeyat036UiInvalidate
    Exit Sub
Failed:
    errorText = Err.Description
    VfaEndUndo undoObject, undoStarted
    VfrReport errorText
End Sub

Public Sub Vefeyat036UiSetScope(ByVal control As Object, ByVal selectedId As String, ByVal index As Integer)
    Dim undoObject As Object, undoStarted As Boolean, errorText As String
    On Error GoTo Failed
    If Not VfrEditableDocument() Then Exit Sub
    undoStarted = VfaBeginUndo(undoObject)
    VfpSetScope ActiveDocument, selectedId
    VfaRefreshDocument
    VflCaptureCommand
    VflArm
    VfaEndUndo undoObject, undoStarted
    Vefeyat036UiInvalidate
    Exit Sub
Failed:
    errorText = Err.Description
    VfaEndUndo undoObject, undoStarted
    VfrReport errorText
End Sub

Public Sub Vefeyat036UiRefresh(ByVal control As Object)
    Vefeyat036TarihleriGuncelle
End Sub

Public Sub Vefeyat036TarihleriGuncelle()
    On Error GoTo Failed
    VfaRefreshDocument
    Vefeyat036UiInvalidate
    Exit Sub
Failed:
    VfrReport Err.Description
End Sub

Public Sub Vefeyat036UiChooseCsv(ByVal control As Object)
    On Error GoTo Failed
    VefeyatChooseData
    Vefeyat036UiInvalidate
    Exit Sub
Failed:
    VfrReport Err.Description
End Sub

Public Function Vefeyat036UiFindPeople(ByVal query As String) As Collection
    Set Vefeyat036UiFindPeople = New Collection
    If Len(query) = 0 Or Len(query) > 200 Then Exit Function
    If Not VefeyatEnsureData() Then Exit Function
    Set Vefeyat036UiFindPeople = VefeyatFind(query)
End Function

Public Sub Vefeyat036UiSearch(ByVal control As Object)
    Dim picker As VefeyatKisiSec036, errorText As String
    On Error GoTo Failed
    mVflSuspended = True
    Set picker = New VefeyatKisiSec036
    picker.InitSearch
    picker.Show vbModal
    Unload picker
    mVflSuspended = False
    VflResetWait
    VflArm
    Exit Sub
Failed:
    errorText = Err.Description
    On Error Resume Next
    Unload picker
    On Error GoTo 0
    mVflSuspended = False
    VflArm
    VfrReport errorText
End Sub

Public Sub Vefeyat036UiProbe()
    ' Only acknowledge this code host in memory; never edit a document or timer.
    mVflProbePath = ThisDocument.FullName
End Sub

Public Sub Vefeyat036UiInfo(ByVal control As Object)
    On Error GoTo Failed
    If Not VefeyatEnsureData() Then Exit Sub
    VfMessage "Vefeyat " & VfrVersion & " - Akilli arama ve otomatik ekleme" & vbCrLf & _
           CStr(VefeyatRecordCount()) & VfText(" yerel kay\u0131t") & vbCrLf & vbCrLf & _
           "CSV: " & VefeyatDataPath() & vbCrLf & vbCrLf & _
           "Eklenti: " & ThisDocument.FullName & vbCrLf & vbCrLf & VflDiagnostic(), vbInformation, VfText("Vefey\u00e2t")
    Exit Sub
Failed:
    VfrReport Err.Description
End Sub

Public Sub Vefeyat036UiSpelling(ByVal control As Object)
    On Error GoTo Failed
    mVflSuspended = True
    VfnCheckSelected
    mVflSuspended = False
    VflArm
    Exit Sub
Failed:
    mVflSuspended = False
    VfrReport Err.Description
End Sub

Public Sub Vefeyat036UiHelp(ByVal control As Object)
    VfMessage VfText("Ad\u0131 se\u00e7in, sa\u011f t\u0131klay\u0131p \u00d6l\u00fcm tarihi ekle komutunu kullan\u0131n.") & _
        vbCrLf & VfText("Her eklemede \u015eahs\u0131 do\u011frulay\u0131n penceresi a\u00e7\u0131l\u0131r. Tek kay\u0131t olsa da tan\u0131t\u0131m\u0131n\u0131 kontrol edip Do\u011frula ve ekle'ye bas\u0131n.") & _
        vbCrLf & vbCrLf & VfText("Ekleme ayar\u0131, se\u00e7ti\u011finiz yaz\u0131mdaki ad\u0131n ana metin ve dipnotlarda birlikte ilk veya her ge\u00e7ti\u011fi yere uygulan\u0131r.") & _
        vbCrLf & VfText("K\u0131saltma ve ekleme tercihi bu belgeye kaydedilir. Ayar de\u011fi\u015fikli\u011fi yaln\u0131z Vefey\u00e2t'\u0131n ekledi\u011fi tarihleri g\u00fcnceller.") & _
        vbCrLf & vbCrLf & VfText("Her ge\u00e7ti\u011fi yere a\u00e7\u0131kken bu belgede do\u011frulad\u0131\u011f\u0131n\u0131z ayn\u0131 ad\u0131 yaz\u0131p k\u0131sa s\u00fcre durun. Bo\u015fluk veya t\u0131klama gerekmez; tarih yan\u0131na eklenir.") & _
        vbCrLf & VfText("\u0130sim yaz\u0131m\u0131n\u0131 denetle se\u00e7ili ad i\u00e7in kaynak yaz\u0131m\u0131 \u00f6nerir. Yaln\u0131z onay\u0131n\u0131zla de\u011fi\u015ftirir.") & _
        vbCrLf & vbCrLf & VfText("Ctrl+Z ile belge i\u015flemini geri alabilirsiniz. Kaynak tarih metni ve yerel CSV korunur."), _
        vbInformation, VfText("Vefey\u00e2t kullan\u0131m\u0131")
End Sub

Private Function VfePickPerson(ByVal people As Collection, ByVal query As String, _
                              Optional ByVal spelling As Boolean = False) As Long
    Dim picker As VefeyatKisiSec036
    Dim errorNumber As Long, errorText As String
    On Error GoTo Failed
    Set picker = New VefeyatKisiSec036
    picker.InitCandidates people, query
    If spelling Then picker.SetSpellingMode
    picker.Show vbModal
    VfePickPerson = picker.ChosenIndex
    Unload picker
    Exit Function
Failed:
    errorNumber = Err.Number
    errorText = Err.Description
    On Error Resume Next
    Unload picker
    On Error GoTo 0
    Err.Raise errorNumber, "Vefeyat", errorText
End Function

Private Function VfrEditableDocument() As Boolean
    On Error GoTo Unavailable
    If Application.Documents.Count = 0 Then Exit Function
    If ActiveDocument.ReadOnly Then Exit Function
    If ActiveDocument.ProtectionType <> wdNoProtection Then Exit Function
    VfrEditableDocument = True
Unavailable:
End Function

Private Sub VfrReport(ByVal message As String)
    Application.StatusBar = VfText("Vefey\u00e2t i\u015flemi tamamlanamad\u0131.")
    VfMessage message, vbExclamation, VfText("Vefey\u00e2t")
End Sub

Public Sub Vefeyat0361Kur()
    Dim fso As Object, picker As Object, sourceXml As String, stage As String
    Dim root As String, rawTemplate As String, sourceDocument As Document, originalDocument As Document
    Dim sourceZip As String, unpacked As String, outputZip As String, checked As String
    Dim startup As String, installedPath As String, readyPath As String
    Dim completed As Boolean
    Dim previousVba As Variant, errorText As String, errorNumber As Long
    Dim incomingManifest As Object, outgoingManifest As Object
    On Error GoTo Failed
    If mVfsBusy Then Exit Sub
    mVfsBusy = True
    If Documents.Count > 0 Then Set originalDocument = ActiveDocument
    Set sourceDocument = VfsRequireSource()
    VfsCheckDispatch sourceDocument
    If VfpRunPolicyChecks() < 1 Then VfsFail VfText("Tarih bi\u00e7imlendirme denetimi ba\u015far\u0131s\u0131z oldu.")
    If VfaRunLookupChecks() < 1 Then VfsFail VfText("Ki\u015fi arama denetimi ba\u015far\u0131s\u0131z oldu.")
    Set fso = CreateObject("Scripting.FileSystemObject")
    Set picker = Application.FileDialog(3)
    With picker
        .Title = VfText("Vefey\u00e2t kurulumu: paketteki VefeyatRibbon.xml dosyas\u0131n\u0131 se\u00e7in")
        .AllowMultiSelect = False
        .Filters.Clear
        .Filters.Add "Vefeyat Ribbon XML", "*.xml"
        If .Show <> -1 Then GoTo Finished
        sourceXml = CStr(.SelectedItems(1))
    End With
    VfsRequireLocal fso, sourceXml
    If StrComp(fso.GetFileName(sourceXml), VfsRibbonName, vbTextCompare) <> 0 Then
        VfsFail VfText("L\u00fctfen paketteki VefeyatRibbon.xml dosyas\u0131n\u0131 se\u00e7in.")
    End If
    VfsValidateRibbon sourceXml
    root = fso.GetParentFolderName(VefeyatDataPath())
    VfsEnsureFolder fso, root & "\Setup"
    stage = root & "\Setup\" & fso.GetTempName
    fso.CreateFolder stage
    fso.CopyFile sourceXml, stage & "\" & VfsRibbonName, False
    VfsValidateRibbon stage & "\" & VfsRibbonName

    startup = Options.DefaultFilePath(wdStartupPath)
    If Len(startup) = 0 Then VfsFail VfText("Word ba\u015flang\u0131\u00e7 klas\u00f6r\u00fc tan\u0131ml\u0131 de\u011fil.")
    VfsRequireLocal fso, startup
    If StrComp(fso.GetAbsolutePathName(fso.GetParentFolderName(sourceDocument.FullName)), _
               fso.GetAbsolutePathName(fso.BuildPath(startup, ".")), vbTextCompare) = 0 Then
        VfsFail VfText("Haz\u0131rl\u0131k \u015fablonunu Word ba\u015flang\u0131\u00e7 klas\u00f6r\u00fcne kaydetmeyin. \u0130ndirilenler gibi ayr\u0131 bir klas\u00f6r kullan\u0131n.")
    End If
    installedPath = fso.BuildPath(startup, VfsTemplateName)

    ' The user creates this separate template and imports the three components.
    ' Save only that open preparation template. Normal is never copied or saved.
    VfsCheckComponents
    ' VBA code edits do not always dirty the document's Saved flag.
    sourceDocument.Saved = False
    sourceDocument.Save
    rawTemplate = stage & "\VefeyatRaw.dotm"
    VfsCopyPreparedTemplate fso, sourceDocument, rawTemplate

    sourceZip = stage & "\source.zip"
    fso.CopyFile rawTemplate, sourceZip, False
    unpacked = stage & "\unpacked"
    Set incomingManifest = VfsExtractZip(fso, sourceZip, unpacked)
    VfsRequirePart fso, unpacked, "[Content_Types].xml"
    VfsRequirePart fso, unpacked, "_rels\.rels"
    VfsRequirePart fso, unpacked, "word\vbaProject.bin"
    previousVba = VfsReadBytes(unpacked & "\word\vbaProject.bin")
    VfsInjectRibbon fso, unpacked, stage & "\" & VfsRibbonName
    Set outgoingManifest = VfsFolderManifest(fso, unpacked)
    outputZip = stage & "\ready.zip"
    VfsCreateZip fso, unpacked, outputZip, outgoingManifest

    ' Re-extract the finished archive and compare the actual files, not only names.
    checked = stage & "\checked"
    Set incomingManifest = VfsExtractZip(fso, outputZip, checked)
    VfsVerifyPackage fso, checked, outgoingManifest, previousVba
    readyPath = stage & "\" & VfsTemplateName
    fso.CopyFile outputZip, readyPath, False

    ' An existing add-in stays loaded and its Startup file stays untouched.
    ' Prepare a verified replacement outside Startup for a closed-Word copy.
    If fso.FileExists(installedPath) Or VfsOwnedLoaded(fso, installedPath) Then
        VfsStageUpdate fso, root, readyPath, installedPath, startup
        completed = True
        GoTo Finished
    End If

    ' A first installation has no existing file or loaded owned add-in.
    ' MoveFile refuses an unexpected destination created after the check.
    VfsEnsureFolder fso, startup
    fso.MoveFile readyPath, installedPath
    completed = True
    ' Loading now would leave two projects with the same callback module name:
    ' the open preparation template and its installed copy. Load on next start.
    VfMessage "Vefeyat eklenti dosyasi hazirlandi." & vbCrLf & vbCrLf & _
        "Calismanizi kaydedin ve Word'un BUTUN pencerelerini kapatin. Word'u yeniden acinca Vefeyat sekmesi yuklenir." & _
        vbCrLf & vbCrLf & "Hazirlik sablonunu gunluk kullanimda acmayin. CSV verileriniz bilgisayarinizda kalir.", _
        vbInformation, "Vefeyat"
    GoTo Finished
Failed:
    errorText = Err.Description
    errorNumber = Err.Number
    If errorNumber = 70 Or errorNumber = 75 Then
        errorText = errorText & vbCrLf & VfsRestartMessage()
    End If
    VfMessage VfText("Kurulum tamamlanamad\u0131: ") & errorText & vbCrLf & vbCrLf & _
        VfText("CSV verileriniz ve haz\u0131rl\u0131k \u015fablonundaki kaynak kod korunur."), vbExclamation, VfText("Vefey\u00e2t")
Finished:
    On Error Resume Next
    If Not originalDocument Is Nothing Then originalDocument.Activate
    ' Keep a failed stage for diagnosis and recovery; delete only a successful one.
    If completed And Len(stage) > 0 Then fso.DeleteFolder stage, False
    On Error GoTo 0
    mVfsBusy = False
End Sub

Public Sub Vefeyat036EklentiyiKaldir()
    Dim fso As Object, root As String, startup As String, installedPath As String
    Dim backupPath As String, wasInstalled As Boolean, removed As Boolean, sourceDocument As Document
    Dim errorText As String
    On Error GoTo Failed
    If mVfsBusy Then Exit Sub
    mVfsBusy = True
    Set sourceDocument = VfsRequireSource()
    Set fso = CreateObject("Scripting.FileSystemObject")
    startup = Options.DefaultFilePath(wdStartupPath)
    If Len(startup) = 0 Then VfsFail VfText("Word ba\u015flang\u0131\u00e7 klas\u00f6r\u00fc tan\u0131ml\u0131 de\u011fil.")
    VfsRequireLocal fso, startup
    installedPath = fso.BuildPath(startup, VfsTemplateName)
    If VfMessage(VfText("Vefey\u00e2t Word eklentisi kald\u0131r\u0131ls\u0131n m\u0131?") & vbCrLf & _
        installedPath & vbCrLf & vbCrLf & _
        VfText("CSV verileri, ayarlar ve haz\u0131rl\u0131k \u015fablonundaki kaynak kod korunacak."), _
        vbYesNo + vbQuestion + vbDefaultButton2, VfText("Vefey\u00e2t")) <> vbYes Then GoTo Finished
    wasInstalled = VfsUnloadOwnedAddin(fso, installedPath)
    If fso.FileExists(installedPath) Then
        If Not VfsCanReadExclusive(installedPath) Then VfsFail VfsRestartMessage()
        root = fso.GetParentFolderName(VefeyatDataPath())
        VfsEnsureFolder fso, root & "\Backups"
        backupPath = root & "\Backups\" & fso.GetBaseName(fso.GetTempName) & ".dotm"
        fso.MoveFile installedPath, backupPath
    End If
    removed = True
    VfMessage VfText("Vefey\u00e2t eklentisi kald\u0131r\u0131ld\u0131. CSV verileriniz, ayarlar\u0131n\u0131z ve kaynak kod korundu."), _
        vbInformation, VfText("Vefey\u00e2t")
    GoTo Finished
Failed:
    errorText = Err.Description
    On Error Resume Next
    If wasInstalled And Not removed Then errorText = errorText & vbCrLf & VfsRestartMessage()
    On Error GoTo 0
    VfMessage VfText("Eklenti kald\u0131r\u0131lamad\u0131: ") & errorText, vbExclamation, VfText("Vefey\u00e2t")
Finished:
    mVfsBusy = False
End Sub

Private Function VfsRequireSource() As Document
    Dim containerPath As String, candidate As Document
    ' Bind setup to the code's own host; MacroContainer is late-bound and can
    ' resolve differently when a global add-in and a preparation file coexist.
    containerPath = ThisDocument.FullName
    If StrComp(containerPath, NormalTemplate.FullName, vbTextCompare) = 0 Then
        VfsFail VfText("Kurulum Normal projesinden \u00e7al\u0131\u015ft\u0131r\u0131lamaz. Paketteki yeni haz\u0131rl\u0131k \u015fablonu ad\u0131mlar\u0131n\u0131 uygulay\u0131n.")
    End If
    For Each candidate In Documents
        If StrComp(candidate.FullName, containerPath, vbTextCompare) = 0 Then
            If StrComp(candidate.Name, VfsSourceTemplateName, vbTextCompare) <> 0 Or candidate.SaveFormat <> 15 Then
                VfsFail VfText("Bo\u015f bir belgeyi VefeyatHazirlik.dotm ad\u0131yla Word makro i\u00e7erebilen \u015fablonu olarak kaydedin ve bile\u015fenleri onun projesine al\u0131n.")
            End If
            If candidate.ReadOnly Or candidate.ProtectionType <> wdNoProtection Then
                VfsFail VfText("Haz\u0131rl\u0131k \u015fablonu d\u00fczenlenebilir olmal\u0131.")
            End If
            If candidate.Content.Text <> vbCr Or candidate.InlineShapes.Count > 0 Or _
               candidate.Shapes.Count > 0 Or candidate.Footnotes.Count > 0 Or candidate.Endnotes.Count > 0 Then
                VfsFail VfText("Haz\u0131rl\u0131k \u015fablonu bo\u015f bir belgeden olu\u015fturulmal\u0131; ki\u015fisel belge i\u00e7eri\u011fi i\u00e7ermemeli.")
            End If
            Set VfsRequireSource = candidate
            Exit Function
        End If
    Next candidate
    VfsFail VfText("VefeyatHazirlik.dotm dosyas\u0131n\u0131 Word'de Dosya > A\u00e7 ile d\u00fczenlemek i\u00e7in a\u00e7\u0131n. Kurulumu onun VefeyatEklenti036 mod\u00fcl\u00fcnden \u00e7al\u0131\u015ft\u0131r\u0131n.")
End Function

Private Sub VfsCheckDispatch(ByVal sourceDocument As Document)
    Dim detail As String, callback As String
    On Error GoTo Failed
    ' Word limits macro lookup to the current document/template context.
    sourceDocument.Activate
    mVflProbePath = vbNullString
    callback = VflMacroPath("Vefeyat036UiProbe")
    ' Probe a Public Sub, like the timer entry, without depending on a return value.
    Application.Run callback
    If StrComp(mVflProbePath, sourceDocument.FullName, vbTextCompare) <> 0 Then
        VfsFail "The callback did not acknowledge this preparation template."
    End If
    mVflProbePath = vbNullString
    Exit Sub
Failed:
    detail = Err.Description
    mVflProbePath = vbNullString
    VfsFail VfText("Haz\u0131rl\u0131k dosyas\u0131n\u0131n makro \u00e7a\u011fr\u0131s\u0131 do\u011frulanamad\u0131. Paketteki ana mod\u00fcl\u00fc haz\u0131rl\u0131k projesine bir kez i\u00e7e al\u0131n. \u00c7a\u011fr\u0131: ") & _
        callback & vbCrLf & VfText("Ayr\u0131nt\u0131: ") & detail
End Sub

Private Sub VfsCheckComponents()
    Dim picker As VefeyatKisiSec036, events As VefeyatOlaylar036
    Dim detail As String, confirmationVersion As Long
    On Error GoTo Failed
    Set events = New VefeyatOlaylar036
    Set picker = New VefeyatKisiSec036
    If picker.Controls.Count < 8 Then VfsFail "VefeyatKisiSec036 controls are incomplete."
    On Error Resume Next
    confirmationVersion = CLng(CallByName(picker, "ConfirmationVersion", VbMethod))
    Err.Clear
    On Error GoTo Failed
    If confirmationVersion <> 3 Then VfsFail VfText("Paketteki VefeyatKisiSec036.frm dosyas\u0131n\u0131 File > Import File ile haz\u0131rl\u0131k projesine al\u0131n. Form ve ana mod\u00fcl ayn\u0131 s\u00fcr\u00fcmden olmal\u0131.")
    Unload picker
    Set picker = Nothing
    Set events = Nothing
    Exit Sub
Failed:
    detail = Err.Description
    On Error Resume Next
    Unload picker
    Set picker = Nothing
    Set events = Nothing
    On Error GoTo 0
    VfsFail VfText("Haz\u0131rl\u0131k \u015fablonundaki ki\u015fi se\u00e7im penceresi y\u00fcklenemedi: ") & detail
End Sub

Private Sub VfsCopyPreparedTemplate(ByVal fso As Object, ByVal sourceDocument As Document, ByVal destination As String)
    Dim verified As Document
    Set verified = VfsRequireSource()
    If Not verified Is sourceDocument Then VfsFail "Preparation template changed."
    VfsRequireLocal fso, sourceDocument.FullName
    If Not sourceDocument.Saved Then VfsFail "Save the preparation template before copying."
    fso.CopyFile sourceDocument.FullName, destination, False
End Sub

Private Function VfsOwnedLoaded(ByVal fso As Object, ByVal fullName As String) As Boolean
    Dim addin As AddIn, actual As String, expected As String
    On Error GoTo Failed
    expected = fso.GetAbsolutePathName(fullName)
    For Each addin In AddIns
        If addin.Installed Then
            actual = fso.GetAbsolutePathName(fso.BuildPath(addin.Path, addin.Name))
            If StrComp(actual, expected, vbTextCompare) = 0 Then
                VfsOwnedLoaded = True
                Exit Function
            End If
        End If
    Next addin
    Exit Function
Failed:
    VfsFail "The existing Vefeyat add-in could not be checked. Close all Word windows before retrying."
End Function

Private Sub VfsStageUpdate(ByVal fso As Object, ByVal root As String, ByVal readyPath As String, _
                           ByVal installedPath As String, ByVal startup As String)
    Dim pendingFolder As String, pendingPath As String, notesPath As String
    Dim transactionFolder As String, stagedNotes As String, previousPending As String, previousNotes As String
    Dim backupPath As String, notes As String, expectedBytes As Variant
    Dim oldFileMoved As Boolean, oldNotesMoved As Boolean, newFileMoved As Boolean, newNotesMoved As Boolean
    Dim errorNumber As Long, errorText As String
    On Error GoTo Failed
    pendingFolder = fso.BuildPath(root, "Guncelleme")
    If Not VfsFolderOutsideStartup(fso, pendingFolder, startup) Then
        VfsFail "The update folder must be outside the Word Startup folder."
    End If
    VfsEnsureFolder fso, pendingFolder
    pendingPath = fso.BuildPath(pendingFolder, VfsTemplateName)
    notesPath = fso.BuildPath(pendingFolder, "GUNCELLEME.txt")
    transactionFolder = fso.GetParentFolderName(readyPath)
    stagedNotes = fso.BuildPath(transactionFolder, "GUNCELLEME.txt")
    previousPending = fso.BuildPath(transactionFolder, "onceki-guncelleme.dotm")
    previousNotes = fso.BuildPath(transactionFolder, "onceki-guncelleme.txt")
    expectedBytes = VfsReadBytes(readyPath)

    ' Reading a loaded file for a backup is best-effort. Never unload it.
    backupPath = VfsTryBackupInstalled(fso, root, installedPath)
    notes = "VEFEYAT GUNCELLEMESI HAZIR; HENUZ KURULMADI." & vbCrLf & _
        "SURUM: " & VfrVersion & vbCrLf & vbCrLf & _
        "Mevcut Word eklentisi degistirilmedi. Yeni dosya asagidaki klasorde hazirlandi." & vbCrLf & vbCrLf & _
        "KAYNAK DOSYA:" & vbCrLf & pendingPath & vbCrLf & vbCrLf & _
        "HEDEF KLASOR (Word'un gercek baslangic klasoru):" & vbCrLf & startup & vbCrLf & vbCrLf & _
        "HEDEF DOSYA:" & vbCrLf & installedPath & vbCrLf & vbCrLf & _
        "1. Acik belgelerinizi kaydedin ve Word'un BUTUN pencerelerini kapatin." & vbCrLf
    If Len(backupPath) > 0 Then
        notes = notes & "2. Onceki eklentinin dogrulanmis yedegi burada saklandi:" & vbCrLf & backupPath & vbCrLf
    Else
        notes = notes & "2. Otomatik yedek olusturulamadi. Word kapaliyken hedefte eski VefeyatEklenti.dotm varsa," & vbCrLf & _
            "   ONCE onu Word baslangic klasorunun DISINDA sececeginiz bir klasore yedekleyin." & vbCrLf
        If VfsFolderOutsideStartup(fso, fso.BuildPath(root, "Backups"), startup) Then
            notes = notes & "   Ornegin su yerel yedek klasorunu kullanabilirsiniz:" & vbCrLf & fso.BuildPath(root, "Backups") & vbCrLf
        End If
    End If
    notes = notes & "3. Dosya Gezgini ile YALNIZ yukaridaki KAYNAK DOSYAYI HEDEF KLASORE kopyalayin." & vbCrLf & _
        "   Hedefteki ayni adli VefeyatEklenti.dotm dosyasini degistirin." & vbCrLf & _
        "   GUNCELLEME.txt dosyasini veya hazirlik sablonunu baslangic klasorune kopyalamayin." & vbCrLf & _
        "4. Word'u yeniden acin ve normal bir belgeyle Vefeyat sekmesini deneyin." & vbCrLf & vbCrLf & _
        "CSV verileriniz ve hazirlik sablonunuz korunur. Bu dosya henuz otomatik olarak kurulmus degildir." & vbCrLf
    VfsWriteVerifiedUtf8 stagedNotes, notes

    ' Commit only the pending pair. Startup and its loaded add-in are untouched.
    If fso.FileExists(pendingPath) Then
        fso.MoveFile pendingPath, previousPending
        oldFileMoved = True
    End If
    If fso.FileExists(notesPath) Then
        fso.MoveFile notesPath, previousNotes
        oldNotesMoved = True
    End If
    fso.MoveFile readyPath, pendingPath
    newFileMoved = True
    fso.MoveFile stagedNotes, notesPath
    newNotesMoved = True
    If Not VfsBytesEqual(expectedBytes, VfsReadBytes(pendingPath)) Then VfsFail "The pending update file changed."
    If VfsReadUtf8(notesPath) <> notes Then VfsFail "The pending update instructions changed."
    VfMessage "Guncelleme hazirlandi; HENUZ KURULMADI." & vbCrLf & vbCrLf & _
        "Mevcut eklenti acik Word icinde degistirilmedi." & vbCrLf & vbCrLf & _
        "Word'un BUTUN pencerelerini kapatin. Sonra GUNCELLEME.txt icindeki yedekleme ve dosya kopyalama adimlarini uygulayin." & _
        vbCrLf & vbCrLf & "Guncelleme klasoru:" & vbCrLf & pendingFolder & vbCrLf & vbCrLf & _
        "Hedef klasor:" & vbCrLf & startup, vbInformation, "Vefeyat"
    Exit Sub
Failed:
    errorNumber = Err.Number
    errorText = Err.Description
    On Error Resume Next
    If newNotesMoved Then fso.DeleteFile notesPath, False
    If newFileMoved Then fso.MoveFile pendingPath, readyPath
    If oldFileMoved Then fso.MoveFile previousPending, pendingPath
    If oldNotesMoved Then fso.MoveFile previousNotes, notesPath
    On Error GoTo 0
    Err.Raise errorNumber, "VefeyatSetup", errorText
End Sub

Private Function VfsFolderOutsideStartup(ByVal fso As Object, ByVal folderPath As String, ByVal startup As String) As Boolean
    Dim startupPrefix As String, candidatePrefix As String
    startupPrefix = fso.GetAbsolutePathName(fso.BuildPath(startup, "."))
    If Right$(startupPrefix, 1) <> "\" Then startupPrefix = startupPrefix & "\"
    candidatePrefix = fso.GetAbsolutePathName(fso.BuildPath(folderPath, "."))
    If Right$(candidatePrefix, 1) <> "\" Then candidatePrefix = candidatePrefix & "\"
    VfsFolderOutsideStartup = (StrComp(Left$(candidatePrefix, Len(startupPrefix)), startupPrefix, vbTextCompare) <> 0)
End Function

Private Function VfsTryBackupInstalled(ByVal fso As Object, ByVal root As String, ByVal installedPath As String) As String
    Dim backupPath As String
    On Error GoTo NotBackedUp
    If Not fso.FileExists(installedPath) Then Exit Function
    If Not VfsFolderOutsideStartup(fso, fso.BuildPath(root, "Backups"), fso.GetParentFolderName(installedPath)) Then Exit Function
    VfsEnsureFolder fso, fso.BuildPath(root, "Backups")
    backupPath = fso.BuildPath(fso.BuildPath(root, "Backups"), fso.GetBaseName(fso.GetTempName) & ".dotm")
    fso.CopyFile installedPath, backupPath, False
    If Not VfsBytesEqual(VfsReadBytes(installedPath), VfsReadBytes(backupPath)) Then GoTo NotBackedUp
    VfsTryBackupInstalled = backupPath
    Exit Function
NotBackedUp:
    On Error Resume Next
    If Len(backupPath) > 0 Then
        If fso.FileExists(backupPath) Then fso.DeleteFile backupPath, False
    End If
    Err.Clear
    On Error GoTo 0
End Function

Private Sub VfsWriteVerifiedUtf8(ByVal path As String, ByVal value As String)
    Dim stream As Object
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 2
    stream.Charset = "utf-8"
    stream.Open
    stream.WriteText value
    stream.SaveToFile path, 2
    stream.Close
    If VfsReadUtf8(path) <> value Then VfsFail "The update instructions could not be verified."
End Sub

Private Function VfsReadUtf8(ByVal path As String) As String
    Dim stream As Object
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 2
    stream.Charset = "utf-8"
    stream.Open
    stream.LoadFromFile path
    VfsReadUtf8 = stream.ReadText(-1)
    stream.Close
End Function

Private Function VfsUnloadOwnedAddin(ByVal fso As Object, ByVal fullName As String) As Boolean
    Dim addin As AddIn, actual As String
    On Error GoTo Failed
    For Each addin In AddIns
        actual = fso.BuildPath(addin.Path, addin.Name)
        If StrComp(fso.GetAbsolutePathName(actual), fso.GetAbsolutePathName(fullName), vbTextCompare) = 0 Then
            If addin.Installed Then
                addin.Installed = False
                VfsUnloadOwnedAddin = True
            End If
        End If
    Next addin
    Exit Function
Failed:
    VfsFail VfsRestartMessage()
End Function

Private Sub VfsRequireLocal(ByVal fso As Object, ByVal path As String)
    Dim driveName As String, drive As Object
    If Len(path) < 3 Then VfsFail VfText("Yerel dosya yolu gerekli.")
    If Mid$(path, 2, 2) <> ":\" Then VfsFail VfText("A\u011f yolu kullan\u0131lamaz; bilgisayar\u0131n\u0131zdaki bir dosyay\u0131 se\u00e7in.")
    driveName = fso.GetDriveName(path)
    If Len(driveName) = 0 Then VfsFail VfText("Yerel s\u00fcr\u00fcc\u00fc bulunamad\u0131.")
    Set drive = fso.GetDrive(driveName)
    If drive.DriveType = 3 Then VfsFail VfText("A\u011f s\u00fcr\u00fcc\u00fcs\u00fc kullan\u0131lamaz.")
End Sub

Private Sub VfsEnsureFolder(ByVal fso As Object, ByVal path As String)
    Dim parent As String
    If fso.FolderExists(path) Then Exit Sub
    parent = fso.GetParentFolderName(path)
    If Len(parent) = 0 Or parent = path Then VfsFail VfText("Klas\u00f6r olu\u015fturulamad\u0131: ") & path
    If Not fso.FolderExists(parent) Then VfsEnsureFolder fso, parent
    fso.CreateFolder path
End Sub

Private Function VfsLoadXml(ByVal path As String) As Object
    Dim dom As Object
    Set dom = CreateObject("MSXML2.DOMDocument.6.0")
    dom.async = False
    dom.validateOnParse = False
    dom.resolveExternals = False
    dom.setProperty "ProhibitDTD", True
    If Not dom.Load(path) Then VfsFail VfText("XML dosyas\u0131 okunamad\u0131: ") & dom.parseError.reason
    Set VfsLoadXml = dom
End Function

Private Sub VfsValidateRibbon(ByVal path As String)
    Dim fso As Object, dom As Object, attr As Object, element As Object, value As String
    Dim callbackCount As Long, name As String
    Set fso = CreateObject("Scripting.FileSystemObject")
    If Not fso.FileExists(path) Then VfsFail VfText("VefeyatRibbon.xml bulunamad\u0131.")
    If fso.GetFile(path).Size > 131072 Then VfsFail VfText("\u015eerit XML dosyas\u0131 beklenenden b\u00fcy\u00fck.")
    Set dom = VfsLoadXml(path)
    If dom.documentElement.baseName <> "customUI" Then VfsFail VfText("Ge\u00e7erli bir Vefey\u00e2t \u015ferit dosyas\u0131 gerekli.")
    If dom.documentElement.namespaceURI <> VfsUiNamespace Then VfsFail VfText("\u015eerit XML ad alan\u0131 ge\u00e7ersiz.")
    For Each element In dom.SelectNodes("//*")
        If element.namespaceURI <> VfsUiNamespace Then VfsFail VfText("\u015eerit dosyas\u0131 beklenmeyen bir XML ad alan\u0131 i\u00e7eriyor.")
    Next element
    For Each attr In dom.SelectNodes("//@*")
        name = attr.baseName
        If Left$(name, 3) = "get" Or Left$(name, 2) = "on" Or name = "loadImage" Then
            value = CStr(attr.nodeValue)
            If Not VfsValidCallback(value) Then VfsFail VfText("Beklenmeyen \u015ferit geri \u00e7a\u011fr\u0131s\u0131: ") & value
            callbackCount = callbackCount + 1
        End If
    Next attr
    If callbackCount = 0 Then VfsFail VfText("\u015eerit dosyas\u0131nda Vefey\u00e2t komutlar\u0131 bulunamad\u0131.")
End Sub

Private Function VfsValidCallback(ByVal value As String) As Boolean
    Dim prefix As String, suffix As String, i As Long, ch As String
    prefix = VfsInstalledModule & ".Vefeyat036Ui"
    If Left$(value, Len(prefix)) <> prefix Then Exit Function
    suffix = Mid$(value, Len(prefix) + 1)
    If Len(suffix) = 0 Then Exit Function
    For i = 1 To Len(suffix)
        ch = Mid$(suffix, i, 1)
        If InStr(1, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_", ch, vbBinaryCompare) = 0 Then Exit Function
    Next i
    VfsValidCallback = True
End Function

Private Sub VfsInjectRibbon(ByVal fso As Object, ByVal unpacked As String, ByVal ribbonPath As String)
    Dim rels As Object, types As Object, node As Object, found As Object
    Set rels = VfsLoadXml(unpacked & "\_rels\.rels")
    If rels.documentElement.namespaceURI <> VfsRelationshipsNamespace Then VfsFail "Invalid package relationships."
    rels.setProperty "SelectionNamespaces", "xmlns:r='" & VfsRelationshipsNamespace & "'"
    Set found = rels.SelectSingleNode("/r:Relationships/r:Relationship[@Type='" & VfsUiRelationship & "']")
    If Not found Is Nothing Then VfsFail "The fresh template already contains Ribbon customizations."
    Set found = rels.SelectSingleNode("/r:Relationships/r:Relationship[@Id='rIdVefeyatUI']")
    If Not found Is Nothing Then VfsFail "Package relationship identifier collision."
    Set node = rels.createNode(1, "Relationship", VfsRelationshipsNamespace)
    node.setAttribute "Id", "rIdVefeyatUI"
    node.setAttribute "Type", VfsUiRelationship
    node.setAttribute "Target", "/customUI/customUI14.xml"
    rels.documentElement.appendChild node
    rels.Save unpacked & "\_rels\.rels"
    Set types = VfsLoadXml(unpacked & "\[Content_Types].xml")
    If types.documentElement.namespaceURI <> VfsContentTypesNamespace Then VfsFail "Invalid package content types."
    types.setProperty "SelectionNamespaces", "xmlns:t='" & VfsContentTypesNamespace & "'"
    Set found = types.SelectSingleNode("/t:Types/t:Override[@PartName='/customUI/customUI14.xml']")
    If Not found Is Nothing Then VfsFail "The fresh template already declares the Ribbon part."
    Set node = types.createNode(1, "Override", VfsContentTypesNamespace)
    node.setAttribute "PartName", "/customUI/customUI14.xml"
    node.setAttribute "ContentType", "application/xml"
    types.documentElement.appendChild node
    types.Save unpacked & "\[Content_Types].xml"
    VfsEnsureFolder fso, unpacked & "\customUI"
    fso.CopyFile ribbonPath, unpacked & "\customUI\customUI14.xml", False
End Sub

Private Function VfsShellFolder(ByVal shell As Object, ByVal path As String) As Object
    Dim variantPath As Variant
    variantPath = path
    Set VfsShellFolder = shell.NameSpace(variantPath)
End Function

Private Function VfsExtractZip(ByVal fso As Object, ByVal zipPath As String, ByVal folderPath As String) As Object
    Dim shell As Object, archive As Object, folder As Object, manifest As Object
    Set shell = CreateObject("Shell.Application")
    Set archive = VfsShellFolder(shell, zipPath)
    If archive Is Nothing Then VfsFail VfText("Windows ZIP dosyas\u0131n\u0131 a\u00e7amad\u0131.")
    Set manifest = CreateObject("Scripting.Dictionary")
    VfsShellManifest archive, "", manifest
    If manifest.Count = 0 Then VfsFail "The Word ZIP package is empty."
    fso.CreateFolder folderPath
    Set folder = VfsShellFolder(shell, folderPath)
    If folder Is Nothing Then VfsFail "Windows could not open the staging folder."
    folder.CopyHere archive.Items, 1556
    VfsWaitForExtraction fso, folderPath, manifest
    Set folder = Nothing
    Set archive = Nothing
    Set shell = Nothing
    Set VfsExtractZip = manifest
End Function

Private Sub VfsShellManifest(ByVal folder As Object, ByVal relative As String, ByVal manifest As Object)
    Dim item As Object, child As Object, name As String, leaf As String
    For Each item In folder.Items
        ' Path preserves file extensions even when Explorer hides known extensions.
        leaf = CStr(item.Path)
        leaf = Mid$(leaf, InStrRev(leaf, "\") + 1)
        If Len(leaf) = 0 Or leaf = "." Or leaf = ".." Then VfsFail "Invalid ZIP package part name."
        If InStr(leaf, ":") > 0 Or InStr(leaf, "/") > 0 Then VfsFail "Invalid ZIP package part name."
        name = relative & leaf
        If item.IsFolder Then
            Set child = item.GetFolder
            VfsShellManifest child, name & "\", manifest
        Else
            If manifest.Exists(name) Then VfsFail "Duplicate ZIP package part."
            If CDbl(item.Size) > 33554432# Then VfsFail "Unexpectedly large package part."
            manifest.Add name, CDbl(item.Size)
        End If
    Next item
End Sub

Private Function VfsFolderManifest(ByVal fso As Object, ByVal folderPath As String) As Object
    Dim manifest As Object
    Set manifest = CreateObject("Scripting.Dictionary")
    VfsAddFolderFiles fso.GetFolder(folderPath), "", manifest
    Set VfsFolderManifest = manifest
End Function

Private Sub VfsAddFolderFiles(ByVal folder As Object, ByVal relative As String, ByVal manifest As Object)
    Dim file As Object, child As Object
    For Each file In folder.Files
        If CDbl(file.Size) > 33554432# Then VfsFail "Unexpectedly large package part."
        manifest.Add relative & CStr(file.Name), CDbl(file.Size)
    Next file
    For Each child In folder.SubFolders
        VfsAddFolderFiles child, relative & CStr(child.Name) & "\", manifest
    Next child
End Sub

Private Function VfsFilesReady(ByVal fso As Object, ByVal folderPath As String, ByVal manifest As Object) As Boolean
    Dim key As Variant, path As String
    On Error GoTo NotReady
    For Each key In manifest.Keys
        path = folderPath & "\" & CStr(key)
        If Not fso.FileExists(path) Then Exit Function
        If CDbl(fso.GetFile(path).Size) <> CDbl(manifest(key)) Then Exit Function
        If Not VfsCanReadExclusive(path) Then Exit Function
    Next key
    VfsFilesReady = True
NotReady:
End Function

Private Sub VfsWaitForExtraction(ByVal fso As Object, ByVal folderPath As String, ByVal manifest As Object)
    Dim started As Single, stable As Single, lastPoll As Single, matched As Boolean
    started = Timer
    lastPoll = started
    Do
        If VfsElapsed(lastPoll) >= 0.1 Then
            lastPoll = Timer
            If VfsFilesReady(fso, folderPath, manifest) Then
                If Not matched Then stable = Timer
                matched = True
                If VfsElapsed(stable) >= 0.3 Then Exit Sub
            Else
                matched = False
            End If
        End If
        If VfsElapsed(started) > 60 Then VfsFail VfText("ZIP dosyas\u0131 zaman\u0131nda a\u00e7\u0131lamad\u0131. L\u00fctfen yeniden deneyin.")
        DoEvents
    Loop
End Sub

Private Sub VfsCreateZip(ByVal fso As Object, ByVal folderPath As String, ByVal zipPath As String, ByVal manifest As Object)
    Dim header(0 To 21) As Byte, fileNumber As Integer, opened As Boolean
    Dim shell As Object, archive As Object, folder As Object, errorText As String
    On Error GoTo Failed
    header(0) = 80
    header(1) = 75
    header(2) = 5
    header(3) = 6
    fileNumber = FreeFile
    Open zipPath For Binary Access Write As #fileNumber
    opened = True
    Put #fileNumber, , header
    Close #fileNumber
    opened = False
    Set shell = CreateObject("Shell.Application")
    Set archive = VfsShellFolder(shell, zipPath)
    Set folder = VfsShellFolder(shell, folderPath)
    If archive Is Nothing Or folder Is Nothing Then VfsFail "Windows could not create the ZIP package."
    archive.CopyHere folder.Items, 1556
    VfsWaitForArchive fso, shell, zipPath, manifest
    Set archive = Nothing
    Set folder = Nothing
    Set shell = Nothing
    Exit Sub
Failed:
    errorText = Err.Description
    On Error Resume Next
    If opened Then Close #fileNumber
    On Error GoTo 0
    VfsFail errorText
End Sub

Private Sub VfsWaitForArchive(ByVal fso As Object, ByVal shell As Object, ByVal zipPath As String, ByVal manifest As Object)
    Dim started As Single, stable As Single, lastPoll As Single, matched As Boolean
    Dim previousSize As Double, currentSize As Double
    started = Timer
    lastPoll = started
    Do
        If VfsElapsed(lastPoll) >= 0.1 Then
            lastPoll = Timer
            currentSize = CDbl(fso.GetFile(zipPath).Size)
            If VfsArchiveMatches(shell, zipPath, manifest) And VfsCanReadExclusive(zipPath) Then
                If Not matched Or currentSize <> previousSize Then stable = Timer
                matched = True
                If VfsElapsed(stable) >= 0.5 Then Exit Sub
            Else
                matched = False
            End If
            previousSize = currentSize
        End If
        If VfsElapsed(started) > 60 Then VfsFail VfText("ZIP paketi tamamlanamad\u0131. Mevcut eklenti de\u011fi\u015ftirilmedi.")
        DoEvents
    Loop
End Sub

Private Function VfsArchiveMatches(ByVal shell As Object, ByVal zipPath As String, ByVal expected As Object) As Boolean
    Dim archive As Object, actual As Object, key As Variant
    On Error GoTo NotReady
    Set archive = VfsShellFolder(shell, zipPath)
    If archive Is Nothing Then Exit Function
    Set actual = CreateObject("Scripting.Dictionary")
    VfsShellManifest archive, "", actual
    If actual.Count <> expected.Count Then Exit Function
    For Each key In expected.Keys
        If Not actual.Exists(key) Then Exit Function
        If CDbl(actual(key)) <> CDbl(expected(key)) Then Exit Function
    Next key
    VfsArchiveMatches = True
NotReady:
End Function

Private Function VfsElapsed(ByVal started As Single) As Single
    Dim value As Single
    value = Timer - started
    If value < 0 Then value = value + 86400
    VfsElapsed = value
End Function

Private Function VfsCanReadExclusive(ByVal path As String) As Boolean
    Dim fileNumber As Integer, opened As Boolean
    On Error GoTo Failed
    fileNumber = FreeFile
    Open path For Binary Access Read Lock Read Write As #fileNumber
    opened = True
    Close #fileNumber
    opened = False
    VfsCanReadExclusive = True
    Exit Function
Failed:
    On Error Resume Next
    If opened Then Close #fileNumber
    On Error GoTo 0
End Function

Private Function VfsReadBytes(ByVal path As String) As Variant
    Dim stream As Object
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1
    stream.Open
    stream.LoadFromFile path
    VfsReadBytes = stream.Read
    stream.Close
End Function

Private Function VfsBytesEqual(ByVal first As Variant, ByVal second As Variant) As Boolean
    Dim i As Long
    If UBound(first) <> UBound(second) Then Exit Function
    If LBound(first) <> LBound(second) Then Exit Function
    For i = LBound(first) To UBound(first)
        If first(i) <> second(i) Then Exit Function
    Next i
    VfsBytesEqual = True
End Function

Private Sub VfsRequirePart(ByVal fso As Object, ByVal folderPath As String, ByVal relative As String)
    Dim path As String
    path = folderPath & "\" & relative
    If Not fso.FileExists(path) Then VfsFail "Missing Word package part: " & relative
    If fso.GetFile(path).Size = 0 Then VfsFail "Empty Word package part: " & relative
End Sub

Private Sub VfsVerifyPackage(ByVal fso As Object, ByVal folderPath As String, ByVal expected As Object, ByVal originalVba As Variant)
    Dim actual As Object, key As Variant, dom As Object, node As Object
    Set actual = VfsFolderManifest(fso, folderPath)
    If actual.Count <> expected.Count Then VfsFail "The ZIP package file count changed."
    For Each key In expected.Keys
        If Not actual.Exists(key) Then VfsFail "A verified ZIP package part is missing."
        If CDbl(actual(key)) <> CDbl(expected(key)) Then VfsFail "A verified ZIP package part has changed size."
    Next key
    VfsRequirePart fso, folderPath, "[Content_Types].xml"
    VfsRequirePart fso, folderPath, "_rels\.rels"
    VfsRequirePart fso, folderPath, "word\vbaProject.bin"
    VfsRequirePart fso, folderPath, "customUI\customUI14.xml"
    If Not VfsBytesEqual(originalVba, VfsReadBytes(folderPath & "\word\vbaProject.bin")) Then
        VfsFail "The VBA project changed while building the ZIP package."
    End If
    VfsValidateRibbon folderPath & "\customUI\customUI14.xml"
    Set dom = VfsLoadXml(folderPath & "\_rels\.rels")
    dom.setProperty "SelectionNamespaces", "xmlns:r='" & VfsRelationshipsNamespace & "'"
    Set node = dom.SelectSingleNode("/r:Relationships/r:Relationship[@Type='" & VfsUiRelationship & "']")
    If node Is Nothing Then VfsFail "The Ribbon package relationship is missing."
    If node.getAttribute("Target") <> "/customUI/customUI14.xml" Then VfsFail "The Ribbon package relationship is invalid."
    Set dom = VfsLoadXml(folderPath & "\[Content_Types].xml")
    dom.setProperty "SelectionNamespaces", "xmlns:t='" & VfsContentTypesNamespace & "'"
    Set node = dom.SelectSingleNode("/t:Types/t:Override[@PartName='/customUI/customUI14.xml']")
    If node Is Nothing Then VfsFail "The Ribbon content type is missing."
    If node.getAttribute("ContentType") <> "application/xml" Then VfsFail "The Ribbon content type is invalid."
End Sub

Private Function VfsRestartMessage() As String
    VfsRestartMessage = VfText("Eklenti dosyas\u0131 Word taraf\u0131ndan kullan\u0131l\u0131yor. \u00c7al\u0131\u015fman\u0131z\u0131 kaydedip t\u00fcm Word pencerelerini kapat\u0131n. Haz\u0131rl\u0131k \u015fablonunu daha sonra Dosya > A\u00e7 ile a\u00e7abilirsiniz.")
End Function

Private Sub VfsFail(ByVal message As String)
    Err.Raise vbObjectError + 2480, "VefeyatSetup", message
End Sub
