VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} VefeyatKisiSec0318
   Caption         =   "Vefeyat - Kisi secimi"
   ClientHeight    =   6480
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   9000
   OleObjectBlob   =   "VefeyatKisiSec0318.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "VefeyatKisiSec0318"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

#If VBA7 Then
Private Declare PtrSafe Function VfkActiveWindow Lib "user32" Alias "GetActiveWindow" () As LongPtr
Private Declare PtrSafe Function VfkClassNameW Lib "user32" Alias "GetClassNameW" (ByVal hwnd As LongPtr, ByVal buffer As LongPtr, ByVal size As Long) As Long
Private Declare PtrSafe Function VfkSetWindowTextW Lib "user32" Alias "SetWindowTextW" (ByVal hwnd As LongPtr, ByVal title As LongPtr) As Long
#Else
Private Declare Function VfkActiveWindow Lib "user32" Alias "GetActiveWindow" () As Long
Private Declare Function VfkClassNameW Lib "user32" Alias "GetClassNameW" (ByVal hwnd As Long, ByVal buffer As Long, ByVal size As Long) As Long
Private Declare Function VfkSetWindowTextW Lib "user32" Alias "SetWindowTextW" (ByVal hwnd As Long, ByVal title As Long) As Long
#End If


' Empty designer binary: Copyright (c) 2026 Samy Haliem, MIT License.
' See THIRD-PARTY-NOTICES.txt. All code below is Vefeyat source.

Private WithEvents mResults As MSForms.ListBox
Private WithEvents mChoose As MSForms.CommandButton
Private WithEvents mCancel As MSForms.CommandButton
Private WithEvents mSearch As MSForms.CommandButton
Private mQuery As MSForms.TextBox
Private mDetails As MSForms.TextBox
Private mPrompt As MSForms.Label
Private mRows As Collection
Private mBrowse As Boolean
Private mEarlier As Boolean
Private mDia As Boolean
Private mLiveReview As Boolean
Private mLiveCollapsed As Boolean
Private mLiveHeight As Single
Private mLiveVisibility As Object
Private mContext As MSForms.TextBox
Private mLiveNote As MSForms.Label
Private WithEvents mBack As MSForms.CommandButton
Private WithEvents mLocate As MSForms.CommandButton
Private WithEvents mToggle As MSForms.CommandButton
Private mSpelling As Boolean
Private mBatch As Boolean
Private mNameMode As Boolean
Private mReview As Boolean
Private mProgress As Boolean
Private mProgressStarted As Boolean
Private mAllowCancel As Boolean
Private mTrack As MSForms.Label
Private mFill As MSForms.Label
Private mNotice As MSForms.Label
Private mReviewExcluded As Object
Private WithEvents mStop As MSForms.CommandButton
Public StopRequested As Boolean

' One-based index in the candidates collection; 0 means cancellation.
Public ChosenIndex As Long

Public Function ConfirmationVersion() As Long
    ConfirmationVersion = 7
End Function

' Every record is a Variant array indexed 0..5:
' short name, full name, original name, death date, description, source link.
Public Sub InitCandidates(ByVal people As Collection, ByVal query As String)
    Dim i As Long, person As Variant
    Set mRows = people
    ChosenIndex = 0
    StopRequested = False
    mBatch = False
    mEarlier = False
    mDia = False
    mNameMode = False
    mReview = False
    mStop.Visible = False
    mResults.Clear
    mBrowse = False
    mChoose.Visible = True
    mCancel.Caption = VfkText("\u0130ptal")
    mPrompt.Caption = VfkText("Se\u00e7ili ad: ") & Left$(query, 100) & vbCrLf & CStr(people.Count) & _
        VfkText(" aday bulundu. Tan\u0131t\u0131m\u0131 kontrol edip eklemek istedi\u011finiz \u015fahs\u0131 do\u011frulay\u0131n.")
    For i = 1 To people.Count
        person = people(i)
        mResults.AddItem CStr(person(0))
        mResults.List(i - 1, 1) = CStr(person(3))
        mResults.List(i - 1, 2) = CStr(person(1))
    Next i
    mChoose.Enabled = False
    If people.Count > 0 Then
        mResults.ListIndex = 0
        mResults_Change
    Else
        mDetails.Text = VfkText("E\u015fle\u015fen \u015fah\u0131s bulunamad\u0131.")
    End If
End Sub

Public Sub InitLiveReview()
    Dim control As Object
    mLiveReview = True
    mProgress = False: mBrowse = False
    Me.Width = 340: Me.Height = 486
    Me.ScrollBars = fmScrollBarsVertical: Me.ScrollHeight = 460
    mPrompt.Left = 12: mPrompt.Top = 10: mPrompt.Width = 308: mPrompt.Height = 46
    For Each control In Me.Controls
        If control.Tag = "VefeyatHeading" Then control.Visible = False
    Next control
    Set mContext = Me.Controls.Add("Forms.TextBox.1", "LiveContext", True)
    With mContext
        .Left = 12: .Top = 62: .Width = 308: .Height = 80
        .MultiLine = True: .WordWrap = True: .Locked = True
        .ScrollBars = fmScrollBarsVertical
    End With
    mResults.Left = 12: mResults.Top = 152: mResults.Width = 308: mResults.Height = 82
    mResults.ColumnCount = 1: mResults.ColumnWidths = "288 pt"
    mDetails.Left = 12: mDetails.Top = 242: mDetails.Width = 308: mDetails.Height = 100
    Set mBack = Me.Controls.Add("Forms.CommandButton.1", "LiveBack", True)
    With mBack
        .Caption = VfkText("\u00d6nceki"): .Left = 12: .Top = 350: .Width = 94: .Height = 26
    End With
    Set mLocate = Me.Controls.Add("Forms.CommandButton.1", "LiveLocate", True)
    With mLocate
        .Caption = VfkText("Metinde g\u00f6ster"): .Left = 114: .Top = 350: .Width = 100: .Height = 26
    End With
    Set mToggle = Me.Controls.Add("Forms.CommandButton.1", "LiveToggle", True)
    With mToggle
        .Caption = VfkText("K\u00fc\u00e7\u00fclt"): .Left = 222: .Top = 350: .Width = 98: .Height = 26
    End With
    mChoose.Left = 12: mChoose.Top = 384: mChoose.Width = 148: mChoose.Height = 28
    mChoose.Caption = "Onayla ve sonraki": mChoose.Default = False
    mStop.Left = 170: mStop.Top = 384: mStop.Width = 150: mStop.Height = 28
    mStop.Caption = "Atla / Sonraki": mStop.Visible = True
    mCancel.Left = 222: mCancel.Top = 420: mCancel.Width = 98: mCancel.Height = 26
    mCancel.Caption = "Bitir": mCancel.Default = False
    Set mLiveNote = Me.Controls.Add("Forms.Label.1", "LiveNote", True)
    With mLiveNote
        .Left = 12: .Top = 418: .Width = 202: .Height = 40: .WordWrap = True: .Font.Size = 8
    End With
End Sub

Public Sub ShowLiveReview(ByVal people As Collection, ByVal heading As String, ByVal context As String, Optional ByVal choice As Long = 1)
    Dim i As Long, row As Variant
    If mLiveCollapsed Then mToggle_Click
    Set mRows = people
    mResults.Clear
    mPrompt.Caption = heading: mContext.Text = context
    For i = 1 To people.Count
        row = people(i)
        mResults.AddItem CStr(row(0)) & " | " & CStr(row(3))
    Next i
    mStop.Enabled = True: mLocate.Enabled = True
    If people.Count > 0 Then
        mResults.ListIndex = choice - 1
        mResults_Change
    Else
        mDetails.Text = VfkText("Bu ge\u00e7i\u015f i\u00e7in aday yok.")
        mChoose.Enabled = False
    End If
End Sub

Public Function LiveReviewChoice() As Long
    If mResults.ListIndex >= 0 Then LiveReviewChoice = mResults.ListIndex + 1
End Function

Public Sub LiveReviewStatus(ByVal canApply As Boolean, ByVal note As String, ByVal canBack As Boolean)
    mChoose.Enabled = canApply: mLiveNote.Caption = note: mBack.Enabled = canBack
End Sub

Public Sub LiveReviewDone(ByVal message As String)
    mPrompt.Caption = VfkText("Belge sonuna kadar inceleme tamamland\u0131.")
    mContext.Text = message: mResults.Clear
    mDetails.Text = VfkText("Yap\u0131lan eklemeler belgede kal\u0131r. Geri almak i\u00e7in Word\u0027e t\u0131klay\u0131p Ctrl+Z kullan\u0131n. Bitir ile pencereyi kapatabilirsiniz.")
    mChoose.Enabled = False: mStop.Enabled = False: mLocate.Enabled = False
    mLiveNote.Caption = ""
End Sub

Public Sub SetSideWarning()
    Me.Width = 340: Me.Height = 460
    Me.ScrollBars = fmScrollBarsVertical: Me.ScrollHeight = 432
    mPrompt.Width = 308: mPrompt.Height = 50
    mDetails.Left = 12: mDetails.Width = 308: mDetails.Top = 70: mDetails.Height = 320
    mStop.Left = 12: mStop.Top = 398: mStop.Width = 98
    mChoose.Left = 116: mChoose.Top = 398: mChoose.Width = 98
    mCancel.Left = 222: mCancel.Top = 398: mCancel.Width = 98
End Sub

Private Sub mBack_Click()
    VefeyatEklenti0318.Vefeyat0318UiReviewMove -1
End Sub
Private Sub mLocate_Click()
    VefeyatEklenti0318.Vefeyat0318UiReviewLocate
End Sub
Private Sub mToggle_Click()
    Dim control As Object
    If Not mLiveCollapsed Then
        Set mLiveVisibility = CreateObject("Scripting.Dictionary")
        For Each control In Me.Controls
            mLiveVisibility(control.Name) = control.Visible: control.Visible = False
        Next control
        mLiveHeight = Me.Height: Me.ScrollTop = 0: Me.Height = 64
        mToggle.Left = 12: mToggle.Top = 6: mToggle.Width = 308
        mToggle.Caption = VfkText("Denetim penceresini geni\u015flet"): mToggle.Visible = True
        mLiveCollapsed = True
    Else
        Me.Height = mLiveHeight
        For Each control In Me.Controls
            If mLiveVisibility.Exists(control.Name) Then control.Visible = CBool(mLiveVisibility(control.Name))
        Next control
        mToggle.Left = 222: mToggle.Top = 350: mToggle.Width = 98
        mToggle.Caption = VfkText("K\u00fc\u00e7\u00fclt"): mLiveCollapsed = False
    End If
End Sub

Public Sub InitEarlier(ByVal message As String)
    Dim control As Object
    mEarlier = True
    mBrowse = False
    mProgress = False
    ChosenIndex = 0
    mResults.Visible = False
    For Each control In Me.Controls
        If control.Tag = "VefeyatHeading" Then control.Visible = False
    Next control
    mPrompt.Caption = VfkText("Bu ad daha \u00f6nce ge\u00e7ti. Yapmak istedi\u011finiz i\u015flemi se\u00e7in.")
    mDetails.Top = 68
    mDetails.Height = 328
    mDetails.Text = message
    mChoose.Visible = True
    mChoose.Enabled = True
    mChoose.Default = False
    mChoose.Caption = "Yine de ekle"
    mStop.Visible = True
    mStop.Caption = VfkText("\u00d6nceki ge\u00e7i\u015fe git")
    mCancel.Caption = VfkText("Vazge\u00e7")
    mCancel.Default = True
End Sub

Public Sub SetDiaMode()
    mDia = True
    mChoose.Caption = VfkText("D\u0130A maddesini a\u00e7")
    mPrompt.Caption = VfkText("D\u0130A maddesini a\u00e7mak istedi\u011finiz \u015fahs\u0131 se\u00e7in. Belge metni de\u011fi\u015ftirilmez.")
End Sub

Public Sub InitSearch()
    Dim control As Object
    Set mRows = New Collection
    ChosenIndex = 0
    SetBrowseOnly
    mPrompt.Caption = VfkText("Yerel verilerde aranacak ad\u0131 yaz\u0131n ve Ara'ya bas\u0131n.")
    Me.Height = 520
    For Each control In Me.Controls
        If control.Tag = "VefeyatHeading" Then control.Top = 92
    Next control
    mResults.Top = 112
    mDetails.Top = 280
    mCancel.Top = 446
    mChoose.Top = 446
    mQuery.Visible = True
    mSearch.Visible = True
    mChoose.Default = False
    mSearch.Default = True
End Sub

Private Sub mSearch_Click()
    Dim people As Collection, query As String
    On Error GoTo Failed
    query = Trim$(mQuery.Text)
    If Len(query) = 0 Then Exit Sub
    If Len(query) > 200 Then
        mPrompt.Caption = VfkText("En fazla 200 karakterlik bir ad aray\u0131n.")
        Exit Sub
    End If
    Set people = VefeyatEklenti0318.Vefeyat0318UiFindPeople(query)
    InitCandidates people, query
    SetBrowseOnly
    If people.Count = 0 Then mPrompt.Caption = VfkText("Bu aramada kay\u0131t bulunamad\u0131.")
    Exit Sub
Failed:
    mPrompt.Caption = VfkText("Arama tamamlanamad\u0131: ") & Err.Description
End Sub

Public Sub SetSpellingMode()
    mSpelling = True
    mChoose.Caption = VfkText("\u015eahs\u0131 se\u00e7")
    mPrompt.Caption = VfkText("Se\u00e7ili ad\u0131n hangi \u015fahsa ait oldu\u011funu do\u011frulay\u0131n. Sonraki ad\u0131mda kaynak yaz\u0131m\u0131n\u0131 \u00f6nerece\u011fiz; hen\u00fcz metin de\u011fi\u015ftirilmez.")
End Sub

Public Sub SetBrowseOnly()
    mBrowse = True
    mChoose.Visible = False
    mCancel.Caption = VfkText("Kapat")
    mPrompt.Caption = VfkText("Yerel kay\u0131tlar: ayr\u0131nt\u0131lar i\u00e7in bir ki\u015fi se\u00e7in.")
End Sub

Public Sub SetScanMode(ByVal index As Long, ByVal total As Long)
    mBatch = True
    mStop.Caption = VfkText("Taramay\u0131 durdur")
    mCancel.Caption = VfkText("Bu ad\u0131 atla")
    mStop.Visible = True
    mPrompt.Caption = CStr(index) & " / " & CStr(total) & VfkText(" farkl\u0131 ad: ") & mPrompt.Caption
End Sub

Public Sub SetReviewMode()
    mReview = True
    Set mReviewExcluded = CreateObject("Scripting.Dictionary")
    mChoose.Caption = VfkText("Listeyi uygula")
    mStop.Caption = VfkText("D\u0131\u015fla / geri al")
    mStop.Visible = True
    mPrompt.Caption = VfkText("Son kontrol: listede kalan adlara belge ayar\u0131na g\u00f6re tarih eklenecek. Bir ad\u0131 \u00e7ift t\u0131klayarak d\u0131\u015flay\u0131n veya geri al\u0131n. \u0130ptal ederseniz belge de\u011fi\u015fmez.")
    mResults_Change
End Sub

Public Function ReviewIncludes(ByVal index As Long) As Boolean
    ReviewIncludes = Not mReviewExcluded.Exists(CStr(index))
End Function

Public Sub SetNameMode()
    mNameMode = True
    mChoose.Caption = VfkText("Bu yaz\u0131m\u0131 se\u00e7")
    mPrompt.Caption = VfkText("\u0130stedi\u011finiz ad bi\u00e7imini se\u00e7in: k\u0131sa yaz\u0131m, kaynak k\u0131sa ad\u0131, tam/uzun ad veya orijinal ad. Sonraki ad\u0131mda de\u011fi\u015fikli\u011fi onaylayabilirsiniz.")
    mResults_Change
End Sub

Private Sub mStop_Click()
    Dim key As String, row As Variant
    If mLiveReview Then
        VefeyatEklenti0318.Vefeyat0318UiReviewMove 1
        Exit Sub
    End If
    If mEarlier Then
        ChosenIndex = 2
        Me.Hide
        Exit Sub
    End If
    If mReview Then
        If mResults.ListIndex < 0 Then Exit Sub
        key = CStr(mResults.ListIndex + 1)
        row = mRows(mResults.ListIndex + 1)
        If mReviewExcluded.Exists(key) Then
            mReviewExcluded.Remove key
            mResults.List(mResults.ListIndex, 0) = CStr(row(0))
        Else
            mReviewExcluded.Add key, True
            mResults.List(mResults.ListIndex, 0) = "[-] " & CStr(row(0))
        End If
        Exit Sub
    End If
    StopRequested = True
    ChosenIndex = 0
    Me.Hide
End Sub

Private Sub UserForm_Initialize()
    Me.Caption = "Vefeyat"
    Me.Width = 640
    Me.Height = 490
    Me.Font.Name = "Segoe UI"
    Me.Font.Size = 10

    Set mPrompt = Me.Controls.Add("Forms.Label.1", "ResultPrompt", True)
    With mPrompt
        .Left = 16: .Top = 12: .Width = 600: .Height = 44
        .WordWrap = True
    End With

    Set mQuery = Me.Controls.Add("Forms.TextBox.1", "SearchQuery", True)
    With mQuery
        .Left = 16: .Top = 54: .Width = 480: .Height = 24
        .Visible = False
    End With
    Set mSearch = Me.Controls.Add("Forms.CommandButton.1", "SearchButton", True)
    With mSearch
        .Caption = "Ara"
        .Left = 510: .Top = 52: .Width = 106: .Height = 28
        .Visible = False
    End With

    AddHeading VfkText("K\u0131sa ad"), 16, 160
    AddHeading "Vefat tarihi", 176, 90
    AddHeading "Tam ad", 266, 350

    Set mResults = Me.Controls.Add("Forms.ListBox.1", "Results", True)
    With mResults
        .Left = 16: .Top = 82: .Width = 600: .Height = 155
        .ColumnCount = 3
        .ColumnWidths = "160 pt;90 pt;330 pt"
        .MultiSelect = fmMultiSelectSingle
        .TabIndex = 0
    End With

    Set mDetails = Me.Controls.Add("Forms.TextBox.1", "Details", True)
    With mDetails
        .Left = 16: .Top = 250: .Width = 600: .Height = 150
        .MultiLine = True
        .WordWrap = True
        .ScrollBars = fmScrollBarsVertical
        .Locked = True
        .TabIndex = 1
    End With

    Set mChoose = Me.Controls.Add("Forms.CommandButton.1", "ChooseButton", True)
    With mChoose
        .Caption = VfkText("Do\u011frula ve ekle")
        .Left = 370: .Top = 416: .Width = 132: .Height = 28
        .Default = True
        .Enabled = False
        .TabIndex = 2
    End With

    Set mStop = Me.Controls.Add("Forms.CommandButton.1", "StopScanButton", True)
    With mStop
        .Caption = VfkText("Taramay\u0131 durdur")
        .Left = 16: .Top = 416: .Width = 145: .Height = 28
        .Visible = False
    End With

    Set mCancel = Me.Controls.Add("Forms.CommandButton.1", "CancelButton", True)
    With mCancel
        .Caption = VfkText("\u0130ptal")
        .Left = 514: .Top = 416: .Width = 102: .Height = 28
        .Cancel = True
        .TabIndex = 3
    End With
End Sub

Private Sub UserForm_Activate()
    Dim title As String
    title = VfkText("Vefey\u00e2t: \u015fahs\u0131 do\u011frulay\u0131n")
    If mLiveReview Then title = VfkText("Vefey\u00e2t: metin \u00fczerinde denetim")
    If mEarlier Then title = VfkText("Vefey\u00e2t: daha \u00f6nce ge\u00e7ti")
    If mDia Then title = VfkText("Vefey\u00e2t: D\u0130A maddesini a\u00e7")
    If mSpelling Then title = VfkText("Vefey\u00e2t: isim yaz\u0131m\u0131n\u0131 denetle")
    If mReview Then title = VfkText("Vefey\u00e2t: belge taramas\u0131n\u0131 onaylay\u0131n")
    If mNameMode Then title = VfkText("Vefey\u00e2t: ad bi\u00e7imini se\u00e7in")
    If mProgress Then title = VfkText("Vefey\u00e2t: belge taramas\u0131")
    VfkSafeTitle title
    If mProgress Then
        If Not mProgressStarted Then
            mProgressStarted = True
            Me.Repaint
            VefeyatEklenti0318.Vefeyat0318UiRunAudit
        End If
        Exit Sub
    End If
    If mQuery.Visible Then mQuery.SetFocus
End Sub

' An active window can be the Word owner. Never rename an arbitrary window.
Private Function VfkFormClass(ByVal value As String) As Boolean
    Select Case LCase$(value)
        Case "thunderdframe", "thunderxframe"
            VfkFormClass = True
    End Select
End Function

Private Sub VfkSafeTitle(ByVal title As String)
    Dim buffer As String, length As Long
#If VBA7 Then
    Dim window As LongPtr
#Else
    Dim window As Long
#End If
    window = VfkActiveWindow()
    buffer = String$(64, vbNullChar)
    length = VfkClassNameW(window, StrPtr(buffer), 64)
    If length = 0 Then Exit Sub
    If Not VfkFormClass(Left$(buffer, length)) Then Exit Sub
    Call VfkSetWindowTextW(window, StrPtr(title))
End Sub

Public Sub InitProgress()
    Dim control As Object
    mProgress = True
    mProgressStarted = False
    mAllowCancel = True
    StopRequested = False
    Me.Width = 490
    Me.Height = 225
    For Each control In Me.Controls
        control.Visible = False
    Next control
    With mPrompt
        .Visible = True
        .Left = 16: .Top = 14: .Width = 448: .Height = 60
        .Caption = VfkText("Tarama haz\u0131rlan\u0131yor. Son onay\u0131n\u0131za kadar belge de\u011fi\u015ftirilmez.")
    End With
    Set mTrack = Me.Controls.Add("Forms.Label.1", "ProgressTrack", True)
    With mTrack
        .Left = 16: .Top = 82: .Width = 448: .Height = 12
        .BackColor = RGB(225, 230, 235)
    End With
    Set mFill = Me.Controls.Add("Forms.Label.1", "ProgressFill", True)
    With mFill
        .Left = 16: .Top = 82: .Width = 0: .Height = 12
        .BackColor = RGB(18, 100, 170)
    End With
    Set mNotice = Me.Controls.Add("Forms.Label.1", "ProgressNotice", True)
    With mNotice
        .Left = 16: .Top = 102: .Width = 448: .Height = 40
        .WordWrap = True
        .Caption = VfkText("Son onay\u0131n\u0131za kadar belgeniz de\u011fi\u015ftirilmez. Durdur ile \u00e7\u0131kabilirsiniz.")
    End With
    With mCancel
        .Visible = True
        .Left = 340: .Top = 158: .Width = 124
        .Caption = VfkText("Taramay\u0131 durdur")
    End With
End Sub

Public Sub UpdateProgress(ByVal stage As String, ByVal completed As Long, ByVal total As Long, ByVal allowCancel As Boolean)
    Dim fraction As Double
    mAllowCancel = allowCancel
    mCancel.Enabled = allowCancel
    If allowCancel Then
        mNotice.Caption = VfkText("Son onay\u0131n\u0131za kadar belgeniz de\u011fi\u015ftirilmez. Durdur ile \u00e7\u0131kabilirsiniz.")
        mCancel.Caption = VfkText("Taramay\u0131 durdur")
    Else
        mNotice.Caption = VfkText("Onaylad\u0131\u011f\u0131n\u0131z tarihler ekleniyor. \u0130\u015flem bitince belgenize d\u00f6nebilirsiniz.")
        mCancel.Caption = VfkText("Uygulan\u0131yor...")
    End If
    mPrompt.Caption = stage
    If total > 0 Then
        fraction = CDbl(completed) / CDbl(total)
        If fraction < 0 Then fraction = 0
        If fraction > 1 Then fraction = 1
        mFill.Width = CSng(fraction * mTrack.Width)
        mPrompt.Caption = stage & vbCrLf & CStr(completed) & " / " & CStr(total) & "  (%" & CStr(CLng(fraction * 100)) & ")"
    End If
End Sub

Private Sub mResults_Change()
    Dim row As Variant, description As String
    If mRows Is Nothing Then Exit Sub
    If mResults.ListIndex < 0 Then
        mDetails.Text = vbNullString
        mChoose.Enabled = False
        Exit Sub
    End If
    row = mRows(mResults.ListIndex + 1)
    description = Trim$(CStr(row(4)))
    If Len(description) = 0 Or description = "---" Then
        description = VfkText("Bu kay\u0131tta k\u0131sa tan\u0131t\u0131m bulunmuyor.")
    End If
    mDetails.Text = VfkText("K\u0131sa tan\u0131t\u0131m: ") & description & vbCrLf & vbCrLf & _
        VfkText("K\u0131sa ad: ") & CStr(row(0)) & vbCrLf & _
        "Tam ad: " & CStr(row(1)) & vbCrLf & _
        "Orijinal ad: " & CStr(row(2)) & vbCrLf & _
        "Vefat tarihi: " & CStr(row(3)) & vbCrLf & vbCrLf & _
        "Kaynak: " & CStr(row(5))
    If mReview Then
        mDetails.Text = VfkText("Belgedeki ad: ") & CStr(row(0)) & vbCrLf & _
            VfkText("Se\u00e7ilen \u015fah\u0131s: ") & CStr(row(1)) & vbCrLf & _
            "Tam ad: " & CStr(row(2)) & vbCrLf & "Vefat tarihi: " & CStr(row(3)) & vbCrLf & _
            description & vbCrLf & "Kaynak: " & CStr(row(5))
    End If
    If mNameMode Then
        mDetails.Text = VfkText("\u00d6nerilen yaz\u0131m: ") & CStr(row(0)) & vbCrLf & _
            VfkText("Ad bi\u00e7imi: ") & CStr(row(1)) & vbCrLf & description & vbCrLf & "Kaynak: " & CStr(row(5))
    End If
    mChoose.Enabled = True
    If mLiveReview Then VefeyatEklenti0318.Vefeyat0318UiReviewChoice
End Sub

Private Sub mResults_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    If mLiveReview Then
        VefeyatEklenti0318.Vefeyat0318UiReviewLocate
        Exit Sub
    End If
    If mReview Then
        mStop_Click
    Else
        mChoose_Click
    End If
End Sub

Private Sub mChoose_Click()
    If mLiveReview Then
        VefeyatEklenti0318.Vefeyat0318UiReviewApply LiveReviewChoice()
        Exit Sub
    End If
    If mEarlier Then
        ChosenIndex = 1
        Me.Hide
        Exit Sub
    End If
    If mBrowse Then Exit Sub
    If mResults.ListIndex < 0 Then Exit Sub
    ChosenIndex = mResults.ListIndex + 1
    Me.Hide
End Sub

Private Sub mCancel_Click()
    If mLiveReview Then
        VefeyatEklenti0318.Vefeyat0318UiReviewClose
        Exit Sub
    End If
    If mProgress Then
        If mAllowCancel Then
            StopRequested = True
            mCancel.Enabled = False
            mPrompt.Caption = VfkText("Tarama durduruluyor; belge de\u011fi\u015ftirilmedi.")
        End If
        Exit Sub
    End If
    ChosenIndex = 0
    Me.Hide
End Sub

Private Sub UserForm_QueryClose(Cancel As Integer, CloseMode As Integer)
    If CloseMode = vbFormControlMenu Then
        Cancel = True
        If mLiveReview Then
            VefeyatEklenti0318.Vefeyat0318UiReviewClose
            Exit Sub
        End If
        If mProgress Then
            mCancel_Click
            Exit Sub
        End If
        If mBatch Then StopRequested = True
        ChosenIndex = 0
        Me.Hide
    End If
End Sub

Private Sub AddHeading(ByVal text As String, ByVal x As Single, ByVal size As Single)
    Dim heading As MSForms.Label
    Set heading = Me.Controls.Add("Forms.Label.1")
    With heading
        .Caption = text
        .Tag = "VefeyatHeading"
        .Left = x
        .Top = 62
        .Width = size
        .Height = 16
        .Font.Bold = True
    End With
End Sub

' Decode ASCII source labels without depending on another module's helpers.
Private Function VfkText(ByVal escaped As String) As String
    Dim i As Long, j As Long, code As Long, digit As Long
    Dim result As String, valid As Boolean, part As String
    i = 1
    Do While i <= Len(escaped)
        If Mid$(escaped, i, 2) = "\u" And i + 5 <= Len(escaped) Then
            part = Mid$(escaped, i + 2, 4)
            code = 0
            valid = True
            For j = 1 To 4
                digit = InStr(1, "0123456789abcdef", LCase$(Mid$(part, j, 1)), vbBinaryCompare) - 1
                If digit < 0 Then
                    valid = False
                    Exit For
                End If
                code = code * 16 + digit
            Next j
            If valid Then
                If code > 32767 Then code = code - 65536
                result = result & ChrW(code)
                i = i + 6
            Else
                result = result & Mid$(escaped, i, 1)
                i = i + 1
            End If
        Else
            result = result & Mid$(escaped, i, 1)
            i = i + 1
        End If
    Loop
    VfkText = result
End Function
