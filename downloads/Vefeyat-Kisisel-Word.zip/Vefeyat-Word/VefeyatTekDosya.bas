Attribute VB_Name = "Vefeyat"
Option Explicit

' Local UTF-8 CSV catalog. No network, installer, or API declarations.
' Keep this source ASCII so it imports consistently into the VBA editor.
Private mVfRows As Collection
Private mVfSearchText() As String
Private mVfShortText() As String
Private mVfIndexReady As Boolean
Private mVfUniqueCounter As Long

Private Const VfwPageSize As Long = 5
Private Const VfwMaxName As Long = 200
Private Const VfwMaxDate As Long = 500
Private Const VfwMessageSize As Long = 850

' Import this source in Word's VBA editor. No installer or network is used.
' The data functions and VfText are provided by VefeyatData.bas.

Public Function VfText(ByVal escaped As String) As String
    Dim i As Long, j As Long, code As Long, digit As Long
    Dim part As String, result As String, valid As Boolean
    i = 1
    Do While i <= Len(escaped)
        If Mid$(escaped, i, 2) = "\u" And i + 5 <= Len(escaped) Then
            part = Mid$(escaped, i + 2, 4)
            valid = True
            code = 0
            For j = 1 To 4
                digit = InStr(1, "0123456789abcdef", LCase$(Mid$(part, j, 1)), vbBinaryCompare) - 1
                If digit < 0 Then
                    valid = False
                    Exit For
                End If
                code = code * 16 + digit
            Next j
            If valid Then
                If code > 32767 Then code = code - 65536
                result = result & ChrW(code)
                i = i + 6
            Else
                result = result & Mid$(escaped, i, 1)
                i = i + 1
            End If
        Else
            result = result & Mid$(escaped, i, 1)
            i = i + 1
        End If
    Loop
    VfText = result
End Function

Public Function VefeyatDataPath() As String
    Dim root As String
    root = Environ$("LOCALAPPDATA")
    If Len(root) = 0 Then VfFail "Windows LOCALAPPDATA folder is unavailable."
    If Right$(root, 1) = "\" Then root = Left$(root, Len(root) - 1)
    VfCheckLocalPath root
    VefeyatDataPath = root & "\Vefeyat\WordVBA\people.csv"
End Function

Public Function VefeyatEnsureData() As Boolean
    Dim fso As Object, catalogPath As String
    On Error GoTo Failed
    catalogPath = VefeyatDataPath()
    Set fso = CreateObject("Scripting.FileSystemObject")
    If Not fso.FileExists(catalogPath) Then
        If Not VfImportCatalog(False) Then Exit Function
    End If
    If mVfRows Is Nothing Then VfLoadCache catalogPath
    VefeyatEnsureData = True
    Exit Function
Failed:
    MsgBox VfText("Veriler a\u00e7\u0131lamad\u0131: ") & Err.Description, vbExclamation, "Vefeyat"
End Function

Public Sub VefeyatChooseData()
    On Error GoTo Failed
    If VfImportCatalog(True) Then
        ' A new import is loaded lazily; no old search index survives it.
        Set mVfRows = Nothing
        mVfIndexReady = False
    End If
    Exit Sub
Failed:
    MsgBox VfText("CSV al\u0131namad\u0131: ") & Err.Description, vbExclamation, "Vefeyat"
End Sub

Public Function VefeyatRecordCount() As Long
    If VefeyatEnsureData() Then VefeyatRecordCount = mVfRows.Count
End Function

Public Function VefeyatFind(ByVal query As String) As Collection
    Dim result As New Collection, exact As New Collection
    Dim prefix As New Collection, other As New Collection
    Dim term As String, tokens As Variant, token As Variant
    Dim row As Variant, i As Long, matches As Boolean
    Set VefeyatFind = result
    If Not VefeyatEnsureData() Then Exit Function
    term = VefeyatNormalize(query)
    If Len(term) = 0 Then Exit Function
    If Not mVfIndexReady Then VfBuildIndex
    tokens = Split(term, " ")
    For i = 1 To mVfRows.Count
        matches = True
        For Each token In tokens
            If InStr(1, mVfSearchText(i), CStr(token), vbBinaryCompare) = 0 Then
                matches = False
                Exit For
            End If
        Next token
        If matches Then
            row = mVfRows.Item(i)
            If mVfShortText(i) = term Then
                exact.Add row
            ElseIf Left$(mVfShortText(i), Len(term)) = term Then
                prefix.Add row
            Else
                other.Add row
            End If
        End If
    Next i
    For Each row In exact
        result.Add row
    Next row
    For Each row In prefix
        result.Add row
    Next row
    For Each row In other
        result.Add row
    Next row
End Function

Public Function VefeyatNormalize(ByVal text As String) As String
    Dim i As Long, code As Long, ch As String, result As String
    Dim pendingSpace As Boolean
    ' Fold Turkish I before lowercasing to avoid locale-specific results.
    text = Replace(text, ChrW(&H130), "i")
    text = Replace(text, ChrW(&H131), "i")
    text = Replace(text, "I", "i")
    text = LCase$(text)
    text = VfFoldLetters(text, "\u00e0\u00e1\u00e2\u00e3\u00e4\u00e5\u0101\u0103\u0105\u01ce", "a")
    text = VfFoldLetters(text, "\u00e7\u0107\u0109\u010b\u010d", "c")
    text = VfFoldLetters(text, "\u010f\u0111\u1e0d", "d")
    text = VfFoldLetters(text, "\u00e8\u00e9\u00ea\u00eb\u0113\u0115\u0117\u0119\u011b", "e")
    text = VfFoldLetters(text, "\u011d\u011f\u0121\u0123\u1e21", "g")
    text = VfFoldLetters(text, "\u0125\u0127\u1e25", "h")
    text = VfFoldLetters(text, "\u00ec\u00ed\u00ee\u00ef\u0129\u012b\u012d\u012f\u01d0", "i")
    text = VfFoldLetters(text, "\u0135", "j")
    text = VfFoldLetters(text, "\u0137\u1e33", "k")
    text = VfFoldLetters(text, "\u013a\u013c\u013e\u0142", "l")
    text = VfFoldLetters(text, "\u00f1\u0144\u0146\u0148\u1e45\u1e47", "n")
    text = VfFoldLetters(text, "\u00f2\u00f3\u00f4\u00f5\u00f6\u00f8\u014d\u014f\u0151\u01d2", "o")
    text = VfFoldLetters(text, "\u0155\u0157\u0159\u1e5b", "r")
    text = VfFoldLetters(text, "\u015b\u015d\u015f\u0161\u1e63", "s")
    text = VfFoldLetters(text, "\u0163\u0165\u0167\u1e6d", "t")
    text = VfFoldLetters(text, "\u00f9\u00fa\u00fb\u00fc\u0169\u016b\u016d\u016f\u0171\u0173\u01d4", "u")
    text = VfFoldLetters(text, "\u00fd\u00ff\u0177", "y")
    text = VfFoldLetters(text, "\u017a\u017c\u017e\u1e93", "z")
    text = Replace(text, ChrW(&HE6), "ae")
    text = Replace(text, ChrW(&H153), "oe")
    text = Replace(text, ChrW(&HDF), "ss")
    For i = 1 To Len(text)
        ch = Mid$(text, i, 1)
        code = AscW(ch)
        If code < 0 Then code = code + 65536
        If (code >= &H300 And code <= &H36F) Or (code >= &H64B And code <= &H65F) Then
            ' Combining accents and Arabic vocalization marks are not search terms.
        ElseIf VfIsSeparator(code) Then
            If Len(result) > 0 Then pendingSpace = True
        Else
            If pendingSpace Then result = result & " "
            result = result & ch
            pendingSpace = False
        End If
    Next i
    result = " " & result & " "
    Do While InStr(1, result, " ibni ", vbBinaryCompare) > 0
        result = Replace(result, " ibni ", " ibn ")
    Loop
    VefeyatNormalize = Trim$(result)
End Function

Private Function VfFoldLetters(ByVal text As String, ByVal escaped As String, ByVal plain As String) As String
    Dim letters As String, i As Long
    letters = VfText(escaped)
    For i = 1 To Len(letters)
        text = Replace(text, Mid$(letters, i, 1), plain)
    Next i
    VfFoldLetters = text
End Function

Private Function VfIsSeparator(ByVal code As Long) As Boolean
    If code <= 32 Or code = 127 Or code = &HA0 Or code = &HAD Then
        VfIsSeparator = True
    ElseIf code < 128 Then
        VfIsSeparator = Not ((code >= 48 And code <= 57) Or (code >= 97 And code <= 122))
    ElseIf (code >= &H2000 And code <= &H206F) Or (code >= &H2E00 And code <= &H2E7F) Then
        VfIsSeparator = True
    ElseIf code = &H60C Or code = &H61B Or code = &H61F Or code = &H640 Then
        VfIsSeparator = True
    ElseIf code = &HB4 Or code = &H2BB Or code = &H2BC Or code = &H2BE Or code = &H2BF Then
        VfIsSeparator = True
    ElseIf code = &HFEFF& Or code = &H3000 Or code = &HFF0C& Or code = &HFF1B& Then
        VfIsSeparator = True
    End If
End Function

Private Sub VfBuildIndex()
    Dim i As Long, row As Variant, combined As String
    If mVfRows.Count = 0 Then
        mVfIndexReady = True
        Exit Sub
    End If
    ReDim mVfSearchText(1 To mVfRows.Count)
    ReDim mVfShortText(1 To mVfRows.Count)
    For i = 1 To mVfRows.Count
        row = mVfRows.Item(i)
        mVfShortText(i) = VefeyatNormalize(CStr(row(0)))
        combined = CStr(row(0)) & " " & CStr(row(1)) & " " & CStr(row(2))
        combined = combined & " " & CStr(row(3)) & " " & CStr(row(4))
        mVfSearchText(i) = VefeyatNormalize(combined)
    Next i
    mVfIndexReady = True
End Sub

Private Sub VfLoadCache(ByVal path As String)
    Dim loaded As Collection
    Set loaded = VfReadCatalog(path)
    Set mVfRows = loaded
    mVfIndexReady = False
End Sub

Private Function VfImportCatalog(ByVal showSuccess As Boolean) As Boolean
    Dim dialog As Object, fso As Object, selectedPath As String
    Dim currentPath As String, folderPath As String, stagePath As String, backupPath As String
    Dim parsed As Collection, stagedRows As Collection
    Dim existed As Boolean, removedCurrent As Boolean, committed As Boolean
    Dim errorText As String, errorNumber As Long, restored As Boolean
    Set dialog = Application.FileDialog(3)
    With dialog
        .Title = VfText("Vefey\u00e2t: bilgisayar\u0131n\u0131zdaki CSV dosyas\u0131n\u0131 se\u00e7in")
        .AllowMultiSelect = False
        .Filters.Clear
        .Filters.Add "CSV", "*.csv"
        If .Show <> -1 Then Exit Function
        selectedPath = CStr(.SelectedItems(1))
    End With
    VfCheckLocalPath selectedPath
    Set fso = CreateObject("Scripting.FileSystemObject")
    currentPath = VefeyatDataPath()
    Set parsed = VfReadCatalog(selectedPath)
    If StrComp(fso.GetAbsolutePathName(selectedPath), currentPath, vbTextCompare) = 0 Then
        Set mVfRows = Nothing
        mVfIndexReady = False
        VfImportCatalog = True
        Exit Function
    End If
    existed = fso.FileExists(currentPath)
    If existed Then
        If MsgBox(VfText("Yerel veri kopyas\u0131 se\u00e7ti\u011finiz CSV ile de\u011fi\u015ftirilsin mi?") & _
            vbCrLf & VfText("Mevcut kopya ayn\u0131 klas\u00f6re yedeklenecek. Kaynak CSV de\u011fi\u015fmez."), _
            vbQuestion Or vbYesNo Or vbDefaultButton2, "Vefeyat") <> vbYes Then Exit Function
    End If
    On Error GoTo Failed
    folderPath = fso.GetParentFolderName(currentPath)
    VfEnsureFolder folderPath, fso
    stagePath = VfUniquePath(folderPath, "incoming-", ".tmp", fso)
    fso.CopyFile selectedPath, stagePath, False
    ' Validate the actual staged copy as well, before touching current data.
    Set stagedRows = VfReadCatalog(stagePath)
    If existed Then
        backupPath = VfUniquePath(folderPath, "people-backup-", ".csv", fso)
        fso.CopyFile currentPath, backupPath, False
        Kill currentPath
        removedCurrent = True
    End If
    fso.MoveFile stagePath, currentPath
    committed = True
    Set mVfRows = Nothing
    mVfIndexReady = False
    VfImportCatalog = True
    If showSuccess Then
        MsgBox CStr(stagedRows.Count) & VfText(" kay\u0131t al\u0131nd\u0131.") & vbCrLf & currentPath, _
            vbInformation, "Vefeyat"
    End If
    Exit Function
Failed:
    errorNumber = Err.Number
    errorText = Err.Description
    On Error Resume Next
    If removedCurrent And Not committed Then
        Err.Clear
        fso.CopyFile backupPath, currentPath, True
        restored = (Err.Number = 0)
    End If
    If Len(stagePath) > 0 Then
        If fso.FileExists(stagePath) Then fso.DeleteFile stagePath, True
    End If
    On Error GoTo 0
    If removedCurrent And Not committed And Not restored Then
        errorText = errorText & vbCrLf & "Restore the retained backup: " & backupPath
    End If
    Err.Raise errorNumber, "VefeyatData", errorText
End Function

Private Sub VfCheckLocalPath(ByVal path As String)
    Dim fso As Object, drive As Object
    ' Reject network/URL paths. Imported source data must be on a local drive.
    If Len(path) < 3 Then VfFail "Choose a CSV file on a local Windows drive."
    If Mid$(path, 2, 2) <> ":\" Then VfFail "Choose a CSV file on a local Windows drive."
    If InStr(1, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", UCase$(Left$(path, 1)), vbBinaryCompare) = 0 Then
        VfFail "Choose a CSV file on a local Windows drive."
    End If
    Set fso = CreateObject("Scripting.FileSystemObject")
    Set drive = fso.GetDrive(Left$(path, 2))
    If drive.DriveType = 3 Then VfFail "A network drive cannot hold the local catalog."
End Sub

Private Sub VfEnsureFolder(ByVal path As String, ByVal fso As Object)
    Dim parent As String
    If fso.FolderExists(path) Then Exit Sub
    parent = fso.GetParentFolderName(path)
    If Len(parent) = 0 Or parent = path Then VfFail "Cannot create the local data folder."
    If Not fso.FolderExists(parent) Then VfEnsureFolder parent, fso
    MkDir path
End Sub

Private Function VfUniquePath(ByVal folder As String, ByVal prefix As String, ByVal suffix As String, ByVal fso As Object) As String
    Dim candidate As String
    Do
        mVfUniqueCounter = mVfUniqueCounter + 1
        candidate = folder & "\" & prefix & Format$(Now, "yyyymmdd-hhnnss") & "-" & CStr(mVfUniqueCounter) & suffix
    Loop While fso.FileExists(candidate) Or fso.FolderExists(candidate)
    VfUniquePath = candidate
End Function

Private Function VfReadCatalog(ByVal path As String) As Collection
    Dim stream As Object, content As String, errorText As String, errorNumber As Long
    On Error GoTo Failed
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 2
    stream.Charset = "utf-8"
    stream.Open
    stream.LoadFromFile path
    content = stream.ReadText(-1)
    stream.Close
    Set stream = Nothing
    If Len(content) > 0 Then
        If Left$(content, 1) = ChrW(&HFEFF) Then content = Mid$(content, 2)
    End If
    Set VfReadCatalog = VfParseCsv(content)
    Exit Function
Failed:
    errorNumber = Err.Number
    errorText = Err.Description
    On Error Resume Next
    If Not stream Is Nothing Then stream.Close
    On Error GoTo 0
    Err.Raise errorNumber, "VefeyatData", errorText
End Function

Private Function VfParseCsv(ByVal content As String) As Collection
    Dim rows As New Collection, fields As New Collection
    Dim fieldValue As String, ch As String, state As Long
    Dim i As Long, lineNumber As Long, recordLine As Long
    Dim recordStarted As Boolean, haveHeader As Boolean
    lineNumber = 1
    recordLine = 1
    i = 1
    Do While i <= Len(content)
        ch = Mid$(content, i, 1)
        If state = 1 Then
            If ch = """" Then
                If Mid$(content, i + 1, 1) = """" Then
                    fieldValue = fieldValue & """"
                    i = i + 1
                Else
                    state = 2
                End If
            Else
                fieldValue = fieldValue & ch
                If ch = vbLf Then lineNumber = lineNumber + 1
            End If
        Else
            If state = 2 And ch <> ";" And ch <> vbCr And ch <> vbLf Then
                VfCsvFail lineNumber, "Unexpected text after a closing quote."
            End If
            Select Case ch
                Case """"
                    If Len(fieldValue) <> 0 Then VfCsvFail lineNumber, "Quote inside an unquoted field."
                    state = 1
                    recordStarted = True
                Case ";"
                    fields.Add fieldValue
                    fieldValue = ""
                    state = 0
                    recordStarted = True
                Case vbCr, vbLf
                    If recordStarted Or fields.Count > 0 Then
                        fields.Add fieldValue
                        VfAppendCsvRecord rows, fields, haveHeader, recordLine
                    End If
                    Set fields = New Collection
                    fieldValue = ""
                    state = 0
                    recordStarted = False
                    If ch = vbCr And Mid$(content, i + 1, 1) = vbLf Then i = i + 1
                    lineNumber = lineNumber + 1
                    recordLine = lineNumber
                Case Else
                    fieldValue = fieldValue & ch
                    recordStarted = True
            End Select
        End If
        i = i + 1
    Loop
    If state = 1 Then VfCsvFail recordLine, "Unclosed quoted field."
    If recordStarted Or fields.Count > 0 Then
        fields.Add fieldValue
        VfAppendCsvRecord rows, fields, haveHeader, recordLine
    End If
    If Not haveHeader Then VfFail "The CSV file has no header."
    If rows.Count = 0 Then VfFail "The CSV file contains no people."
    Set VfParseCsv = rows
End Function

Private Sub VfAppendCsvRecord(ByVal rows As Collection, ByVal fields As Collection, ByRef haveHeader As Boolean, ByVal lineNumber As Long)
    Dim expected As Variant, row As Variant, i As Long
    If fields.Count <> 6 Then VfCsvFail lineNumber, "Expected exactly six semicolon-separated columns."
    If Not haveHeader Then
        expected = Array(VfText("K\u0131sa Ad"), "Tam Ad", "Orijinal Ad", "Vefat Tarihi", VfText("Tan\u0131t\u0131m"), "Kaynak Link")
        For i = 0 To 5
            If StrComp(CStr(fields.Item(i + 1)), CStr(expected(i)), vbBinaryCompare) <> 0 Then
                VfCsvFail lineNumber, "The six CSV headers do not match the expected catalog format."
            End If
        Next i
        haveHeader = True
        Exit Sub
    End If
    row = Array("", "", "", "", "", "")
    For i = 0 To 5
        row(i) = Trim$(CStr(fields.Item(i + 1)))
        If row(i) = "---" Then row(i) = ""
    Next i
    If Len(CStr(row(0))) = 0 Then VfCsvFail lineNumber, "A short name is required."
    rows.Add row
End Sub

Private Sub VfCsvFail(ByVal lineNumber As Long, ByVal message As String)
    VfFail "CSV line " & CStr(lineNumber) & ": " & message
End Sub

Private Sub VfFail(ByVal message As String)
    Err.Raise vbObjectError + 2141, "VefeyatData", message
End Sub

Public Sub VefeyatSeciliAdiAra()
    Dim targetDoc As Document
    Dim targetRange As Range
    Dim matches As Collection
    Dim originalText As String
    Dim query As String
    Dim originalStart As Long
    Dim originalEnd As Long
    Dim originalStory As Long
    Dim picked As Long
    Dim row As Variant
    Dim dateText As String
    Dim reason As String
    Dim preview As String
    Dim failure As String

    On Error GoTo Failed
    ' Capture the exact occurrence before a file picker or any other dialog.
    If Not VfwCaptureTarget(targetDoc, targetRange, originalText, query, _
                            originalStart, originalEnd, originalStory) Then GoTo Done
    If Not VefeyatEnsureData() Then GoTo Done
    Set matches = VefeyatFind(query)
    picked = VfwPickResult(matches, query)
    If picked = 0 Then GoTo Done
    row = matches.Item(picked)
    If Not VfwShowRecord(row) Then GoTo Done

    dateText = VfwTrimSpaces(CStr(row(3)))
    If Not VfwValidDate(dateText) Then
        VfwWarn VfText("Bu kayd\u0131n vefat tarihi bo\u015f, birden fazla sat\u0131r i\xe7eriyor veya 500 karakterden uzun. Belgeye bir \u015fey eklenmedi.")
        GoTo Done
    End If
    If Not VfwTargetIsCurrent(targetDoc, targetRange, originalText, _
                              originalStart, originalEnd, originalStory, reason) Then
        VfwWarn reason
        GoTo Done
    End If
    If VfwAlreadyHasDate(targetRange, originalText, dateText) Then
        VfwWarn VfText("Ayn\u0131 tarih se\xe7ili metnin sonunda veya hemen ard\u0131nda zaten var. Tarih yeniden eklenmedi.")
        GoTo Done
    End If

    preview = VfText("Se\xe7ti\u011finiz ad\u0131n sonuna bu tarih eklensin mi?") & vbCrLf & vbCrLf & _
              VfwTrimSpaces(originalText) & " " & dateText & vbCrLf & vbCrLf & _
              VfText("Tarih, veri taban\u0131ndaki yaz\u0131m\u0131yla eklenecek. Ad\u0131n mevcut bi\xe7imi korunacak.")
    If MsgBox(preview, vbYesNo + vbQuestion + vbDefaultButton2, VfwTitle()) <> vbYes Then GoTo Done

    ' Recheck after confirmation; never find a new occurrence by name.
    If Not VfwTargetIsCurrent(targetDoc, targetRange, originalText, _
                              originalStart, originalEnd, originalStory, reason) Then
        VfwWarn reason
        GoTo Done
    End If
    If VfwAlreadyHasDate(targetRange, originalText, dateText) Then
        VfwWarn VfText("Ayn\u0131 tarih zaten var. Tarih yeniden eklenmedi.")
        GoTo Done
    End If
    VfwInsertDate targetRange, originalText, dateText

Done:
    Set matches = Nothing
    Set targetRange = Nothing
    Set targetDoc = Nothing
    Exit Sub
Failed:
    failure = Err.Description
    VfwWarn VfText("Arama tamamlanamad\u0131. ") & VfwClip(failure, 450)
    Resume Done
End Sub

Public Sub VefeyatSahislariAra()
    Dim query As String
    Dim matches As Collection
    Dim picked As Long
    Dim row As Variant
    Dim failure As String

    On Error GoTo Failed
    If Not VefeyatEnsureData() Then GoTo Done
    query = VfwTrimSpaces(VBA.InputBox( _
        VfText("Aranacak \u015fahs\u0131n ad\u0131n\u0131 yaz\u0131n. Bu arama belgeye metin eklemez."), VfwTitle()))
    If Len(query) = 0 Then GoTo Done
    If Len(query) > VfwMaxName Or Not VfwSingleLine(query) Then
        VfwWarn VfText("Tek sat\u0131rda, en fazla 200 karakterlik bir ad yaz\u0131n.")
        GoTo Done
    End If
    Set matches = VefeyatFind(query)
    picked = VfwPickResult(matches, query)
    If picked = 0 Then GoTo Done
    row = matches.Item(picked)
    Call VfwShowRecord(row)
Done:
    Set matches = Nothing
    Exit Sub
Failed:
    failure = Err.Description
    VfwWarn VfText("Arama tamamlanamad\u0131. ") & VfwClip(failure, 450)
    Resume Done
End Sub

Public Sub VefeyatVeriSec()
    Dim failure As String
    On Error GoTo Failed
    VefeyatChooseData
    Exit Sub
Failed:
    failure = Err.Description
    VfwWarn VfText("Veri dosyas\u0131 se\xe7ilemedi. ") & VfwClip(failure, 450)
End Sub

Public Sub VefeyatBilgi()
    Dim message As String
    Dim failure As String
    On Error GoTo Failed
    If Not VefeyatEnsureData() Then Exit Sub
    message = VfText("Vefey\xe2t - Word i\xe7in \xe7evrimd\u0131\u015f\u0131 deneme") & vbCrLf & vbCrLf & _
              VfText("Kay\u0131t say\u0131s\u0131: ") & CStr(VefeyatRecordCount()) & vbCrLf & _
              VfText("Bu bilgisayardaki veri dosyas\u0131:") & vbCrLf & VefeyatDataPath() & vbCrLf & vbCrLf & _
              VfText("Veriler bu bilgisayarda saklan\u0131r. Sunucu, alan ad\u0131 ve Docker gerekmez. Kaynak ba\u011flant\u0131lar\u0131 metin olarak g\xf6sterilir; uygulama bunlar\u0131 a\xe7maz.")
    Call VfwShowTextPages(message, VfText("Bilgi"))
    Exit Sub
Failed:
    failure = Err.Description
    VfwWarn VfText("Bilgi g\xf6sterilemedi. ") & VfwClip(failure, 450)
End Sub

Private Function VfwCaptureTarget(ByRef targetDoc As Document, ByRef targetRange As Range, _
                                  ByRef originalText As String, ByRef query As String, _
                                  ByRef originalStart As Long, ByRef originalEnd As Long, _
                                  ByRef originalStory As Long) As Boolean
    Dim reason As String

    If Application.Documents.Count = 0 Then
        VfwWarn VfText("\xd6nce bir Word belgesi a\xe7\u0131n ve belge i\xe7indeki \u015fah\u0131s ad\u0131n\u0131 se\xe7in.")
        Exit Function
    End If
    If Selection.Type <> wdSelectionNormal Then
        VfwWarn VfText("Belgede tek bir \u015fah\u0131s ad\u0131n\u0131 normal metin se\xe7imiyle se\xe7in.")
        Exit Function
    End If
    Set targetDoc = ActiveDocument
    Set targetRange = Selection.Range.Duplicate
    originalText = targetRange.Text
    query = VfwTrimSpaces(originalText)
    If Len(query) = 0 Or Len(originalText) > VfwMaxName Or Not VfwSingleLine(originalText) Then
        VfwWarn VfText("Yaln\u0131zca tek sat\u0131rdaki \u015fah\u0131s ad\u0131n\u0131 se\xe7in (en fazla 200 karakter). Paragraf, sekme ve tablo h\xfccresi sonunu se\xe7ime katmay\u0131n.")
        Exit Function
    End If
    originalStart = targetRange.Start
    originalEnd = targetRange.End
    originalStory = targetRange.StoryType
    If Not VfwTargetIsCurrent(targetDoc, targetRange, originalText, _
                              originalStart, originalEnd, originalStory, reason) Then
        VfwWarn reason
        Exit Function
    End If
    VfwCaptureTarget = True
End Function

Private Function VfwTargetIsCurrent(ByVal targetDoc As Document, ByVal targetRange As Range, _
                                     ByVal originalText As String, ByVal originalStart As Long, _
                                     ByVal originalEnd As Long, ByVal originalStory As Long, _
                                     ByRef reason As String) As Boolean
    Dim currentDoc As Document
    Dim rangeDoc As Document
    Dim currentRange As Range

    reason = VfText("Belge veya se\xe7ili ad de\u011fi\u015fti. Tarih eklenmedi. Do\u011fru ad\u0131 yeniden se\xe7ip aramay\u0131 ba\u015flat\u0131n.")
    If Application.Documents.Count = 0 Then Exit Function
    Set currentDoc = ActiveDocument
    If currentDoc Is targetDoc Then
        ' The original document is still active.
    Else
        Exit Function
    End If
    Set rangeDoc = targetRange.Document
    If rangeDoc Is targetDoc Then
        ' The captured range still belongs to that document.
    Else
        Exit Function
    End If
    If Selection.Type <> wdSelectionNormal Then Exit Function
    Set currentRange = Selection.Range.Duplicate
    If Not currentRange.IsEqual(targetRange) Then Exit Function
    If targetRange.Start <> originalStart Or targetRange.End <> originalEnd Then Exit Function
    If targetRange.StoryType <> originalStory Or currentRange.StoryType <> originalStory Then Exit Function
    If StrComp(targetRange.Text, originalText, vbBinaryCompare) <> 0 Then Exit Function
    If StrComp(currentRange.Text, originalText, vbBinaryCompare) <> 0 Then Exit Function
    If targetDoc.ReadOnly Then
        reason = VfText("Bu belge salt okunur. Tarih eklenmedi.")
        Exit Function
    End If
    If targetDoc.ProtectionType <> wdNoProtection Then
        reason = VfText("Bu belge d\xfczenlemeye kar\u015f\u0131 korumal\u0131. Tarih eklenmedi.")
        Exit Function
    End If
    VfwTargetIsCurrent = True
End Function

Private Function VfwPickResult(ByVal matches As Collection, ByVal query As String) As Long
    Dim pageStart As Long
    Dim pageEnd As Long
    Dim answer As String
    Dim chosen As Long

    If matches Is Nothing Then Exit Function
    If matches.Count = 0 Then
        VfwWarn VfText("E\u015fle\u015fen kay\u0131t bulunamad\u0131. Ad\u0131n daha k\u0131sa bir b\xf6l\xfcm\xfcyle tekrar arayabilirsiniz.")
        Exit Function
    End If
    pageStart = 1
    Do
        pageEnd = pageStart + VfwPageSize - 1
        If pageEnd > matches.Count Then pageEnd = matches.Count
        answer = LCase$(Trim$(VBA.InputBox(VfwResultPage(matches, query, pageStart, pageEnd), VfwTitle())))
        Select Case answer
            Case "", "q"
                Exit Function
            Case "n"
                If pageEnd < matches.Count Then pageStart = pageEnd + 1
            Case "p"
                If pageStart > 1 Then pageStart = pageStart - VfwPageSize
            Case Else
                If VfwResultNumber(answer, pageStart, pageEnd, chosen) Then
                    VfwPickResult = chosen
                    Exit Function
                End If
                VfwWarn VfText("Bu sayfada g\xf6r\xfcnen bir kayd\u0131n numaras\u0131n\u0131 yaz\u0131n. Sonraki: n, \xf6nceki: p, vazge\xe7: q.")
        End Select
    Loop
End Function

Private Function VfwResultPage(ByVal matches As Collection, ByVal query As String, _
                                ByVal pageStart As Long, ByVal pageEnd As Long) As String
    Dim prompt As String
    Dim row As Variant
    Dim i As Long

    prompt = VfText("Arama: ") & VfwClip(query, 40) & vbCrLf & _
             VfText("Kay\u0131tlar: ") & CStr(pageStart) & "-" & CStr(pageEnd) & "/" & CStr(matches.Count) & vbCrLf & vbCrLf
    For i = pageStart To pageEnd
        row = matches.Item(i)
        prompt = prompt & CStr(i) & ") " & VfwClip(CStr(row(0)), 29) & " | " & _
                 VfwClip(CStr(row(3)), 22) & vbCrLf & "    " & _
                 VfwClip(CStr(row(2)), 20) & " - " & VfwClip(CStr(row(4)), 29) & vbCrLf
    Next i
    prompt = prompt & vbCrLf & VfText("Ayr\u0131nt\u0131lar i\xe7in kay\u0131t numaras\u0131n\u0131 yaz\u0131n.") & vbCrLf & _
             VfText("Sonraki: n   \xd6nceki: p   Vazge\xe7: q veya \u0130ptal")
    VfwResultPage = prompt
End Function

Private Function VfwResultNumber(ByVal answer As String, ByVal first As Long, _
                                  ByVal last As Long, ByRef chosen As Long) As Boolean
    Dim i As Long
    Dim digit As Long
    Dim number As Double

    If Len(answer) = 0 Or Len(answer) > 10 Then Exit Function
    For i = 1 To Len(answer)
        digit = AscW(Mid$(answer, i, 1)) - 48
        If digit < 0 Or digit > 9 Then Exit Function
        number = number * 10 + digit
        If number > last Then Exit Function
    Next i
    If number < first Then Exit Function
    chosen = CLng(number)
    VfwResultNumber = True
End Function

Private Function VfwShowRecord(ByRef row As Variant) As Boolean
    Dim message As String
    message = VfText("K\u0131sa ad: ") & CStr(row(0)) & vbCrLf & _
              VfText("Tam ad: ") & CStr(row(1)) & vbCrLf & _
              VfText("Orijinal ad: ") & CStr(row(2)) & vbCrLf & _
              VfText("Vefat tarihi: ") & CStr(row(3)) & vbCrLf & vbCrLf & _
              VfText("Tan\u0131t\u0131m:") & vbCrLf & CStr(row(4)) & vbCrLf & vbCrLf & _
              VfText("Kaynak (yaln\u0131zca metin):") & vbCrLf & CStr(row(5))
    VfwShowRecord = VfwShowTextPages(message, VfText("Kay\u0131t ayr\u0131nt\u0131lar\u0131"))
End Function

Private Function VfwShowTextPages(ByVal message As String, ByVal subtitle As String) As Boolean
    Dim offset As Long
    Dim count As Long
    Dim page As Long
    Dim chunk As String
    Dim title As String
    Dim lastCode As Long
    Dim nextCode As Long

    offset = 1
    page = 1
    Do While offset <= Len(message)
        count = VfwMessageSize
        If offset + count - 1 > Len(message) Then count = Len(message) - offset + 1
        ' Do not split a UTF-16 surrogate pair across dialog pages.
        lastCode = AscW(Mid$(message, offset + count - 1, 1)) And &HFFFF&
        If count > 1 And offset + count - 1 < Len(message) Then
            nextCode = AscW(Mid$(message, offset + count, 1)) And &HFFFF&
            If lastCode >= &HD800& And lastCode <= &HDBFF& And _
               nextCode >= &HDC00& And nextCode <= &HDFFF& Then count = count - 1
        End If
        chunk = Mid$(message, offset, count)
        title = VfwTitle() & " - " & subtitle
        If Len(message) > VfwMessageSize Then title = title & " (" & CStr(page) & ")"
        If MsgBox(chunk, vbOKCancel + vbInformation, title) <> vbOK Then Exit Function
        offset = offset + count
        page = page + 1
    Loop
    VfwShowTextPages = True
End Function

Private Function VfwValidDate(ByVal dateText As String) As Boolean
    If Len(dateText) = 0 Or Len(dateText) > VfwMaxDate Then Exit Function
    VfwValidDate = VfwSingleLine(dateText)
End Function

Private Function VfwSingleLine(ByVal text As String) As Boolean
    Dim i As Long
    Dim code As Long
    For i = 1 To Len(text)
        code = AscW(Mid$(text, i, 1)) And &HFFFF&
        If code < 32 Or code = 127 Or code = 133 Or code = 8232 Or code = 8233 Then Exit Function
    Next i
    VfwSingleLine = True
End Function

Private Function VfwAlreadyHasDate(ByVal targetRange As Range, ByVal originalText As String, _
                                    ByVal dateText As String) As Boolean
    Dim normalizedDate As String
    Dim normalizedName As String
    Dim normalizedAfter As String
    Dim following As Range

    normalizedDate = VfwNormalizeWhitespace(dateText)
    normalizedName = VfwNormalizeWhitespace(originalText)
    If Len(normalizedName) >= Len(normalizedDate) Then
        If StrComp(Right$(normalizedName, Len(normalizedDate)), normalizedDate, vbBinaryCompare) = 0 Then
            VfwAlreadyHasDate = True
            Exit Function
        End If
    End If
    Set following = targetRange.Duplicate
    following.SetRange VfwInsertionPosition(targetRange, originalText), VfwInsertionPosition(targetRange, originalText)
    Call following.MoveEnd(wdCharacter, Len(dateText) * 3 + 512)
    normalizedAfter = VfwNormalizeWhitespace(following.Text)
    If Len(normalizedAfter) < Len(normalizedDate) Then Exit Function
    If StrComp(Left$(normalizedAfter, Len(normalizedDate)), normalizedDate, vbBinaryCompare) <> 0 Then Exit Function
    If Len(normalizedAfter) = Len(normalizedDate) Then
        VfwAlreadyHasDate = True
    Else
        VfwAlreadyHasDate = VfwDateBoundary(Mid$(normalizedAfter, Len(normalizedDate) + 1, 1))
    End If
End Function

Private Function VfwDateBoundary(ByVal character As String) As Boolean
    VfwDateBoundary = (InStr(1, " .,;:!?)]}" & Chr$(34), character, vbBinaryCompare) > 0)
End Function

Private Function VfwInsertionPosition(ByVal targetRange As Range, ByVal originalText As String) As Long
    VfwInsertionPosition = targetRange.End - (Len(originalText) - Len(VfwRTrimSpaces(originalText)))
End Function

Private Sub VfwInsertDate(ByVal targetRange As Range, ByVal originalText As String, ByVal dateText As String)
    Dim insertion As Range
    Dim position As Long
    Dim undoObject As Object
    Dim undoStarted As Boolean
    Dim failure As String

    On Error GoTo Failed
    position = VfwInsertionPosition(targetRange, originalText)
    Set insertion = targetRange.Duplicate
    insertion.SetRange position, position
    undoStarted = VfwBeginUndo(undoObject)
    ' The only document write in this module. Do not retry if Word reports an error.
    insertion.InsertAfter " " & dateText
    VfwEndUndo undoObject, undoStarted
    Set insertion = Nothing
    Exit Sub
Failed:
    failure = Err.Description
    VfwEndUndo undoObject, undoStarted
    Set insertion = Nothing
    VfwWarn VfText("Word ekleme i\u015flemini tamamlayamad\u0131. Yeniden denemeden \xf6nce belgedeki ad\u0131 ve tarihi kontrol edin. ") & VfwClip(failure, 350)
End Sub

Private Function VfwBeginUndo(ByRef undoObject As Object) As Boolean
    ' UndoRecord is optional on older Word versions; only these calls ignore errors.
    On Error Resume Next
    Err.Clear
    Set undoObject = CallByName(Application, "UndoRecord", VbGet)
    If Err.Number = 0 Then
        Err.Clear
        CallByName undoObject, "StartCustomRecord", VbMethod, VfText("Vefey\xe2t tarih ekle")
        VfwBeginUndo = (Err.Number = 0)
    End If
    Err.Clear
    On Error GoTo 0
End Function

Private Sub VfwEndUndo(ByRef undoObject As Object, ByRef undoStarted As Boolean)
    If undoStarted Then
        On Error Resume Next
        Err.Clear
        CallByName undoObject, "EndCustomRecord", VbMethod
        Err.Clear
        On Error GoTo 0
    End If
    undoStarted = False
    Set undoObject = Nothing
End Sub

Private Function VfwNormalizeWhitespace(ByVal text As String) As String
    Dim i As Long
    Dim character As String
    Dim code As Long
    Dim pendingSpace As Boolean
    Dim result As String

    For i = 1 To Len(text)
        character = Mid$(text, i, 1)
        code = AscW(character) And &HFFFF&
        If code <= 32 Or code = 133 Or code = 160 Or code = 5760 Or _
           (code >= 8192 And code <= 8202) Or code = 8232 Or code = 8233 Or _
           code = 8239 Or code = 8287 Or code = 12288 Then
            If Len(result) > 0 Then pendingSpace = True
        Else
            If pendingSpace Then result = result & " "
            result = result & character
            pendingSpace = False
        End If
    Next i
    VfwNormalizeWhitespace = result
End Function

Private Function VfwTrimSpaces(ByVal text As String) As String
    Dim first As Long
    Dim last As Long
    first = 1
    last = Len(text)
    Do While first <= last
        If Not VfwOuterSpace(Mid$(text, first, 1)) Then Exit Do
        first = first + 1
    Loop
    Do While last >= first
        If Not VfwOuterSpace(Mid$(text, last, 1)) Then Exit Do
        last = last - 1
    Loop
    If last >= first Then VfwTrimSpaces = Mid$(text, first, last - first + 1)
End Function

Private Function VfwRTrimSpaces(ByVal text As String) As String
    Dim last As Long
    last = Len(text)
    Do While last > 0
        If Not VfwOuterSpace(Mid$(text, last, 1)) Then Exit Do
        last = last - 1
    Loop
    VfwRTrimSpaces = Left$(text, last)
End Function

Private Function VfwOuterSpace(ByVal character As String) As Boolean
    VfwOuterSpace = (character = " " Or character = ChrW(160))
End Function

Private Function VfwClip(ByVal text As String, ByVal maximum As Long) As String
    text = VfwNormalizeWhitespace(text)
    If Len(text) > maximum Then text = Left$(text, maximum - 3) & "..."
    VfwClip = text
End Function

Private Function VfwTitle() As String
    VfwTitle = VfText("Vefey\xe2t")
End Function

Private Sub VfwWarn(ByVal message As String)
    MsgBox message, vbExclamation + vbOKOnly, VfwTitle()
End Sub
